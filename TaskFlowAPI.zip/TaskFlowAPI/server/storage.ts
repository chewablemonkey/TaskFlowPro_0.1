import {
  users,
  projects,
  tasks,
  taskComments,
  taskAttachments,
  projectMembers,
  taskDependencies,
  workflowRules,
  workflowExecutions,
  dashboardLayouts,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type Task,
  type InsertTask,
  type TaskComment,
  type InsertTaskComment,
  type TaskAttachment,
  type InsertTaskAttachment,
  type ProjectMember,
  type InsertProjectMember,
  type TaskDependency,
  type InsertTaskDependency,
  type WorkflowRule,
  type InsertWorkflowRule,
  type WorkflowExecution,
  type InsertWorkflowExecution,
  type DashboardLayout,
  type InsertDashboardLayout,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, count, sum, sql, inArray } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUsersByRole(role: string): Promise<User[]>;
  updateUserRole(userId: string, role: string): Promise<User | undefined>;
  
  // Project operations
  createProject(project: InsertProject): Promise<Project>;
  getProject(id: string): Promise<Project | undefined>;
  getUserProjects(userId: string): Promise<Project[]>;
  updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  getProjectMembers(projectId: string): Promise<(ProjectMember & { user: User })[]>;
  addProjectMember(member: InsertProjectMember): Promise<ProjectMember>;
  removeProjectMember(projectId: string, userId: string): Promise<boolean>;
  
  // Task operations
  createTask(task: InsertTask): Promise<Task>;
  getTask(id: string): Promise<Task | undefined>;
  getProjectTasks(projectId: string): Promise<(Task & { assignee?: User; creator: User })[]>;
  getUserTasks(userId: string): Promise<(Task & { project: Project; assignee?: User })[]>;
  updateTask(id: string, updates: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: string): Promise<boolean>;
  
  // Task comments
  createTaskComment(comment: InsertTaskComment): Promise<TaskComment>;
  getTaskComments(taskId: string): Promise<(TaskComment & { author: User })[]>;
  deleteTaskComment(id: string): Promise<boolean>;
  
  // Task attachments
  createTaskAttachment(attachment: InsertTaskAttachment): Promise<TaskAttachment>;
  getTaskAttachments(taskId: string): Promise<(TaskAttachment & { uploadedBy: User })[]>;
  deleteTaskAttachment(id: string): Promise<boolean>;
  
  // Task dependencies
  createTaskDependency(dependency: InsertTaskDependency): Promise<TaskDependency>;
  getTaskDependencies(taskId: string): Promise<TaskDependency[]>;
  deleteTaskDependency(id: string): Promise<boolean>;
  
  // Dashboard statistics
  getDashboardStats(userId: string): Promise<{
    activeProjects: number;
    totalTasks: number;
    completedTasks: number;
    teamMembers: number;
  }>;
  
  // Workflow automation operations
  createWorkflowRule(rule: InsertWorkflowRule): Promise<WorkflowRule>;
  getWorkflowRule(id: string): Promise<WorkflowRule | undefined>;
  getUserWorkflowRules(userId: string): Promise<WorkflowRule[]>;
  getActiveWorkflowRules(projectId?: string): Promise<WorkflowRule[]>;
  updateWorkflowRule(id: string, updates: Partial<InsertWorkflowRule>): Promise<WorkflowRule | undefined>;
  deleteWorkflowRule(id: string): Promise<boolean>;
  
  // Workflow execution tracking
  createWorkflowExecution(execution: InsertWorkflowExecution): Promise<WorkflowExecution>;
  getWorkflowExecutions(ruleId: string): Promise<WorkflowExecution[]>;
  updateWorkflowExecution(id: string, status: string, error?: string): Promise<void>;
  
  // Dashboard layout operations
  createDashboardLayout(layout: InsertDashboardLayout): Promise<DashboardLayout>;
  getDashboardLayout(id: string): Promise<DashboardLayout | undefined>;
  getUserDashboardLayouts(userId: string): Promise<DashboardLayout[]>;
  updateDashboardLayout(id: string, updates: Partial<InsertDashboardLayout>): Promise<DashboardLayout | undefined>;
  deleteDashboardLayout(id: string): Promise<boolean>;
  getUserDefaultLayout(userId: string): Promise<DashboardLayout | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role as any));
  }

  async updateUserRole(userId: string, role: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role: role as any, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Project operations
  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    // Get projects where user is owner or member
    const ownedProjects = await db
      .select()
      .from(projects)
      .where(eq(projects.ownerId, userId));
    
    const memberProjects = await db
      .select({ 
        id: projects.id,
        name: projects.name,
        description: projects.description,
        status: projects.status,
        parentProjectId: projects.parentProjectId,
        ownerId: projects.ownerId,
        startDate: projects.startDate,
        dueDate: projects.dueDate,
        completedAt: projects.completedAt,
        createdAt: projects.createdAt,
        updatedAt: projects.updatedAt,
      })
      .from(projects)
      .innerJoin(projectMembers, eq(projects.id, projectMembers.projectId))
      .where(eq(projectMembers.userId, userId));

    // Combine and deduplicate
    const allProjects = [...ownedProjects, ...memberProjects];
    const uniqueProjects = allProjects.filter((project, index, self) => 
      index === self.findIndex(p => p.id === project.id)
    );
    
    return uniqueProjects;
  }

  async updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: string): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getProjectMembers(projectId: string): Promise<(ProjectMember & { user: User })[]> {
    return await db
      .select({
        id: projectMembers.id,
        projectId: projectMembers.projectId,
        userId: projectMembers.userId,
        role: projectMembers.role,
        canEdit: projectMembers.canEdit,
        joinedAt: projectMembers.joinedAt,
        user: users,
      })
      .from(projectMembers)
      .innerJoin(users, eq(projectMembers.userId, users.id))
      .where(eq(projectMembers.projectId, projectId));
  }

  async addProjectMember(member: InsertProjectMember): Promise<ProjectMember> {
    const [newMember] = await db.insert(projectMembers).values(member).returning();
    return newMember;
  }

  async removeProjectMember(projectId: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(projectMembers)
      .where(and(
        eq(projectMembers.projectId, projectId),
        eq(projectMembers.userId, userId)
      ));
    return (result.rowCount ?? 0) > 0;
  }

  // Task operations
  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async getTask(id: string): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async getProjectTasks(projectId: string): Promise<(Task & { assignee?: User; creator: User })[]> {
    return await db
      .select()
      .from(tasks)
      .leftJoin(users, eq(tasks.assigneeId, users.id))
      .where(eq(tasks.projectId, projectId))
      .then(async (results) => {
        // Get creator info separately to avoid complex joins
        const tasksWithCreators = await Promise.all(
          results.map(async (result) => {
            const [creator] = await db.select().from(users).where(eq(users.id, result.tasks.creatorId));
            return {
              ...result.tasks,
              assignee: result.users || undefined,
              creator: creator || {
                id: 'unknown',
                email: 'unknown@example.com',
                firstName: 'Unknown',
                lastName: 'User',
                profileImageUrl: null,
                role: 'employee' as const,
                isActive: true,
                createdAt: new Date(),
                updatedAt: new Date(),
              },
            };
          })
        );
        return tasksWithCreators;
      });
  }

  async getUserTasks(userId: string): Promise<(Task & { project: Project; assignee?: User })[]> {
    // Get projects the user has access to
    const userProjects = await this.getUserProjects(userId);
    const projectIds = userProjects.map(p => p.id);
    
    if (projectIds.length === 0) {
      return [];
    }

    return await db
      .select({
        id: tasks.id,
        title: tasks.title,
        description: tasks.description,
        status: tasks.status,
        priority: tasks.priority,
        projectId: tasks.projectId,
        assigneeId: tasks.assigneeId,
        creatorId: tasks.creatorId,
        dueDate: tasks.dueDate,
        completedAt: tasks.completedAt,
        estimatedHours: tasks.estimatedHours,
        actualHours: tasks.actualHours,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
        project: projects,
        assignee: users,
      })
      .from(tasks)
      .innerJoin(projects, eq(tasks.projectId, projects.id))
      .leftJoin(users, eq(tasks.assigneeId, users.id))
      .where(inArray(tasks.projectId, projectIds));
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<Task | undefined> {
    const updateData: any = { ...updates, updatedAt: new Date() };
    
    // Set completedAt if status is being changed to completed
    if (updates.status === 'completed') {
      updateData.completedAt = new Date();
    } else if (updates.status && updates.status !== 'completed') {
      updateData.completedAt = null;
    }

    const [task] = await db
      .update(tasks)
      .set(updateData)
      .where(eq(tasks.id, id))
      .returning();
    return task;
  }

  async deleteTask(id: string): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Task comments
  async createTaskComment(comment: InsertTaskComment): Promise<TaskComment> {
    const [newComment] = await db.insert(taskComments).values(comment).returning();
    return newComment;
  }

  async getTaskComments(taskId: string): Promise<(TaskComment & { author: User })[]> {
    return await db
      .select({
        id: taskComments.id,
        taskId: taskComments.taskId,
        authorId: taskComments.authorId,
        content: taskComments.content,
        createdAt: taskComments.createdAt,
        updatedAt: taskComments.updatedAt,
        author: users,
      })
      .from(taskComments)
      .innerJoin(users, eq(taskComments.authorId, users.id))
      .where(eq(taskComments.taskId, taskId))
      .orderBy(asc(taskComments.createdAt));
  }

  async deleteTaskComment(id: string): Promise<boolean> {
    const result = await db.delete(taskComments).where(eq(taskComments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Task attachments
  async createTaskAttachment(attachment: InsertTaskAttachment): Promise<TaskAttachment> {
    const [newAttachment] = await db.insert(taskAttachments).values(attachment).returning();
    return newAttachment;
  }

  async getTaskAttachments(taskId: string): Promise<(TaskAttachment & { uploadedBy: User })[]> {
    return await db
      .select({
        id: taskAttachments.id,
        taskId: taskAttachments.taskId,
        uploadedById: taskAttachments.uploadedById,
        fileName: taskAttachments.fileName,
        originalFileName: taskAttachments.originalFileName,
        fileSize: taskAttachments.fileSize,
        mimeType: taskAttachments.mimeType,
        objectPath: taskAttachments.objectPath,
        createdAt: taskAttachments.createdAt,
        uploadedBy: users,
      })
      .from(taskAttachments)
      .innerJoin(users, eq(taskAttachments.uploadedById, users.id))
      .where(eq(taskAttachments.taskId, taskId))
      .orderBy(desc(taskAttachments.createdAt));
  }

  async deleteTaskAttachment(id: string): Promise<boolean> {
    const result = await db.delete(taskAttachments).where(eq(taskAttachments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Task dependencies
  async createTaskDependency(dependency: InsertTaskDependency): Promise<TaskDependency> {
    const [newDependency] = await db.insert(taskDependencies).values(dependency).returning();
    return newDependency;
  }

  async getTaskDependencies(taskId: string): Promise<TaskDependency[]> {
    return await db
      .select()
      .from(taskDependencies)
      .where(eq(taskDependencies.taskId, taskId));
  }

  async deleteTaskDependency(id: string): Promise<boolean> {
    const result = await db.delete(taskDependencies).where(eq(taskDependencies.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Dashboard statistics
  async getDashboardStats(userId: string): Promise<{
    activeProjects: number;
    totalTasks: number;
    completedTasks: number;
    teamMembers: number;
  }> {
    // Get projects where user is owner or member
    const userProjectsSubquery = db
      .select({ id: projects.id })
      .from(projects)
      .leftJoin(projectMembers, eq(projects.id, projectMembers.projectId))
      .where(
        sql`${projects.ownerId} = ${userId} OR ${projectMembers.userId} = ${userId}`
      )
      .as('userProjects');

    // Active projects count
    const [activeProjectsResult] = await db
      .select({ count: count() })
      .from(userProjectsSubquery)
      .innerJoin(projects, eq(userProjectsSubquery.id, projects.id))
      .where(eq(projects.status, 'active'));

    // Total tasks count (from accessible projects)
    const [totalTasksResult] = await db
      .select({ count: count() })
      .from(tasks)
      .innerJoin(userProjectsSubquery, eq(tasks.projectId, userProjectsSubquery.id));

    // Completed tasks count (from accessible projects)
    const [completedTasksResult] = await db
      .select({ count: count() })
      .from(tasks)
      .innerJoin(userProjectsSubquery, eq(tasks.projectId, userProjectsSubquery.id))
      .where(eq(tasks.status, 'completed'));

    // Team members count (unique users in user's projects)
    const [teamMembersResult] = await db
      .select({ count: count(sql`DISTINCT ${projectMembers.userId}`) })
      .from(projectMembers)
      .innerJoin(userProjectsSubquery, eq(projectMembers.projectId, userProjectsSubquery.id));

    return {
      activeProjects: activeProjectsResult.count,
      totalTasks: totalTasksResult.count,
      completedTasks: completedTasksResult.count,
      teamMembers: teamMembersResult.count,
    };
  }

  // Enhanced dashboard analytics
  async getDashboardAnalytics(userId: string): Promise<{
    projectStatusDistribution: Record<string, number>;
    taskPriorityDistribution: Record<string, number>;
    overdueTasks: number;
    completionTrend: { date: string; completed: number; total: number }[];
  }> {
    const userProjectsSubquery = db
      .select({ id: projects.id })
      .from(projects)
      .leftJoin(projectMembers, eq(projects.id, projectMembers.projectId))
      .where(
        sql`${projects.ownerId} = ${userId} OR ${projectMembers.userId} = ${userId}`
      )
      .as('userProjects');

    // Project status distribution
    const projectStatuses = await db
      .select({ 
        status: projects.status,
        count: count()
      })
      .from(userProjectsSubquery)
      .innerJoin(projects, eq(userProjectsSubquery.id, projects.id))
      .groupBy(projects.status);

    // Task priority distribution  
    const taskPriorities = await db
      .select({
        priority: tasks.priority,
        count: count()
      })
      .from(tasks)
      .innerJoin(userProjectsSubquery, eq(tasks.projectId, userProjectsSubquery.id))
      .groupBy(tasks.priority);

    // Overdue tasks count
    const [overdueResult] = await db
      .select({ count: count() })
      .from(tasks)
      .innerJoin(userProjectsSubquery, eq(tasks.projectId, userProjectsSubquery.id))
      .where(
        sql`${tasks.dueDate} < NOW() AND ${tasks.status} != 'completed'`
      );

    return {
      projectStatusDistribution: Object.fromEntries(
        projectStatuses.map(s => [s.status || 'planning', s.count])
      ),
      taskPriorityDistribution: Object.fromEntries(
        taskPriorities.map(p => [p.priority || 'medium', p.count])
      ),
      overdueTasks: overdueResult.count,
      completionTrend: [], // Simplified for now - would need historical data
    };
  }

  // Recent activities for activity feed
  async getRecentActivities(userId: string, limit: number = 20): Promise<{
    id: string;
    type: string;
    title: string;
    description: string;
    timestamp: Date;
    userId: string;
    userName?: string;
    projectId?: string;
    taskId?: string;
  }[]> {
    const userProjectsSubquery = db
      .select({ id: projects.id })
      .from(projects)
      .leftJoin(projectMembers, eq(projects.id, projectMembers.projectId))
      .where(
        sql`${projects.ownerId} = ${userId} OR ${projectMembers.userId} = ${userId}`
      )
      .as('userProjects');

    // Get recent task updates
    const recentTasks = await db
      .select({
        id: tasks.id,
        title: tasks.title,
        status: tasks.status,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
        projectId: tasks.projectId,
        creatorId: tasks.creatorId,
        assigneeId: tasks.assigneeId,
      })
      .from(tasks)
      .innerJoin(userProjectsSubquery, eq(tasks.projectId, userProjectsSubquery.id))
      .orderBy(sql`${tasks.updatedAt} DESC`)
      .limit(limit);

    // Transform to activity format
    return recentTasks.map(task => ({
      id: `task-${task.id}`,
      type: 'task_update',
      title: task.status === 'completed' ? 'Task Completed' : 'Task Updated',
      description: task.title,
      timestamp: task.updatedAt,
      userId: task.assigneeId || task.creatorId || userId,
      projectId: task.projectId,
      taskId: task.id,
    }));
  }

  // Team workload analytics
  async getTeamWorkload(userId: string): Promise<{
    memberId: string;
    memberName?: string;
    activeTasks: number;
    completedTasks: number;
    totalHours: number;
    utilization: number;
  }[]> {
    const userProjectsSubquery = db
      .select({ id: projects.id })
      .from(projects)
      .leftJoin(projectMembers, eq(projects.id, projectMembers.projectId))
      .where(
        sql`${projects.ownerId} = ${userId} OR ${projectMembers.userId} = ${userId}`
      )
      .as('userProjects');

    // Get team member workload data
    const workloadData = await db
      .select({
        assigneeId: tasks.assigneeId,
        status: tasks.status,
        totalEstimatedHours: sql<number>`SUM(${tasks.estimatedHours})`,
        count: count(),
      })
      .from(tasks)
      .innerJoin(userProjectsSubquery, eq(tasks.projectId, userProjectsSubquery.id))
      .where(sql`${tasks.assigneeId} IS NOT NULL`)
      .groupBy(tasks.assigneeId, tasks.status);

    // Group by member and calculate metrics
    const memberMetrics = new Map();
    
    for (const item of workloadData) {
      if (!memberMetrics.has(item.assigneeId)) {
        memberMetrics.set(item.assigneeId, {
          memberId: item.assigneeId,
          activeTasks: 0,
          completedTasks: 0,
          totalHours: 0,
        });
      }
      
      const member = memberMetrics.get(item.assigneeId);
      
      if (item.status === 'completed') {
        member.completedTasks += item.count;
      } else {
        member.activeTasks += item.count;
      }
      
      member.totalHours += Number(item.totalEstimatedHours) || 0;
    }

    return Array.from(memberMetrics.values()).map(member => ({
      ...member,
      utilization: Math.min(100, Math.round((member.totalHours / 40) * 100)), // Assuming 40h work week
    }));
  }

  // Workflow automation operations
  async createWorkflowRule(rule: InsertWorkflowRule): Promise<WorkflowRule> {
    const [newRule] = await db.insert(workflowRules).values(rule).returning();
    return newRule;
  }

  async getWorkflowRule(id: string): Promise<WorkflowRule | undefined> {
    const [rule] = await db.select().from(workflowRules).where(eq(workflowRules.id, id));
    return rule;
  }

  async getUserWorkflowRules(userId: string): Promise<WorkflowRule[]> {
    return await db
      .select()
      .from(workflowRules)
      .where(eq(workflowRules.createdById, userId))
      .orderBy(desc(workflowRules.createdAt));
  }

  async getActiveWorkflowRules(projectId?: string): Promise<WorkflowRule[]> {
    const conditions = [eq(workflowRules.isActive, true)];
    
    if (projectId) {
      conditions.push(
        sql`(${workflowRules.projectId} = ${projectId} OR ${workflowRules.projectId} IS NULL)`
      );
    } else {
      conditions.push(sql`${workflowRules.projectId} IS NULL`);
    }

    return await db
      .select()
      .from(workflowRules)
      .where(and(...conditions))
      .orderBy(desc(workflowRules.createdAt));
  }

  async updateWorkflowRule(id: string, updates: Partial<InsertWorkflowRule>): Promise<WorkflowRule | undefined> {
    const [updatedRule] = await db
      .update(workflowRules)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(workflowRules.id, id))
      .returning();
    return updatedRule;
  }

  async deleteWorkflowRule(id: string): Promise<boolean> {
    const result = await db.delete(workflowRules).where(eq(workflowRules.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Workflow execution tracking
  async createWorkflowExecution(execution: InsertWorkflowExecution): Promise<WorkflowExecution> {
    const [newExecution] = await db.insert(workflowExecutions).values(execution).returning();
    return newExecution;
  }

  async getWorkflowExecutions(ruleId: string): Promise<WorkflowExecution[]> {
    return await db
      .select()
      .from(workflowExecutions)
      .where(eq(workflowExecutions.ruleId, ruleId))
      .orderBy(desc(workflowExecutions.executedAt));
  }

  async updateWorkflowExecution(id: string, status: string, error?: string): Promise<void> {
    await db
      .update(workflowExecutions)
      .set({ status, error })
      .where(eq(workflowExecutions.id, id));
  }

  // Dashboard layout operations
  async createDashboardLayout(layout: InsertDashboardLayout): Promise<DashboardLayout> {
    const [newLayout] = await db.insert(dashboardLayouts).values(layout).returning();
    return newLayout;
  }

  async getDashboardLayout(id: string): Promise<DashboardLayout | undefined> {
    const [layout] = await db.select().from(dashboardLayouts).where(eq(dashboardLayouts.id, id));
    return layout;
  }

  async getUserDashboardLayouts(userId: string): Promise<DashboardLayout[]> {
    return await db
      .select()
      .from(dashboardLayouts)
      .where(eq(dashboardLayouts.userId, userId))
      .orderBy(desc(dashboardLayouts.updatedAt));
  }

  async updateDashboardLayout(id: string, updates: Partial<InsertDashboardLayout>): Promise<DashboardLayout | undefined> {
    const [updatedLayout] = await db
      .update(dashboardLayouts)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(dashboardLayouts.id, id))
      .returning();
    return updatedLayout;
  }

  async deleteDashboardLayout(id: string): Promise<boolean> {
    const result = await db.delete(dashboardLayouts).where(eq(dashboardLayouts.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getUserDefaultLayout(userId: string): Promise<DashboardLayout | undefined> {
    const [defaultLayout] = await db
      .select()
      .from(dashboardLayouts)
      .where(and(eq(dashboardLayouts.userId, userId), eq(dashboardLayouts.isDefault, true)))
      .limit(1);
    return defaultLayout;
  }
}

export const storage = new DatabaseStorage();
