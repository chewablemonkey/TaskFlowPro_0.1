import { storage } from "./storage";
import { WorkflowRule, Task, Project, User } from "@shared/schema";
import { isAfter, subDays } from "date-fns";

interface TriggerContext {
  task?: Task & { project?: Project; assignee?: User };
  project?: Project;
  user?: User;
  oldValues?: any;
  newValues?: any;
}

export class WorkflowEngine {
  // Execute workflow rules based on trigger type and context
  async executeTriggers(
    triggerType: string, 
    context: TriggerContext,
    triggeredBy?: string
  ): Promise<void> {
    try {
      // Get active workflow rules for this trigger type
      const projectId = context.task?.projectId || context.project?.id;
      const rules = await storage.getActiveWorkflowRules(projectId);
      
      const matchingRules = rules.filter(rule => rule.triggerType === triggerType);

      for (const rule of matchingRules) {
        if (await this.evaluateTriggerConditions(rule, context)) {
          await this.executeRule(rule, context, triggeredBy);
        }
      }
    } catch (error) {
      console.error("Error executing workflow triggers:", error);
    }
  }

  // Evaluate if trigger conditions are met
  private async evaluateTriggerConditions(
    rule: WorkflowRule, 
    context: TriggerContext
  ): Promise<boolean> {
    const conditions = rule.triggerConditions as any;

    switch (rule.triggerType) {
      case 'task_status_changed':
        return this.evaluateTaskStatusChanged(conditions, context);
      
      case 'task_priority_changed':
        return this.evaluateTaskPriorityChanged(conditions, context);
      
      case 'task_due_approaching':
        return this.evaluateTaskDueApproaching(conditions, context);
      
      case 'task_overdue':
        return this.evaluateTaskOverdue(conditions, context);
      
      case 'project_status_changed':
        return this.evaluateProjectStatusChanged(conditions, context);
      
      case 'task_created':
        return this.evaluateTaskCreated(conditions, context);
      
      case 'task_assigned':
        return this.evaluateTaskAssigned(conditions, context);
      
      default:
        return false;
    }
  }

  // Execute the workflow rule action
  private async executeRule(
    rule: WorkflowRule, 
    context: TriggerContext,
    triggeredBy?: string
  ): Promise<void> {
    // Create execution log
    const execution = await storage.createWorkflowExecution({
      ruleId: rule.id,
      triggeredBy: triggeredBy || null,
      triggerData: JSON.stringify(context),
      status: 'pending',
    });

    try {
      await this.performAction(rule, context, triggeredBy);
      
      // Mark execution as successful
      await storage.updateWorkflowExecution(execution.id, 'success');
      
      console.log(`Workflow rule "${rule.name}" executed successfully`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      await storage.updateWorkflowExecution(execution.id, 'failed', errorMessage);
      console.error(`Workflow rule "${rule.name}" failed:`, error);
    }
  }

  // Perform the action specified in the workflow rule
  private async performAction(
    rule: WorkflowRule, 
    context: TriggerContext,
    triggeredBy?: string
  ): Promise<void> {
    const actionData = rule.actionData as any;

    switch (rule.actionType) {
      case 'send_notification':
        await this.sendNotification(actionData, context);
        break;
      
      case 'send_email':
        await this.sendEmail(actionData, context);
        break;
      
      case 'change_task_priority':
        await this.changeTaskPriority(actionData, context);
        break;
      
      case 'assign_task':
        await this.assignTask(actionData, context);
        break;
      
      case 'add_comment':
        await this.addComment(actionData, context, triggeredBy);
        break;
      
      default:
        throw new Error(`Unknown action type: ${rule.actionType}`);
    }
  }

  // Trigger condition evaluators
  private evaluateTaskStatusChanged(conditions: any, context: TriggerContext): boolean {
    if (!context.task || !context.oldValues || !context.newValues) return false;
    
    const fromStatus = conditions.fromStatus;
    const toStatus = conditions.toStatus;
    
    const statusChanged = context.oldValues.status !== context.newValues.status;
    const fromMatches = !fromStatus || context.oldValues.status === fromStatus;
    const toMatches = !toStatus || context.newValues.status === toStatus;
    
    return statusChanged && fromMatches && toMatches;
  }

  private evaluateTaskPriorityChanged(conditions: any, context: TriggerContext): boolean {
    if (!context.task || !context.oldValues || !context.newValues) return false;
    
    const fromPriority = conditions.fromPriority;
    const toPriority = conditions.toPriority;
    
    const priorityChanged = context.oldValues.priority !== context.newValues.priority;
    const fromMatches = !fromPriority || context.oldValues.priority === fromPriority;
    const toMatches = !toPriority || context.newValues.priority === toPriority;
    
    return priorityChanged && fromMatches && toMatches;
  }

  private evaluateTaskDueApproaching(conditions: any, context: TriggerContext): boolean {
    if (!context.task?.dueDate) return false;
    
    const daysBeforeDue = conditions.daysBeforeDue || 1;
    const dueDate = new Date(context.task.dueDate);
    const alertDate = subDays(dueDate, daysBeforeDue);
    
    return new Date() >= alertDate && new Date() < dueDate;
  }

  private evaluateTaskOverdue(conditions: any, context: TriggerContext): boolean {
    if (!context.task?.dueDate || context.task.status === 'completed') return false;
    
    return isAfter(new Date(), new Date(context.task.dueDate));
  }

  private evaluateProjectStatusChanged(conditions: any, context: TriggerContext): boolean {
    if (!context.project || !context.oldValues || !context.newValues) return false;
    
    const fromStatus = conditions.fromStatus;
    const toStatus = conditions.toStatus;
    
    const statusChanged = context.oldValues.status !== context.newValues.status;
    const fromMatches = !fromStatus || context.oldValues.status === fromStatus;
    const toMatches = !toStatus || context.newValues.status === toStatus;
    
    return statusChanged && fromMatches && toMatches;
  }

  private evaluateTaskCreated(conditions: any, context: TriggerContext): boolean {
    if (!context.task) return false;
    
    const projectId = conditions.projectId;
    const priority = conditions.priority;
    
    const projectMatches = !projectId || context.task.projectId === projectId;
    const priorityMatches = !priority || context.task.priority === priority;
    
    return projectMatches && priorityMatches;
  }

  private evaluateTaskAssigned(conditions: any, context: TriggerContext): boolean {
    if (!context.task || !context.oldValues || !context.newValues) return false;
    
    const assigneeChanged = context.oldValues.assigneeId !== context.newValues.assigneeId;
    const assignedToSomeone = context.newValues.assigneeId != null;
    
    return assigneeChanged && assignedToSomeone;
  }

  // Action performers
  private async sendNotification(actionData: any, context: TriggerContext): Promise<void> {
    // In a real implementation, this would integrate with a notification service
    // For now, we'll just log the notification
    const message = this.interpolateTemplate(actionData.message, context);
    console.log(`[NOTIFICATION] ${message}`);
    
    // Could integrate with browser notifications, push notifications, etc.
  }

  private async sendEmail(actionData: any, context: TriggerContext): Promise<void> {
    // In a real implementation, this would integrate with an email service
    const subject = this.interpolateTemplate(actionData.subject, context);
    const body = this.interpolateTemplate(actionData.body, context);
    
    console.log(`[EMAIL] To: ${actionData.to}, Subject: ${subject}, Body: ${body}`);
    
    // Could integrate with SendGrid, Mailgun, AWS SES, etc.
  }

  private async changeTaskPriority(actionData: any, context: TriggerContext): Promise<void> {
    if (!context.task) throw new Error("No task in context");
    
    await storage.updateTask(context.task.id, {
      priority: actionData.priority
    });
  }

  private async assignTask(actionData: any, context: TriggerContext): Promise<void> {
    if (!context.task) throw new Error("No task in context");
    
    await storage.updateTask(context.task.id, {
      assigneeId: actionData.assigneeId
    });
  }

  private async addComment(actionData: any, context: TriggerContext, triggeredBy?: string): Promise<void> {
    if (!context.task) throw new Error("No task in context");
    
    const comment = this.interpolateTemplate(actionData.comment, context);
    
    await storage.createTaskComment({
      taskId: context.task.id,
      authorId: triggeredBy || actionData.authorId,
      content: comment,
    });
  }

  // Template interpolation for dynamic content
  private interpolateTemplate(template: string, context: TriggerContext): string {
    let result = template;
    
    if (context.task) {
      result = result.replace(/\{task\.title\}/g, context.task.title);
      result = result.replace(/\{task\.status\}/g, context.task.status || '');
      result = result.replace(/\{task\.priority\}/g, context.task.priority || '');
      result = result.replace(/\{task\.dueDate\}/g, context.task.dueDate?.toISOString() || '');
    }
    
    if (context.project) {
      result = result.replace(/\{project\.name\}/g, context.project.name);
      result = result.replace(/\{project\.status\}/g, context.project.status || '');
    }
    
    if (context.user) {
      result = result.replace(/\{user\.firstName\}/g, context.user.firstName || '');
      result = result.replace(/\{user\.lastName\}/g, context.user.lastName || '');
      result = result.replace(/\{user\.email\}/g, context.user.email || '');
    }
    
    return result;
  }

  // Check for overdue tasks and due date approaching (called periodically)
  async checkScheduledTriggers(): Promise<void> {
    try {
      // Get all tasks that might trigger due date or overdue conditions
      const allRules = await storage.getActiveWorkflowRules();
      const dueDateRules = allRules.filter(rule => 
        rule.triggerType === 'task_due_approaching' || 
        rule.triggerType === 'task_overdue'
      );
      
      if (dueDateRules.length === 0) return;
      
      // This would need to be implemented to get all tasks
      // For now, we'll skip this functionality
      console.log("Scheduled trigger check would run here");
    } catch (error) {
      console.error("Error checking scheduled triggers:", error);
    }
  }
}

export const workflowEngine = new WorkflowEngine();