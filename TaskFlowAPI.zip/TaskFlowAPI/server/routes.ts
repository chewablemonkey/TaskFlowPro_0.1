import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertProjectSchema, insertTaskSchema, insertTaskCommentSchema, insertTaskAttachmentSchema, insertProjectMemberSchema, insertWorkflowRuleSchema, insertDashboardLayoutSchema, type User } from "@shared/schema";
import { workflowEngine } from "./workflowEngine";
import { z } from "zod";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { ObjectPermission } from "./objectAcl";

// Safe update schema that only allows editing non-sensitive fields
const updateProjectSchema = insertProjectSchema.pick({
  name: true,
  description: true,
  status: true,
  startDate: true,
  dueDate: true,
});

// Safe task update schema that only allows editing non-sensitive fields
const updateTaskSchema = insertTaskSchema.pick({
  title: true,
  description: true,
  status: true,
  priority: true,
  assigneeId: true,
  dueDate: true,
  estimatedHours: true,
  actualHours: true,
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getDashboardStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Enhanced dashboard analytics
  app.get('/api/dashboard/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const analytics = await storage.getDashboardAnalytics(userId);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching dashboard analytics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard analytics" });
    }
  });

  // Activity feed endpoint
  app.get('/api/dashboard/activities', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 20;
      const activities = await storage.getRecentActivities(userId, limit);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Team workload analytics
  app.get('/api/dashboard/team-workload', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workload = await storage.getTeamWorkload(userId);
      res.json(workload);
    } catch (error) {
      console.error("Error fetching team workload:", error);
      res.status(500).json({ message: "Failed to fetch team workload" });
    }
  });

  // Dashboard layout routes
  app.get('/api/dashboard/layouts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const layouts = await storage.getUserDashboardLayouts(userId);
      res.json(layouts);
    } catch (error) {
      console.error("Error fetching dashboard layouts:", error);
      res.status(500).json({ message: "Failed to fetch dashboard layouts" });
    }
  });

  app.get('/api/dashboard/layouts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const layout = await storage.getDashboardLayout(id);
      
      if (!layout) {
        return res.status(404).json({ message: "Dashboard layout not found" });
      }

      // Check if user owns this layout
      const userId = req.user.claims.sub;
      if (layout.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(layout);
    } catch (error) {
      console.error("Error fetching dashboard layout:", error);
      res.status(500).json({ message: "Failed to fetch dashboard layout" });
    }
  });

  app.post('/api/dashboard/layouts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const validatedData = insertDashboardLayoutSchema.parse({
        ...req.body,
        userId: userId,
      });
      
      const layout = await storage.createDashboardLayout(validatedData);
      res.status(201).json(layout);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating dashboard layout:", error);
      res.status(500).json({ message: "Failed to create dashboard layout" });
    }
  });

  app.put('/api/dashboard/layouts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const layout = await storage.getDashboardLayout(id);
      if (!layout) {
        return res.status(404).json({ message: "Dashboard layout not found" });
      }

      // Check if user owns this layout
      if (layout.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const validatedData = insertDashboardLayoutSchema.partial().parse(req.body);
      const updatedLayout = await storage.updateDashboardLayout(id, validatedData);
      
      if (!updatedLayout) {
        return res.status(404).json({ message: "Dashboard layout not found" });
      }

      res.json(updatedLayout);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating dashboard layout:", error);
      res.status(500).json({ message: "Failed to update dashboard layout" });
    }
  });

  app.delete('/api/dashboard/layouts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const layout = await storage.getDashboardLayout(id);
      if (!layout) {
        return res.status(404).json({ message: "Dashboard layout not found" });
      }

      // Check if user owns this layout
      if (layout.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const success = await storage.deleteDashboardLayout(id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ message: "Dashboard layout not found" });
      }
    } catch (error) {
      console.error("Error deleting dashboard layout:", error);
      res.status(500).json({ message: "Failed to delete dashboard layout" });
    }
  });

  // Project routes
  app.get('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projects = await storage.getUserProjects(userId);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Check if user has access to this project
      const userId = req.user.claims.sub;
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === id);
      
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !['admin', 'manager', 'employee'].includes(user.role || '')) {
        return res.status(403).json({ message: "Authentication required to create projects" });
      }

      const validatedData = insertProjectSchema.parse({
        ...req.body,
        ownerId: userId,
      });
      
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating project:", error);
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.put('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Check permissions - project owners or admin/managers can edit
      if (project.ownerId !== userId && !['admin', 'manager'].includes(user?.role || '')) {
        return res.status(403).json({ message: "Only project owners, admins, and managers can edit projects" });
      }

      const validatedData = updateProjectSchema.partial().parse(req.body);
      const updatedProject = await storage.updateProject(id, validatedData);
      
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(updatedProject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating project:", error);
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  // PATCH route for partial project updates (same logic as PUT)
  app.patch('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Check permissions
      if (project.ownerId !== userId && !['admin', 'manager'].includes(user?.role || '')) {
        return res.status(403).json({ message: "Access denied" });
      }

      const validatedData = updateProjectSchema.partial().parse(req.body);
      const updatedProject = await storage.updateProject(id, validatedData);
      
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(updatedProject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating project:", error);
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.delete('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Only owners and admins can delete projects
      if (project.ownerId !== userId && user?.role !== 'admin') {
        return res.status(403).json({ message: "Access denied" });
      }

      const success = await storage.deleteProject(id);
      if (!success) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting project:", error);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Project members routes
  app.get('/api/projects/:id/members', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Check access
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === id);
      
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied" });
      }

      const members = await storage.getProjectMembers(id);
      res.json(members);
    } catch (error) {
      console.error("Error fetching project members:", error);
      res.status(500).json({ message: "Failed to fetch project members" });
    }
  });

  app.post('/api/projects/:id/members', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Check permissions
      if (project.ownerId !== userId && !['admin', 'manager'].includes(user?.role || '')) {
        return res.status(403).json({ message: "Access denied" });
      }

      const validatedData = insertProjectMemberSchema.parse({
        ...req.body,
        projectId: id,
      });
      
      const member = await storage.addProjectMember(validatedData);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error adding project member:", error);
      res.status(500).json({ message: "Failed to add project member" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { project } = req.query;
      
      if (project) {
        // Check access to project
        const userProjects = await storage.getUserProjects(userId);
        const hasAccess = userProjects.some(p => p.id === project);
        
        if (!hasAccess) {
          return res.status(403).json({ message: "Access denied" });
        }

        const tasks = await storage.getProjectTasks(project as string);
        res.json(tasks);
      } else {
        const tasks = await storage.getUserTasks(userId);
        res.json(tasks);
      }
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const task = await storage.getTask(id);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check if user has access to the task's project
      const userId = req.user.claims.sub;
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === task.projectId);
      
      if (!hasAccess && task.assigneeId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Check access to project
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === req.body.projectId);
      
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied to project" });
      }

      const validatedData = insertTaskSchema.parse({
        ...req.body,
        creatorId: userId,
      });
      
      const task = await storage.createTask(validatedData);
      
      // Trigger workflow automation for task creation
      try {
        const project = await storage.getProject(validatedData.projectId);
        const assignee = task.assigneeId ? await storage.getUser(task.assigneeId) : undefined;
        
        const context = {
          task: { ...task, project, assignee }
        };

        await workflowEngine.executeTriggers('task_created', context, userId);
      } catch (workflowError) {
        // Don't fail the creation if workflow execution fails
        console.error("Workflow execution error:", workflowError);
      }
      
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.put('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check permissions - creator, assignee, or project member can update
      const userProjects = await storage.getUserProjects(userId);
      const hasProjectAccess = userProjects.some(p => p.id === task.projectId);
      const canUpdate = task.creatorId === userId || 
                       task.assigneeId === userId || 
                       hasProjectAccess;
      
      if (!canUpdate) {
        return res.status(403).json({ message: "Access denied" });
      }

      const validatedData = updateTaskSchema.partial().parse(req.body);
      const oldTask = { ...task }; // Capture old values for workflow triggers
      
      const updatedTask = await storage.updateTask(id, validatedData);
      
      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Trigger workflow automation for task changes
      try {
        const project = await storage.getProject(task.projectId);
        const assignee = updatedTask.assigneeId ? await storage.getUser(updatedTask.assigneeId) : undefined;
        
        const context = {
          task: { ...updatedTask, project, assignee },
          oldValues: oldTask,
          newValues: updatedTask
        };

        // Check for status changes
        if (oldTask.status !== updatedTask.status) {
          await workflowEngine.executeTriggers('task_status_changed', context, userId);
        }

        // Check for priority changes
        if (oldTask.priority !== updatedTask.priority) {
          await workflowEngine.executeTriggers('task_priority_changed', context, userId);
        }

        // Check for assignment changes
        if (oldTask.assigneeId !== updatedTask.assigneeId && updatedTask.assigneeId) {
          await workflowEngine.executeTriggers('task_assigned', context, userId);
        }
      } catch (workflowError) {
        // Don't fail the update if workflow execution fails
        console.error("Workflow execution error:", workflowError);
      }

      res.json(updatedTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Only creator, project owner, or admin can delete tasks
      const project = await storage.getProject(task.projectId);
      const canDelete = task.creatorId === userId || 
                       project?.ownerId === userId || 
                       user?.role === 'admin';
      
      if (!canDelete) {
        return res.status(403).json({ message: "Access denied" });
      }

      const success = await storage.deleteTask(id);
      if (!success) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Task comments routes
  app.get('/api/tasks/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check access
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === task.projectId) || 
                       task.assigneeId === userId;
      
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied" });
      }

      const comments = await storage.getTaskComments(id);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching task comments:", error);
      res.status(500).json({ message: "Failed to fetch task comments" });
    }
  });

  app.post('/api/tasks/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check access
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === task.projectId) || 
                       task.assigneeId === userId;
      
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied" });
      }

      const validatedData = insertTaskCommentSchema.parse({
        ...req.body,
        taskId: id,
        authorId: userId,
      });
      
      const comment = await storage.createTaskComment(validatedData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating task comment:", error);
      res.status(500).json({ message: "Failed to create task comment" });
    }
  });

  // User management routes (admin only)
  app.get('/api/users', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !['admin', 'manager'].includes(user.role || '')) {
        return res.status(403).json({ message: "Access denied" });
      }

      const { role } = req.query;
      let users: User[];
      
      if (role) {
        users = await storage.getUsersByRole(role as string);
      } else {
        // For now, return empty array. In a full implementation, you'd get all users
        users = [];
      }
      
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.put('/api/users/:id/role', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { role } = req.body;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Only admins can change user roles" });
      }

      if (!['admin', 'manager', 'employee', 'guest'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const updatedUser = await storage.updateUserRole(id, role);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Workflow automation routes
  const updateWorkflowRuleSchema = insertWorkflowRuleSchema.pick({
    name: true,
    description: true,
    isActive: true,
    triggerConditions: true,
    actionData: true,
  });

  app.get('/api/workflows', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const rules = await storage.getUserWorkflowRules(userId);
      res.json(rules);
    } catch (error) {
      console.error("Error fetching workflow rules:", error);
      res.status(500).json({ message: "Failed to fetch workflow rules" });
    }
  });

  app.get('/api/workflows/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const rule = await storage.getWorkflowRule(id);
      if (!rule) {
        return res.status(404).json({ message: "Workflow rule not found" });
      }

      // Check if user has access (creator only for now)
      if (rule.createdById !== userId) {
        const user = await storage.getUser(userId);
        if (user?.role !== 'admin') {
          return res.status(403).json({ message: "Access denied" });
        }
      }

      res.json(rule);
    } catch (error) {
      console.error("Error fetching workflow rule:", error);
      res.status(500).json({ message: "Failed to fetch workflow rule" });
    }
  });

  app.post('/api/workflows', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const validatedData = insertWorkflowRuleSchema.parse({
        ...req.body,
        createdById: userId,
      });
      
      const rule = await storage.createWorkflowRule(validatedData);
      res.status(201).json(rule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating workflow rule:", error);
      res.status(500).json({ message: "Failed to create workflow rule" });
    }
  });

  app.put('/api/workflows/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const rule = await storage.getWorkflowRule(id);
      if (!rule) {
        return res.status(404).json({ message: "Workflow rule not found" });
      }

      // Check permissions (creator or admin only)
      if (rule.createdById !== userId) {
        const user = await storage.getUser(userId);
        if (user?.role !== 'admin') {
          return res.status(403).json({ message: "Access denied" });
        }
      }

      const validatedData = updateWorkflowRuleSchema.partial().parse(req.body);
      const updatedRule = await storage.updateWorkflowRule(id, validatedData);
      
      if (!updatedRule) {
        return res.status(404).json({ message: "Workflow rule not found" });
      }

      res.json(updatedRule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating workflow rule:", error);
      res.status(500).json({ message: "Failed to update workflow rule" });
    }
  });

  app.delete('/api/workflows/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const rule = await storage.getWorkflowRule(id);
      if (!rule) {
        return res.status(404).json({ message: "Workflow rule not found" });
      }

      // Check permissions (creator or admin only)
      if (rule.createdById !== userId) {
        const user = await storage.getUser(userId);
        if (user?.role !== 'admin') {
          return res.status(403).json({ message: "Access denied" });
        }
      }

      const success = await storage.deleteWorkflowRule(id);
      if (!success) {
        return res.status(404).json({ message: "Workflow rule not found" });
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting workflow rule:", error);
      res.status(500).json({ message: "Failed to delete workflow rule" });
    }
  });

  app.get('/api/workflows/:id/executions', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const rule = await storage.getWorkflowRule(id);
      if (!rule) {
        return res.status(404).json({ message: "Workflow rule not found" });
      }

      // Check permissions (creator or admin only)
      if (rule.createdById !== userId) {
        const user = await storage.getUser(userId);
        if (user?.role !== 'admin') {
          return res.status(403).json({ message: "Access denied" });
        }
      }

      const executions = await storage.getWorkflowExecutions(id);
      res.json(executions);
    } catch (error) {
      console.error("Error fetching workflow executions:", error);
      res.status(500).json({ message: "Failed to fetch workflow executions" });
    }
  });

  // File attachment and object storage routes
  
  // Endpoint for getting upload URL for file attachments
  app.post('/api/objects/upload', isAuthenticated, async (req: any, res) => {
    try {
      const objectStorageService = new ObjectStorageService();
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error) {
      console.error("Error getting upload URL:", error);
      res.status(500).json({ error: "Failed to get upload URL" });
    }
  });

  // Endpoint for serving private/protected files
  app.get('/objects/:objectPath(*)', isAuthenticated, async (req, res) => {
    const userId = req.user?.claims?.sub;
    const objectStorageService = new ObjectStorageService();
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      const canAccess = await objectStorageService.canAccessObjectEntity({
        objectFile,
        userId: userId,
        requestedPermission: ObjectPermission.READ,
      });
      if (!canAccess) {
        return res.sendStatus(403);
      }
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error accessing object:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });

  // Task attachment routes
  app.post('/api/tasks/:taskId/attachments', isAuthenticated, async (req: any, res) => {
    try {
      const { taskId } = req.params;
      const userId = req.user.claims.sub;

      // Check if user has access to the task
      const task = await storage.getTask(taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check project access
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === task.projectId);
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied" });
      }

      const validatedData = insertTaskAttachmentSchema.parse({
        ...req.body,
        taskId,
        uploadedById: userId,
      });

      // Set ACL policy for the uploaded file
      if (req.body.uploadURL) {
        const objectStorageService = new ObjectStorageService();
        const objectPath = await objectStorageService.trySetObjectEntityAclPolicy(
          req.body.uploadURL,
          {
            owner: userId,
            visibility: "private",
            aclRules: [
              {
                group: { type: "USER_LIST", id: "task_members" },
                permission: ObjectPermission.READ,
              },
            ],
          }
        );
        validatedData.objectPath = objectPath;
      }

      const attachment = await storage.createTaskAttachment(validatedData);
      res.status(201).json(attachment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating task attachment:", error);
      res.status(500).json({ message: "Failed to create attachment" });
    }
  });

  app.get('/api/tasks/:taskId/attachments', isAuthenticated, async (req: any, res) => {
    try {
      const { taskId } = req.params;
      const userId = req.user.claims.sub;

      // Check if user has access to the task
      const task = await storage.getTask(taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check project access
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === task.projectId);
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied" });
      }

      const attachments = await storage.getTaskAttachments(taskId);
      res.json(attachments);
    } catch (error) {
      console.error("Error fetching task attachments:", error);
      res.status(500).json({ message: "Failed to fetch attachments" });
    }
  });

  app.delete('/api/tasks/:taskId/attachments/:attachmentId', isAuthenticated, async (req: any, res) => {
    try {
      const { taskId, attachmentId } = req.params;
      const userId = req.user.claims.sub;

      // Check if user has access to the task
      const task = await storage.getTask(taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check project access
      const userProjects = await storage.getUserProjects(userId);
      const hasAccess = userProjects.some(p => p.id === task.projectId);
      if (!hasAccess) {
        return res.status(403).json({ message: "Access denied" });
      }

      const success = await storage.deleteTaskAttachment(attachmentId);
      if (!success) {
        return res.status(404).json({ message: "Attachment not found" });
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting task attachment:", error);
      res.status(500).json({ message: "Failed to delete attachment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
