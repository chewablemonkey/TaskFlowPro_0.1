import { Storage, File } from "@google-cloud/storage";
import { Response } from "express";
import { randomUUID } from "crypto";
import {
  ObjectAclPolicy,
  ObjectPermission,
  canAccessObject,
  getObjectAclPolicy,
  setObjectAclPolicy,
} from "./objectAcl";

const REPLIT_SIDECAR_ENDPOINT = "http://127.0.0.1:1106";

// The object storage client is used to interact with the object storage service.
export const objectStorageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: {
        type: "json",
        subject_token_field_name: "access_token",
      },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
    Object.setPrototypeOf(this, ObjectNotFoundError.prototype);
  }
}

// The object storage service is used to interact with the object storage service.
export class ObjectStorageService {
  constructor() {}

  // Gets the public object search paths.
  getPublicObjectSearchPaths(): Array<string> {
    const pathsStr = process.env.PUBLIC_OBJECT_SEARCH_PATHS || "";
    const paths = Array.from(
      new Set(
        pathsStr
          .split(",")
          .map((path) => path.trim())
          .filter((path) => path.length > 0)
      )
    );
    if (paths.length === 0) {
      throw new Error(
        "PUBLIC_OBJECT_SEARCH_PATHS not set. Create a bucket in 'Object Storage' " +
          "tool and set PUBLIC_OBJECT_SEARCH_PATHS env var (comma-separated paths)."
      );
    }
    return paths;
  }

  // Gets the private object directory.
  getPrivateObjectDir(): string {
    const dir = process.env.PRIVATE_OBJECT_DIR;
    if (!dir) {
      throw new Error(
        "PRIVATE_OBJECT_DIR not set. Create a bucket in 'Object Storage' " +
          "tool and set PRIVATE_OBJECT_DIR env var."
      );
    }
    return dir;
  }

  // Gets the default bucket ID.
  getDefaultBucketId(): string {
    const bucketId = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
    if (!bucketId) {
      throw new Error(
        "DEFAULT_OBJECT_STORAGE_BUCKET_ID not set. Create a bucket in 'Object Storage' " +
          "tool and set DEFAULT_OBJECT_STORAGE_BUCKET_ID env var."
      );
    }
    return bucketId;
  }

  // Searches for a public object in the public object search paths.
  async searchPublicObject(filePath: string): Promise<File | null> {
    const paths = this.getPublicObjectSearchPaths();
    const bucketId = this.getDefaultBucketId();
    const bucket = objectStorageClient.bucket(bucketId);

    for (const path of paths) {
      const fullPath = `${path}/${filePath}`;
      const file = bucket.file(fullPath);
      const [exists] = await file.exists();
      if (exists) {
        return file;
      }
    }

    return null;
  }

  // Gets an object entity file from the object path.
  async getObjectEntityFile(objectPath: string): Promise<File> {
    const bucketId = this.getDefaultBucketId();
    const bucket = objectStorageClient.bucket(bucketId);
    
    // Remove leading slash if present
    const normalizedPath = objectPath.startsWith('/') ? objectPath.slice(1) : objectPath;
    const file = bucket.file(normalizedPath);
    
    const [exists] = await file.exists();
    if (!exists) {
      throw new ObjectNotFoundError();
    }
    
    return file;
  }

  // Gets a presigned URL for uploading an object entity.
  async getObjectEntityUploadURL(): Promise<string> {
    const bucketId = this.getDefaultBucketId();
    const privateDir = this.getPrivateObjectDir();
    const bucket = objectStorageClient.bucket(bucketId);
    
    // Generate unique filename
    const fileName = `${randomUUID()}`;
    const fullPath = `${privateDir}/${fileName}`;
    
    const file = bucket.file(fullPath);
    
    const [url] = await file.getSignedUrl({
      version: "v4",
      action: "write",
      expires: Date.now() + 15 * 60 * 1000, // 15 minutes
      contentType: "application/octet-stream",
    });
    
    return url;
  }

  // Normalizes the object entity path from a presigned URL.
  normalizeObjectEntityPath(uploadUrl: string): string {
    try {
      const url = new URL(uploadUrl);
      const pathParts = url.pathname.split('/');
      // Extract bucket name and object path
      if (pathParts.length >= 3) {
        return pathParts.slice(2).join('/');
      }
      throw new Error("Invalid upload URL format");
    } catch (error) {
      throw new Error(`Failed to normalize object path: ${error}`);
    }
  }

  // Sets the ACL policy for an object entity and returns the normalized path.
  async trySetObjectEntityAclPolicy(
    uploadUrl: string,
    aclPolicy: ObjectAclPolicy,
  ): Promise<string> {
    const objectPath = this.normalizeObjectEntityPath(uploadUrl);
    const file = await this.getObjectEntityFile(objectPath);
    await setObjectAclPolicy(file, aclPolicy);
    return objectPath;
  }

  // Checks if a user can access an object entity.
  async canAccessObjectEntity({
    objectFile,
    userId,
    requestedPermission,
  }: {
    objectFile: File;
    userId?: string;
    requestedPermission: ObjectPermission;
  }): Promise<boolean> {
    return await canAccessObject({
      userId,
      objectFile,
      requestedPermission,
    });
  }

  // Downloads an object to the response stream.
  downloadObject(objectFile: File, response: Response): void {
    const readStream = objectFile.createReadStream();
    
    readStream.on('error', (error) => {
      console.error('Error reading object:', error);
      if (!response.headersSent) {
        response.status(500).send('Error reading file');
      }
    });

    readStream.on('response', (gcsResponse) => {
      // Set appropriate headers
      if (gcsResponse.headers['content-type']) {
        response.setHeader('content-type', gcsResponse.headers['content-type']);
      }
      if (gcsResponse.headers['content-length']) {
        response.setHeader('content-length', gcsResponse.headers['content-length']);
      }
    });

    readStream.pipe(response);
  }
}