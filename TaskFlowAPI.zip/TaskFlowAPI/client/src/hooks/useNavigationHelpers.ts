import { useLocation } from 'wouter';
import { useCallback } from 'react';

// Navigation helpers for drill-down functionality
export function useNavigationHelpers() {
  const [, setLocation] = useLocation();

  // Navigate to projects page with filters
  const navigateToProjects = useCallback((filters?: {
    status?: string;
    search?: string;
  }) => {
    const params = new URLSearchParams();
    
    if (filters?.status && filters.status !== 'all') {
      params.set('status', filters.status);
    }
    if (filters?.search) {
      params.set('search', filters.search);
    }

    const queryString = params.toString();
    const url = queryString ? `/projects?${queryString}` : '/projects';
    setLocation(url);
  }, [setLocation]);

  // Navigate to tasks page with filters
  const navigateToTasks = useCallback((filters?: {
    status?: string;
    priority?: string;
    assignee?: string;
    project?: string;
    search?: string;
  }) => {
    const params = new URLSearchParams();
    
    if (filters?.status && filters.status !== 'all') {
      params.set('status', filters.status);
    }
    if (filters?.priority && filters.priority !== 'all') {
      params.set('priority', filters.priority);
    }
    if (filters?.assignee) {
      params.set('assignee', filters.assignee);
    }
    if (filters?.project) {
      params.set('project', filters.project);
    }
    if (filters?.search) {
      params.set('search', filters.search);
    }

    const queryString = params.toString();
    const url = queryString ? `/tasks?${queryString}` : '/tasks';
    setLocation(url);
  }, [setLocation]);

  // Navigate to team page with member focus
  const navigateToTeam = useCallback((memberId?: string) => {
    const url = memberId ? `/team?member=${memberId}` : '/team';
    setLocation(url);
  }, [setLocation]);

  // Navigate to project details
  const navigateToProjectDetails = useCallback((projectId: string) => {
    setLocation(`/projects/${projectId}`);
  }, [setLocation]);

  // Navigate to task details
  const navigateToTaskDetails = useCallback((taskId: string) => {
    setLocation(`/tasks/${taskId}`);
  }, [setLocation]);

  // Generic navigation function
  const navigateTo = useCallback((path: string, params?: Record<string, string>) => {
    if (params && Object.keys(params).length > 0) {
      const urlParams = new URLSearchParams(params);
      setLocation(`${path}?${urlParams.toString()}`);
    } else {
      setLocation(path);
    }
  }, [setLocation]);

  return {
    navigateToProjects,
    navigateToTasks,
    navigateToTeam,
    navigateToProjectDetails,
    navigateToTaskDetails,
    navigateTo,
  };
}

// Hook for extracting URL parameters (for the target pages to use)
export function useURLParams() {
  const [location] = useLocation();
  
  const getParams = useCallback(() => {
    const url = new URL(window.location.href);
    const params: Record<string, string> = {};
    
    url.searchParams.forEach((value, key) => {
      params[key] = value;
    });
    
    return params;
  }, [location]);

  const getParam = useCallback((key: string): string | null => {
    const url = new URL(window.location.href);
    return url.searchParams.get(key);
  }, [location]);

  return {
    getParams,
    getParam,
  };
}