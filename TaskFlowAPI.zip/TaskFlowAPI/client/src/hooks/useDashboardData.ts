import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo } from 'react';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';
import { useLocation } from 'wouter';

// Types for centralized dashboard data
interface DashboardStats {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  totalTasks: number;
  completedTasks: number;
  overdueTasks: number;
  teamMembers: number;
  completionRate: number;
}

interface DashboardAnalytics {
  projectStatusDistribution: Array<{
    status: string;
    count: number;
    percentage: number;
  }>;
  priorityDistribution: Array<{
    priority: 'low' | 'medium' | 'high';
    count: number;
    percentage: number;
  }>;
  teamProductivity: Array<{
    memberId: string;
    memberName: string;
    tasksCompleted: number;
    tasksInProgress: number;
    efficiency: number;
  }>;
  timelineData: Array<{
    date: string;
    planned: number;
    actual: number;
    remaining: number;
  }>;
  workloadData: Array<{
    assignee: string;
    tasks: number;
    hours: number;
    status: 'normal' | 'overloaded' | 'underutilized';
  }>;
}

interface ActivityItem {
  id: string;
  type: 'task_created' | 'task_completed' | 'task_assigned' | 'comment_added' | 'file_uploaded' | 'project_created';
  title: string;
  description: string;
  user: {
    id: string;
    name: string;
    avatar?: string;
  };
  timestamp: Date;
  metadata?: {
    projectId?: string;
    taskId?: string;
    projectName?: string;
    taskTitle?: string;
  };
}

interface TeamWorkloadData {
  members: Array<{
    id: string;
    name: string;
    allocatedHours: number;
    actualHours: number;
    utilization: number;
    availability: number;
    currentTasks: number;
  }>;
  overall: {
    totalCapacity: number;
    totalAllocated: number;
    averageUtilization: number;
  };
}

// Enhanced error handling for auth failures
const handleAuthError = (error: any, toast: any, setLocation: any) => {
  if (error?.message?.includes('401') || error?.status === 401) {
    toast({
      title: "Authentication Required",
      description: "Please log in to continue accessing the dashboard.",
      variant: "default",
    });
    // Graceful redirect instead of throwing
    setLocation('/login');
    return true;
  }
  return false;
};

// Main dashboard data hook with centralized fetching
export function useDashboardData(refreshInterval?: number) {
  const { user, isLoading: isAuthLoading } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  // Centralized dashboard stats
  const {
    data: stats,
    isLoading: isStatsLoading,
    error: statsError,
    refetch: refetchStats
  } = useQuery({
    queryKey: ['/api/dashboard', 'stats'],
    enabled: !!user && !isAuthLoading,
    staleTime: 2 * 60 * 1000, // 2 minutes
    refetchInterval: refreshInterval ? refreshInterval * 1000 : false,
    retry: (failureCount, error) => {
      // Don't retry on auth errors
      if (handleAuthError(error, toast, setLocation)) return false;
      return failureCount < 2;
    },
    onError: (error) => {
      if (!handleAuthError(error, toast, setLocation)) {
        console.error('Dashboard stats fetch error:', error);
      }
    }
  });

  // Centralized dashboard analytics
  const {
    data: analytics,
    isLoading: isAnalyticsLoading,
    error: analyticsError,
    refetch: refetchAnalytics
  } = useQuery({
    queryKey: ['/api/dashboard', 'analytics'],
    enabled: !!user && !isAuthLoading,
    staleTime: 2 * 60 * 1000, // 2 minutes
    refetchInterval: refreshInterval ? refreshInterval * 1000 : false,
    retry: (failureCount, error) => {
      if (handleAuthError(error, toast, setLocation)) return false;
      return failureCount < 2;
    },
    onError: (error) => {
      if (!handleAuthError(error, toast, setLocation)) {
        console.error('Dashboard analytics fetch error:', error);
      }
    }
  });

  // Activity feed data
  const {
    data: activities,
    isLoading: isActivitiesLoading,
    error: activitiesError,
    refetch: refetchActivities
  } = useQuery({
    queryKey: ['/api/dashboard', 'activities'],
    enabled: !!user && !isAuthLoading,
    staleTime: 1 * 60 * 1000, // 1 minute
    refetchInterval: refreshInterval ? refreshInterval * 1000 : false,
    retry: (failureCount, error) => {
      if (handleAuthError(error, toast, setLocation)) return false;
      return failureCount < 2;
    },
    onError: (error) => {
      if (!handleAuthError(error, toast, setLocation)) {
        console.error('Dashboard activities fetch error:', error);
      }
    }
  });

  // Team workload data
  const {
    data: teamWorkload,
    isLoading: isTeamWorkloadLoading,
    error: teamWorkloadError,
    refetch: refetchTeamWorkload
  } = useQuery({
    queryKey: ['/api/dashboard', 'team-workload'],
    enabled: !!user && !isAuthLoading,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchInterval: refreshInterval ? refreshInterval * 1000 : false,
    retry: (failureCount, error) => {
      if (handleAuthError(error, toast, setLocation)) return false;
      return failureCount < 2;
    },
    onError: (error) => {
      if (!handleAuthError(error, toast, setLocation)) {
        console.error('Dashboard team workload fetch error:', error);
      }
    }
  });

  // Memoized data transformations
  const memoizedData = useMemo(() => {
    const isLoading = isStatsLoading || isAnalyticsLoading || isActivitiesLoading || isTeamWorkloadLoading;
    const error = statsError || analyticsError || activitiesError || teamWorkloadError;

    return {
      stats: stats as DashboardStats,
      analytics: analytics as DashboardAnalytics,
      activities: (activities as ActivityItem[])?.slice(0, 20) || [],
      teamWorkload: teamWorkload as TeamWorkloadData,
      isLoading,
      error: error?.message || null,
      lastUpdated: new Date(),
    };
  }, [stats, analytics, activities, teamWorkload, isStatsLoading, isAnalyticsLoading, isActivitiesLoading, isTeamWorkloadLoading, statsError, analyticsError, activitiesError, teamWorkloadError]);

  // Centralized refetch function
  const refetchAll = () => {
    return Promise.all([
      refetchStats(),
      refetchAnalytics(),
      refetchActivities(),
      refetchTeamWorkload()
    ]);
  };

  // Cache invalidation helper
  const invalidateCache = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
  };

  return {
    ...memoizedData,
    refetch: refetchAll,
    invalidateCache,
  };
}

// Specialized hooks for individual widget types
export function useProjectStatusData(refreshInterval?: number) {
  const { analytics, isLoading, error, refetch } = useDashboardData(refreshInterval);
  
  return useMemo(() => ({
    data: analytics?.projectStatusDistribution || [],
    isLoading,
    error,
    refetch,
    lastUpdated: new Date(),
  }), [analytics?.projectStatusDistribution, isLoading, error, refetch]);
}

export function usePriorityDistributionData(refreshInterval?: number) {
  const { analytics, isLoading, error, refetch } = useDashboardData(refreshInterval);
  
  return useMemo(() => ({
    data: analytics?.priorityDistribution || [],
    isLoading,
    error,
    refetch,
    lastUpdated: new Date(),
  }), [analytics?.priorityDistribution, isLoading, error, refetch]);
}

export function useTeamProductivityData(refreshInterval?: number) {
  const { analytics, isLoading, error, refetch } = useDashboardData(refreshInterval);
  
  return useMemo(() => ({
    data: analytics?.teamProductivity || [],
    isLoading,
    error,
    refetch,
    lastUpdated: new Date(),
  }), [analytics?.teamProductivity, isLoading, error, refetch]);
}

export function useActivityFeedData(refreshInterval?: number, maxItems = 10) {
  const { activities, isLoading, error, refetch } = useDashboardData(refreshInterval);
  
  return useMemo(() => ({
    data: activities?.slice(0, maxItems) || [],
    isLoading,
    error,
    refetch,
    lastUpdated: new Date(),
  }), [activities, maxItems, isLoading, error, refetch]);
}

export function useTeamWorkloadData(refreshInterval?: number) {
  const { teamWorkload, isLoading, error, refetch } = useDashboardData(refreshInterval);
  
  return useMemo(() => ({
    data: teamWorkload || { members: [], overall: { totalCapacity: 0, totalAllocated: 0, averageUtilization: 0 } },
    isLoading,
    error,
    refetch,
    lastUpdated: new Date(),
  }), [teamWorkload, isLoading, error, refetch]);
}