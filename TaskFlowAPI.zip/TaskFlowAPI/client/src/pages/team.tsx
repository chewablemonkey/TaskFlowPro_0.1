import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Users, 
  Search, 
  Mail, 
  Edit, 
  Trash2,
  Plus
} from "lucide-react";
import { format } from "date-fns";
import AddUserModal from "@/components/modals/add-user-modal";
import Header from "@/components/layout/header";
import { useAuth } from "@/hooks/useAuth";
import type { User } from "@shared/schema";

const roleColors = {
  admin: "bg-red-500/10 text-red-500",
  manager: "bg-blue-500/10 text-blue-500", 
  employee: "bg-green-500/10 text-green-500",
  guest: "bg-gray-500/10 text-gray-500",
};

// Mock team data since we don't have a team members endpoint yet
const mockTeamMembers: (User & { projectCount: number; taskCount: number })[] = [
  {
    id: "1",
    email: "john.admin@company.com",
    firstName: "John",
    lastName: "Admin", 
    role: "admin",
    isActive: true,
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-01-15"),
    profileImageUrl: null,
    projectCount: 5,
    taskCount: 12
  },
  {
    id: "2", 
    email: "alice.manager@company.com",
    firstName: "Alice",
    lastName: "Smith",
    role: "manager",
    isActive: true,
    createdAt: new Date("2024-02-01"),
    updatedAt: new Date("2024-02-01"),
    profileImageUrl: null,
    projectCount: 3,
    taskCount: 8
  },
  {
    id: "3",
    email: "mike.employee@company.com", 
    firstName: "Mike",
    lastName: "Johnson",
    role: "employee",
    isActive: true,
    createdAt: new Date("2024-02-15"),
    updatedAt: new Date("2024-02-15"),
    profileImageUrl: null,
    projectCount: 2,
    taskCount: 15
  }
];

export default function Team() {
  const [showAddUser, setShowAddUser] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth() as { user: User | undefined };

  // For now, use mock data since we don't have team endpoints
  const isLoading = false;
  const teamMembers = mockTeamMembers;

  const filteredMembers = teamMembers?.filter(member => {
    const fullName = `${member.firstName || ''} ${member.lastName || ''}`.toLowerCase();
    const email = member.email?.toLowerCase() || "";
    const query = searchQuery.toLowerCase();
    
    return fullName.includes(query) || email.includes(query);
  }) || [];

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.charAt(0) || ""}${lastName?.charAt(0) || ""}`.toUpperCase();
  };

  const canManageUsers = user?.role === "admin" || user?.role === "manager";

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Team"
          description="Manage team members and their roles"
          showCreateButton={canManageUsers}
          onCreateClick={() => setShowAddUser(true)}
          createButtonText="Add Member"
        />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            <Card className="animate-pulse">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-muted rounded-full"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-muted rounded w-1/4 mb-2"></div>
                        <div className="h-3 bg-muted rounded w-1/3"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  return (
    <>
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Team"
          description="Manage team members and their roles"
          showCreateButton={canManageUsers}
          onCreateClick={() => setShowAddUser(true)}
          createButtonText="Add Member"
        />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            {/* Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Members</CardTitle>
                  <div className="text-2xl font-bold">{filteredMembers.length}</div>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Admins</CardTitle>
                  <div className="text-2xl font-bold text-red-500">
                    {filteredMembers.filter(m => m.role === 'admin').length}
                  </div>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Managers</CardTitle>
                  <div className="text-2xl font-bold text-blue-500">
                    {filteredMembers.filter(m => m.role === 'manager').length}
                  </div>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Employees</CardTitle>
                  <div className="text-2xl font-bold text-green-500">
                    {filteredMembers.filter(m => m.role === 'employee').length}
                  </div>
                </CardHeader>
              </Card>
            </div>

            {/* Search */}
            <div className="mb-6">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search team members..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-team"
                />
              </div>
            </div>

            {/* Team Members */}
            {filteredMembers.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {searchQuery ? "No members found" : "No team members yet"}
                </h3>
                <p className="text-muted-foreground mb-6">
                  {searchQuery 
                    ? "Try adjusting your search criteria"
                    : "Start building your team by adding members"
                  }
                </p>
                {!searchQuery && canManageUsers && (
                  <Button 
                    onClick={() => setShowAddUser(true)}
                    data-testid="button-add-first-member"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Team Member
                  </Button>
                )}
              </div>
            ) : (
              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="border-b border-border">
                        <tr>
                          <th className="text-left py-3 px-6 font-medium text-muted-foreground">Member</th>
                          <th className="text-left py-3 px-4 font-medium text-muted-foreground">Role</th>
                          <th className="text-left py-3 px-4 font-medium text-muted-foreground">Projects</th>
                          <th className="text-left py-3 px-4 font-medium text-muted-foreground">Tasks</th>
                          <th className="text-left py-3 px-4 font-medium text-muted-foreground">Joined</th>
                          <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                          {canManageUsers && (
                            <th className="text-left py-3 px-4 font-medium text-muted-foreground">Actions</th>
                          )}
                        </tr>
                      </thead>
                      <tbody>
                        {filteredMembers.map((member) => (
                          <tr key={member.id} className="border-b border-border hover:bg-accent/50" data-testid={`member-row-${member.id}`}>
                            <td className="py-4 px-6">
                              <div className="flex items-center space-x-3">
                                <Avatar className="w-10 h-10">
                                  <AvatarImage src={member.profileImageUrl || undefined} />
                                  <AvatarFallback className="bg-primary text-primary-foreground">
                                    {getInitials(member.firstName || undefined, member.lastName || undefined)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="min-w-0">
                                  <p className="font-medium text-foreground">
                                    {member.firstName && member.lastName 
                                      ? `${member.firstName} ${member.lastName}`
                                      : "Unnamed User"
                                    }
                                  </p>
                                  <div className="flex items-center text-sm text-muted-foreground">
                                    <Mail className="w-3 h-3 mr-1" />
                                    <span className="truncate">{member.email}</span>
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <Badge 
                                variant="outline"
                                className={roleColors[(member.role as keyof typeof roleColors) || 'employee']}
                              >
                                {(member.role?.charAt(0).toUpperCase() + (member.role?.slice(1) || '')) || 'Employee'}
                              </Badge>
                            </td>
                            <td className="py-4 px-4 text-foreground">
                              {member.projectCount || 0}
                            </td>
                            <td className="py-4 px-4 text-foreground">
                              {member.taskCount || 0}
                            </td>
                            <td className="py-4 px-4 text-muted-foreground">
                              {member.createdAt ? format(new Date(member.createdAt), "MMM dd, yyyy") : "Unknown"}
                            </td>
                            <td className="py-4 px-4">
                              <Badge 
                                variant="outline" 
                                className={member.isActive ? "bg-green-500/10 text-green-500" : "bg-gray-500/10 text-gray-500"}
                              >
                                {member.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                            </td>
                            {canManageUsers && (
                              <td className="py-4 px-4">
                                <div className="flex items-center space-x-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    data-testid={`button-edit-member-${member.id}`}
                                  >
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-destructive hover:text-destructive/80"
                                    data-testid={`button-delete-member-${member.id}`}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>

      {canManageUsers && (
        <AddUserModal 
          open={showAddUser} 
          onClose={() => setShowAddUser(false)} 
        />
      )}
    </>
  );
}
