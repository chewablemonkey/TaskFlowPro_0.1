import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useURLParams } from "@/hooks/useNavigationHelpers";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  CheckSquare, 
  Search, 
  Filter, 
  Plus, 
  Calendar, 
  User,
  AlertTriangle,
  Clock,
  Trash2,
  List,
  Columns
} from "lucide-react";
import { format, isAfter } from "date-fns";
import CreateTaskModal from "@/components/modals/create-task-modal";
import Header from "@/components/layout/header";
import { KanbanBoard } from "@/components/kanban/KanbanBoard";
import TaskDetailsModal from "@/components/task-details/TaskDetailsModal";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Task, Project } from "@shared/schema";

const priorityColors = {
  low: "bg-green-500/10 text-green-500",
  medium: "bg-yellow-500/10 text-yellow-500",
  high: "bg-red-500/10 text-red-500",
};

const statusColors = {
  todo: "bg-gray-500/10 text-gray-500",
  in_progress: "bg-blue-500/10 text-blue-500",
  completed: "bg-green-500/10 text-green-500",
  cancelled: "bg-red-500/10 text-red-500",
};

interface TaskWithProject extends Task {
  project: Project;
  assignee?: any;
}

export default function Tasks() {
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [showTaskDetails, setShowTaskDetails] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string>("");
  const [viewMode, setViewMode] = useState<"list" | "kanban">("list");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  const { toast } = useToast();
  const { getParam } = useURLParams();

  // Initialize filters from URL parameters
  useEffect(() => {
    const urlStatus = getParam('status');
    const urlPriority = getParam('priority');
    const urlAssignee = getParam('assignee');
    const urlProject = getParam('project');
    const urlSearch = getParam('search');
    
    if (urlStatus && urlStatus !== statusFilter) {
      setStatusFilter(urlStatus);
    }
    if (urlPriority && urlPriority !== priorityFilter) {
      setPriorityFilter(urlPriority);
    }
    if (urlSearch && urlSearch !== searchQuery) {
      setSearchQuery(urlSearch);
    }
    
    // Handle assignee and project filters if needed for navigation
    // These would require additional state and UI elements
  }, [getParam]);

  // Update URL when filters change
  const updateURL = (newStatus?: string, newPriority?: string, newSearch?: string) => {
    const params = new URLSearchParams();
    const status = newStatus ?? statusFilter;
    const priority = newPriority ?? priorityFilter;
    const search = newSearch ?? searchQuery;
    
    if (status && status !== 'all') {
      params.set('status', status);
    }
    if (priority && priority !== 'all') {
      params.set('priority', priority);
    }
    if (search) {
      params.set('search', search);
    }

    const queryString = params.toString();
    const newUrl = queryString ? `/tasks?${queryString}` : '/tasks';
    
    // Only update URL if it's different from current
    if (window.location.pathname + window.location.search !== newUrl) {
      window.history.replaceState({}, '', newUrl);
    }
  };

  const { data: tasks, isLoading } = useQuery<TaskWithProject[]>({
    queryKey: ["/api/tasks"],
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, updates }: { taskId: string; updates: Partial<Task> }) => {
      await apiRequest("PUT", `/api/tasks/${taskId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Task updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (taskId: string) => {
      await apiRequest("DELETE", `/api/tasks/${taskId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Task deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive",
      });
    },
  });

  const handleTaskStatusChange = (taskId: string, completed: boolean) => {
    updateTaskMutation.mutate({
      taskId,
      updates: { status: completed ? 'completed' : 'todo' }
    });
  };

  const handleStatusUpdate = (taskId: string, status: string) => {
    updateTaskMutation.mutate({
      taskId,
      updates: { status: status as Task['status'] }
    });
  };

  const handlePriorityUpdate = (taskId: string, priority: string) => {
    updateTaskMutation.mutate({
      taskId,
      updates: { priority: priority as Task['priority'] }
    });
  };

  const handleDeleteTask = (taskId: string, taskTitle: string) => {
    if (confirm(`Are you sure you want to delete "${taskTitle}"? This action cannot be undone.`)) {
      deleteTaskMutation.mutate(taskId);
    }
  };

  const handleTaskClick = (taskId: string) => {
    setSelectedTaskId(taskId);
    setShowTaskDetails(true);
  };

  const filteredTasks = tasks?.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || task.status === statusFilter;
    const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter;
    
    return matchesSearch && matchesStatus && matchesPriority;
  }) || [];

  const overdueTasks = filteredTasks.filter(task => 
    task.dueDate && 
    isAfter(new Date(), new Date(task.dueDate)) && 
    task.status !== 'completed'
  ).length;

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Tasks"
          description="Manage and track your tasks"
          showCreateButton
          onCreateClick={() => setShowCreateTask(true)}
          createButtonText="New Task"
        />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-4 h-4 bg-muted rounded"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <>
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Tasks"
          description="Manage and track your tasks"
          showCreateButton
          onCreateClick={() => setShowCreateTask(true)}
          createButtonText="New Task"
        >
          {/* View Toggle */}
          <div className="flex items-center border border-border rounded-lg p-1" data-testid="view-toggle">
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="px-3 py-1"
              data-testid="button-list-view"
            >
              <List className="w-4 h-4 mr-2" />
              List
            </Button>
            <Button
              variant={viewMode === "kanban" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("kanban")}
              className="px-3 py-1"
              data-testid="button-kanban-view"
            >
              <Columns className="w-4 h-4 mr-2" />
              Kanban
            </Button>
          </div>
        </Header>

        <main className="flex-1 overflow-y-auto p-6">
          {/* Render Kanban or List view based on viewMode */}
          {viewMode === "kanban" ? (
            <KanbanBoard onTaskClick={handleTaskClick} />
          ) : (
            <div className="max-w-7xl mx-auto">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription className="text-xs font-medium">Total Tasks</CardDescription>
                  <CardTitle className="text-xl">{filteredTasks.length}</CardTitle>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription className="text-xs font-medium">Completed</CardDescription>
                  <CardTitle className="text-xl text-green-600">
                    {filteredTasks.filter(task => task.status === 'completed').length}
                  </CardTitle>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription className="text-xs font-medium">Overdue</CardDescription>
                  <CardTitle className="text-xl text-red-600">{overdueTasks}</CardTitle>
                </CardHeader>
              </Card>
            </div>

            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => {
                    const newSearch = e.target.value;
                    setSearchQuery(newSearch);
                    updateURL(undefined, undefined, newSearch);
                  }}
                  className="pl-10"
                  data-testid="input-search-tasks"
                />
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={(value) => {
                  setStatusFilter(value);
                  updateURL(value, undefined, undefined);
                }}>
                  <SelectTrigger className="w-40" data-testid="select-status-filter">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="todo">To Do</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={priorityFilter} onValueChange={(value) => {
                  setPriorityFilter(value);
                  updateURL(undefined, value, undefined);
                }}>
                  <SelectTrigger className="w-40" data-testid="select-priority-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priority</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Tasks List */}
            {filteredTasks.length === 0 ? (
              <div className="text-center py-12">
                <CheckSquare className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {searchQuery || statusFilter !== "all" || priorityFilter !== "all" 
                    ? "No tasks found" 
                    : "No tasks yet"
                  }
                </h3>
                <p className="text-muted-foreground mb-6">
                  {searchQuery || statusFilter !== "all" || priorityFilter !== "all"
                    ? "Try adjusting your search criteria"
                    : "Create your first task to get started"
                  }
                </p>
                {!searchQuery && statusFilter === "all" && priorityFilter === "all" && (
                  <Button 
                    onClick={() => setShowCreateTask(true)}
                    data-testid="button-create-first-task"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Task
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredTasks.map((task) => {
                  const isOverdue = task.dueDate && 
                    isAfter(new Date(), new Date(task.dueDate)) && 
                    task.status !== 'completed';

                  return (
                    <Card 
                      key={task.id}
                      className={`hover:shadow-md transition-shadow cursor-pointer ${isOverdue ? 'border-destructive/50' : ''}`}
                      data-testid={`task-card-${task.id}`}
                      onClick={() => handleTaskClick(task.id)}
                      title="Click to view task details"
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-4">
                          <Checkbox
                            checked={task.status === 'completed'}
                            onCheckedChange={(checked) => handleTaskStatusChange(task.id, !!checked)}
                            disabled={updateTaskMutation.isPending}
                            data-testid={`task-checkbox-${task.id}`}
                          />
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2 mb-1">
                              <h3 className={`font-medium text-foreground ${
                                task.status === 'completed' ? 'line-through opacity-60' : ''
                              }`}>
                                {task.title}
                              </h3>
                              {isOverdue && (
                                <AlertTriangle className="w-4 h-4 text-destructive flex-shrink-0" />
                              )}
                            </div>
                            
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                              <div className="flex items-center space-x-1">
                                <User className="w-3 h-3" />
                                <span>{task.project.name}</span>
                              </div>
                              
                              {task.dueDate && (
                                <div className="flex items-center space-x-1">
                                  <Calendar className="w-3 h-3" />
                                  <span className={isOverdue ? 'text-destructive' : ''}>
                                    {format(new Date(task.dueDate), "MMM dd, yyyy")}
                                  </span>
                                </div>
                              )}

                              {task.estimatedHours && (
                                <div className="flex items-center space-x-1">
                                  <Clock className="w-3 h-3" />
                                  <span>{task.estimatedHours}h</span>
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center space-x-2">
                            {/* Status Selector */}
                            <Select 
                              value={task.status || 'todo'} 
                              onValueChange={(value) => handleStatusUpdate(task.id, value)}
                              disabled={updateTaskMutation.isPending}
                            >
                              <SelectTrigger 
                                className={`w-32 h-7 text-xs ${statusColors[task.status || 'todo']}`}
                                data-testid={`select-task-status-${task.id}`}
                              >
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="todo">To Do</SelectItem>
                                <SelectItem value="in_progress">In Progress</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                                <SelectItem value="cancelled">Cancelled</SelectItem>
                              </SelectContent>
                            </Select>
                            
                            {/* Priority Selector */}
                            <Select 
                              value={task.priority || 'medium'} 
                              onValueChange={(value) => handlePriorityUpdate(task.id, value)}
                              disabled={updateTaskMutation.isPending}
                            >
                              <SelectTrigger 
                                className={`w-24 h-7 text-xs ${priorityColors[task.priority || 'medium']}`}
                                data-testid={`select-task-priority-${task.id}`}
                              >
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="critical">Critical</SelectItem>
                              </SelectContent>
                            </Select>

                            {/* Delete Button */}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteTask(task.id, task.title)}
                              disabled={deleteTaskMutation.isPending}
                              className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                              data-testid={`button-delete-task-${task.id}`}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
            </div>
          )}
        </main>
      </div>

      <CreateTaskModal 
        open={showCreateTask} 
        onClose={() => setShowCreateTask(false)} 
      />

      <TaskDetailsModal
        taskId={selectedTaskId}
        open={showTaskDetails}
        onOpenChange={setShowTaskDetails}
      />
    </>
  );
}
