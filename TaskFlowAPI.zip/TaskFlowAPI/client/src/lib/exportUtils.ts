import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// CSV Export Utilities
export interface CSVExportData {
  headers: string[];
  rows: (string | number)[][];
  filename?: string;
}

export function exportToCSV(data: CSVExportData) {
  const { headers, rows, filename = 'dashboard-export.csv' } = data;
  
  // Create CSV content
  const csvContent = [
    headers.join(','),
    ...rows.map(row => 
      row.map(cell => {
        // Handle special characters and commas in cell content
        const cellString = String(cell);
        if (cellString.includes(',') || cellString.includes('"') || cellString.includes('\n')) {
          return `"${cellString.replace(/"/g, '""')}"`;
        }
        return cellString;
      }).join(',')
    )
  ].join('\n');

  // Create and trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
}

// Specialized export functions for different chart types
export function exportProjectStatusData(data: Array<{ status: string; count: number; percentage: number }>) {
  const csvData: CSVExportData = {
    headers: ['Status', 'Count', 'Percentage'],
    rows: data.map(item => [
      item.status.charAt(0).toUpperCase() + item.status.slice(1),
      item.count,
      `${item.percentage}%`
    ]),
    filename: `project-status-${new Date().toISOString().split('T')[0]}.csv`
  };
  
  exportToCSV(csvData);
}

export function exportPriorityDistributionData(data: Array<{ priority: string; count: number; percentage: number }>) {
  const csvData: CSVExportData = {
    headers: ['Priority', 'Count', 'Percentage'],
    rows: data.map(item => [
      item.priority.charAt(0).toUpperCase() + item.priority.slice(1),
      item.count,
      `${item.percentage}%`
    ]),
    filename: `priority-distribution-${new Date().toISOString().split('T')[0]}.csv`
  };
  
  exportToCSV(csvData);
}

export function exportTeamProductivityData(data: Array<{
  memberId: string;
  memberName: string;
  tasksCompleted: number;
  tasksInProgress: number;
  efficiency: number;
}>) {
  const csvData: CSVExportData = {
    headers: ['Member ID', 'Member Name', 'Tasks Completed', 'Tasks In Progress', 'Efficiency (%)'],
    rows: data.map(item => [
      item.memberId,
      item.memberName,
      item.tasksCompleted,
      item.tasksInProgress,
      `${item.efficiency}%`
    ]),
    filename: `team-productivity-${new Date().toISOString().split('T')[0]}.csv`
  };
  
  exportToCSV(csvData);
}

export function exportActivityFeedData(data: Array<{
  id: string;
  type: string;
  title: string;
  description: string;
  user: { name: string };
  timestamp: Date;
}>) {
  const csvData: CSVExportData = {
    headers: ['ID', 'Type', 'Title', 'Description', 'User', 'Timestamp'],
    rows: data.map(item => [
      item.id,
      item.type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      item.title,
      item.description,
      item.user.name,
      new Date(item.timestamp).toLocaleString()
    ]),
    filename: `activity-feed-${new Date().toISOString().split('T')[0]}.csv`
  };
  
  exportToCSV(csvData);
}

// Chart data export utility
export function exportChartData(chartData: any, filename?: string) {
  if (!chartData || !chartData.labels || !chartData.datasets) {
    throw new Error('Invalid chart data format');
  }

  const headers = ['Label', ...chartData.datasets.map((dataset: any) => dataset.label || 'Data')];
  const rows: (string | number)[][] = [];

  chartData.labels.forEach((label: string, index: number) => {
    const row = [label];
    chartData.datasets.forEach((dataset: any) => {
      row.push(dataset.data[index] || 0);
    });
    rows.push(row);
  });

  const csvData: CSVExportData = {
    headers,
    rows,
    filename: filename || `chart-data-${new Date().toISOString().split('T')[0]}.csv`
  };

  exportToCSV(csvData);
}

// PDF Export Utilities
export interface PDFExportOptions {
  title?: string;
  filename?: string;
  orientation?: 'portrait' | 'landscape';
  format?: 'a4' | 'letter';
  margin?: number;
  includeDate?: boolean;
}

export async function exportToPDF(elementId: string, options: PDFExportOptions = {}) {
  const {
    title = 'Dashboard Export',
    filename = 'dashboard-export.pdf',
    orientation = 'landscape',
    format = 'a4',
    margin = 20,
    includeDate = true
  } = options;

  try {
    const element = document.getElementById(elementId);
    if (!element) {
      throw new Error(`Element with ID '${elementId}' not found`);
    }

    // Create canvas from the element
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff'
    });

    // Calculate dimensions
    const imgWidth = orientation === 'landscape' ? 297 : 210; // A4 dimensions in mm
    const imgHeight = orientation === 'landscape' ? 210 : 297;
    
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    
    // Calculate scale to fit the image
    const scale = Math.min(
      (imgWidth - 2 * margin) / (canvasWidth * 0.264583), // Convert px to mm
      (imgHeight - 2 * margin - 20) / (canvasHeight * 0.264583) // Leave space for title
    );

    const scaledWidth = canvasWidth * 0.264583 * scale;
    const scaledHeight = canvasHeight * 0.264583 * scale;

    // Create PDF
    const pdf = new jsPDF(orientation, 'mm', format);
    
    // Add title
    pdf.setFontSize(16);
    pdf.text(title, margin, margin);
    
    // Add date if requested
    if (includeDate) {
      pdf.setFontSize(10);
      pdf.text(
        `Generated on: ${new Date().toLocaleDateString()}`,
        imgWidth - margin - 50,
        margin
      );
    }

    // Add image
    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(
      imgData,
      'PNG',
      margin,
      margin + 15,
      scaledWidth,
      scaledHeight
    );

    // Save the PDF
    pdf.save(filename);
    
    return true;
  } catch (error) {
    console.error('PDF export failed:', error);
    throw new Error('Failed to export PDF. Please try again.');
  }
}

// Dashboard layout export (enhanced version)
export function exportDashboardLayout(layout: any, includeData = false) {
  const exportData = {
    layout,
    metadata: {
      exportedAt: new Date().toISOString(),
      version: '1.0.0',
      includesData: includeData
    }
  };

  if (includeData) {
    // In a real implementation, this would include the current widget data
    exportData.metadata.includesData = true;
  }

  const dataStr = JSON.stringify(exportData, null, 2);
  const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
  
  const exportFileDefaultName = `dashboard-layout-${layout.name.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.json`;
  
  const linkElement = document.createElement('a');
  linkElement.setAttribute('href', dataUri);
  linkElement.setAttribute('download', exportFileDefaultName);
  linkElement.click();
}

// Utility to format data for export
export function formatDataForExport(data: any[], headers: string[]): CSVExportData {
  if (!Array.isArray(data) || data.length === 0) {
    return { headers, rows: [] };
  }

  const rows = data.map(item => {
    return headers.map(header => {
      const value = getNestedValue(item, header.toLowerCase().replace(/\s+/g, ''));
      return value !== undefined && value !== null ? String(value) : '';
    });
  });

  return { headers, rows };
}

// Helper function to get nested object values
function getNestedValue(obj: any, path: string): any {
  return path.split('.').reduce((current, key) => {
    return current && current[key] !== undefined ? current[key] : undefined;
  }, obj);
}

// Export utility for widget data with proper formatting
export function exportWidgetData(widgetTitle: string, data: any[], customFormatter?: (data: any[]) => CSVExportData) {
  if (customFormatter) {
    const csvData = customFormatter(data);
    csvData.filename = csvData.filename || `${widgetTitle.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.csv`;
    exportToCSV(csvData);
    return;
  }

  // Default formatting - extract all keys from first object
  if (data.length === 0) {
    throw new Error('No data available to export');
  }

  const headers = Object.keys(data[0]);
  const rows = data.map(item => headers.map(header => item[header] || ''));

  const csvData: CSVExportData = {
    headers: headers.map(h => h.charAt(0).toUpperCase() + h.slice(1).replace(/([A-Z])/g, ' $1')),
    rows,
    filename: `${widgetTitle.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.csv`
  };

  exportToCSV(csvData);
}