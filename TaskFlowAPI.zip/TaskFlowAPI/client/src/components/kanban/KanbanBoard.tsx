import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  DndContext, 
  DragEndEvent, 
  DragOverEvent,
  DragOverlay, 
  DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
  closestCorners 
} from "@dnd-kit/core";
import { arrayMove } from "@dnd-kit/sortable";
import { 
  Search, 
  Filter, 
  Plus, 
  Clock,
  PlayCircle,
  CheckCircle,
  Loader2
} from "lucide-react";
import { KanbanColumn } from "./KanbanColumn";
import { TaskCard } from "./TaskCard";
import CreateTaskModal from "@/components/modals/create-task-modal";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Task, Project, User } from "@shared/schema";

interface TaskWithDetails extends Task {
  project?: Project;
  assignee?: User;
}

interface KanbanBoardProps {
  className?: string;
  onTaskClick?: (taskId: string) => void;
}

const columns = [
  {
    id: 'todo',
    title: 'To Do',
    color: 'bg-gray-500',
    icon: Clock,
    status: 'todo' as const,
  },
  {
    id: 'in_progress',
    title: 'In Progress',
    color: 'bg-blue-500',
    icon: PlayCircle,
    status: 'in_progress' as const,
  },
  {
    id: 'completed',
    title: 'Completed',
    color: 'bg-green-500',
    icon: CheckCircle,
    status: 'completed' as const,
  },
];

export function KanbanBoard({ className = "", onTaskClick }: KanbanBoardProps) {
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [activeTask, setActiveTask] = useState<TaskWithDetails | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [projectFilter, setProjectFilter] = useState<string>("all");
  const [assigneeFilter, setAssigneeFilter] = useState<string>("all");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  
  const { toast } = useToast();

  // Sensors for drag and drop
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  // Fetch tasks and projects
  const { data: tasks, isLoading: tasksLoading } = useQuery<TaskWithDetails[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, updates }: { taskId: string; updates: Partial<Task> }) => {
      await apiRequest("PUT", `/api/tasks/${taskId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Task updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
      // Revert optimistic update if needed
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  // Filter and organize tasks
  const filteredTasks = useMemo(() => {
    if (!tasks) return [];
    
    return tasks.filter(task => {
      const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           task.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesProject = projectFilter === "all" || task.projectId === projectFilter;
      const matchesAssignee = assigneeFilter === "all" || task.assigneeId === assigneeFilter;
      const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter;
      
      return matchesSearch && matchesProject && matchesAssignee && matchesPriority;
    });
  }, [tasks, searchQuery, projectFilter, assigneeFilter, priorityFilter]);

  const tasksByStatus = useMemo(() => {
    const grouped = {
      todo: [] as TaskWithDetails[],
      in_progress: [] as TaskWithDetails[],
      completed: [] as TaskWithDetails[],
    };

    filteredTasks.forEach(task => {
      if (task.status === 'todo') {
        grouped.todo.push(task);
      } else if (task.status === 'in_progress') {
        grouped.in_progress.push(task);
      } else if (task.status === 'completed') {
        grouped.completed.push(task);
      }
      // Skip 'cancelled' tasks in kanban view
    });

    return grouped;
  }, [filteredTasks]);

  // Get available filter options
  const availableProjects = useMemo(() => {
    if (!projects || !tasks) return [];
    const projectsWithTasks = projects.filter(project => 
      tasks.some(task => task.projectId === project.id)
    );
    return projectsWithTasks;
  }, [projects, tasks]);

  const availableAssignees = useMemo(() => {
    if (!users || !tasks) return [];
    const assigneesWithTasks = users.filter(user => 
      tasks.some(task => task.assigneeId === user.id)
    );
    return assigneesWithTasks;
  }, [users, tasks]);

  function handleDragStart(event: DragStartEvent) {
    const { active } = event;
    const task = filteredTasks.find(t => t.id === active.id);
    setActiveTask(task || null);
  }

  function handleDragOver(event: DragOverEvent) {
    // Handle drag over logic if needed for visual feedback
  }

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    setActiveTask(null);

    if (!over) return;

    const activeTaskId = active.id as string;
    const overColumnId = over.id as string;

    // Find the task being moved
    const task = filteredTasks.find(t => t.id === activeTaskId);
    if (!task) return;

    // Determine the new status based on the column
    let newStatus: Task['status'];
    if (overColumnId === 'todo') {
      newStatus = 'todo';
    } else if (overColumnId === 'in_progress') {
      newStatus = 'in_progress';
    } else if (overColumnId === 'completed') {
      newStatus = 'completed';
    } else {
      return; // Invalid drop target
    }

    // Only update if status actually changed
    if (task.status !== newStatus) {
      // Optimistic update - update local state immediately
      queryClient.setQueryData<TaskWithDetails[]>(["/api/tasks"], (old) => {
        if (!old) return old;
        return old.map(t => t.id === activeTaskId ? { ...t, status: newStatus } : t);
      });

      // Update via API
      updateTaskMutation.mutate({
        taskId: activeTaskId,
        updates: { 
          status: newStatus
        },
      });
    }
  }

  if (tasksLoading || projectsLoading) {
    return (
      <div className={`flex items-center justify-center h-96 ${className}`}>
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading kanban board...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className={`space-y-6 ${className}`}>
        {/* Header with filters */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Kanban Board</h2>
              <p className="text-muted-foreground">Drag tasks between columns to update their status</p>
            </div>
            <Button 
              onClick={() => setShowCreateTask(true)}
              data-testid="button-create-task-kanban"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Task
            </Button>
          </div>

          {/* Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-wrap gap-4">
                {/* Search */}
                <div className="relative flex-1 min-w-[250px]">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search tasks..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-kanban"
                  />
                </div>

                {/* Project filter */}
                <Select value={projectFilter} onValueChange={setProjectFilter}>
                  <SelectTrigger className="w-48" data-testid="select-project-filter-kanban">
                    <SelectValue placeholder="All Projects" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Projects</SelectItem>
                    {availableProjects.map(project => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Assignee filter */}
                <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
                  <SelectTrigger className="w-48" data-testid="select-assignee-filter-kanban">
                    <SelectValue placeholder="All Assignees" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Assignees</SelectItem>
                    {availableAssignees.map(user => (
                      <SelectItem key={user.id} value={user.id}>
                        {`${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Priority filter */}
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-40" data-testid="select-priority-filter-kanban">
                    <SelectValue placeholder="All Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priority</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Kanban Board */}
        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-400px)] min-h-[600px]">
            {columns.map((column) => (
              <KanbanColumn
                key={column.id}
                id={column.id}
                title={column.title}
                tasks={tasksByStatus[column.status]}
                color={column.color}
                icon={column.icon}
                onTaskClick={onTaskClick}
              />
            ))}
          </div>

          {/* Drag Overlay */}
          <DragOverlay>
            {activeTask ? <TaskCard task={activeTask} isDragging /> : null}
          </DragOverlay>
        </DndContext>

        {/* Summary Stats */}
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-foreground">{tasksByStatus.todo.length}</p>
                <p className="text-sm text-muted-foreground">To Do</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">{tasksByStatus.in_progress.length}</p>
                <p className="text-sm text-muted-foreground">In Progress</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{tasksByStatus.completed.length}</p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{filteredTasks.length}</p>
                <p className="text-sm text-muted-foreground">Total Tasks</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Create Task Modal */}
      <CreateTaskModal
        open={showCreateTask}
        onClose={() => setShowCreateTask(false)}
      />
    </>
  );
}

export default KanbanBoard;