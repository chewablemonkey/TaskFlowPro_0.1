import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { CalendarDays, Clock, AlertTriangle, User } from "lucide-react";
import { format, isAfter } from "date-fns";
import type { Task, Project, User as UserType } from "@shared/schema";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface TaskWithDetails extends Task {
  project?: Project;
  assignee?: UserType;
}

interface TaskCardProps {
  task: TaskWithDetails;
  isDragging?: boolean;
  onClick?: (taskId: string) => void;
}

const priorityConfig = {
  low: { color: "bg-green-500/10 text-green-700 border-green-200", icon: Clock },
  medium: { color: "bg-yellow-500/10 text-yellow-700 border-yellow-200", icon: Clock },
  high: { color: "bg-red-500/10 text-red-700 border-red-200", icon: AlertTriangle },
};

export function TaskCard({ task, isDragging = false, onClick }: TaskCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const isOverdue = task.dueDate && isAfter(new Date(), new Date(task.dueDate)) && task.status !== 'completed';
  const PriorityIcon = priorityConfig[task.priority || 'medium'].icon;

  const handleClick = (e: React.MouseEvent) => {
    // Only trigger click if not dragging
    if (e.detail === 2 || e.type === 'dblclick') { // Double click
      e.stopPropagation();
      onClick?.(task.id);
    }
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      onClick={handleClick}
      onDoubleClick={handleClick}
      className={`cursor-grab active:cursor-grabbing transition-all hover:shadow-md ${
        isDragging ? 'opacity-50 shadow-lg rotate-3' : ''
      } ${isOverdue ? 'ring-2 ring-red-200' : ''} ${onClick ? 'hover:ring-1 hover:ring-primary/20' : ''}`}
      data-testid={`task-card-${task.id}`}
      title="Double-click to view details"
    >
      <CardContent className="p-4 space-y-3">
        {/* Header with priority and project */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 
              className="font-medium text-sm leading-tight text-foreground truncate" 
              title={task.title}
              data-testid={`task-title-${task.id}`}
            >
              {task.title}
            </h3>
            {task.project && (
              <p className="text-xs text-muted-foreground truncate mt-1" title={task.project.name}>
                {task.project.name}
              </p>
            )}
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            <Badge
              variant="outline"
              className={`text-xs px-2 py-0.5 ${priorityConfig[task.priority || 'medium'].color}`}
              data-testid={`task-priority-${task.id}`}
            >
              <PriorityIcon className="w-3 h-3 mr-1" />
              {task.priority || 'medium'}
            </Badge>
            {isOverdue && (
              <Badge variant="destructive" className="text-xs px-2 py-0.5">
                Overdue
              </Badge>
            )}
          </div>
        </div>

        {/* Description */}
        {task.description && (
          <p 
            className="text-xs text-muted-foreground line-clamp-2"
            title={task.description}
            data-testid={`task-description-${task.id}`}
          >
            {task.description}
          </p>
        )}

        {/* Footer with assignee and due date */}
        <div className="flex items-center justify-between text-xs">
          {/* Assignee */}
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {task.assignee ? (
              <>
                <Avatar className="w-5 h-5" data-testid={`task-assignee-avatar-${task.id}`}>
                  <AvatarImage src={task.assignee.profileImageUrl || ''} />
                  <AvatarFallback className="text-[10px] bg-primary/10">
                    {`${task.assignee.firstName || ''}${task.assignee.lastName || ''}`.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <span 
                  className="text-muted-foreground truncate"
                  title={`${task.assignee.firstName || ''} ${task.assignee.lastName || ''}`.trim()}
                  data-testid={`task-assignee-name-${task.id}`}
                >
                  {`${task.assignee.firstName || ''} ${task.assignee.lastName || ''}`.trim()}
                </span>
              </>
            ) : (
              <div className="flex items-center gap-2 text-muted-foreground">
                <User className="w-4 h-4" />
                <span className="text-xs">Unassigned</span>
              </div>
            )}
          </div>

          {/* Due date */}
          {task.dueDate && (
            <div className="flex items-center gap-1 flex-shrink-0">
              <CalendarDays className={`w-3 h-3 ${isOverdue ? 'text-red-500' : 'text-muted-foreground'}`} />
              <span 
                className={`text-xs ${isOverdue ? 'text-red-500 font-medium' : 'text-muted-foreground'}`}
                data-testid={`task-due-date-${task.id}`}
              >
                {format(new Date(task.dueDate), "MMM dd")}
              </span>
            </div>
          )}
        </div>

        {/* Time tracking if available */}
        {(task.estimatedHours || task.actualHours) && (
          <div className="flex items-center gap-4 text-xs text-muted-foreground pt-2 border-t">
            {task.estimatedHours && (
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Est: {task.estimatedHours}h</span>
              </div>
            )}
            {task.actualHours && (
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Actual: {task.actualHours}h</span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default TaskCard;