import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TaskCard } from "./TaskCard";
import type { Task, Project, User } from "@shared/schema";
import { useDroppable } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";

interface TaskWithDetails extends Task {
  project?: Project;
  assignee?: User;
}

interface KanbanColumnProps {
  id: string;
  title: string;
  tasks: TaskWithDetails[];
  color: string;
  icon: React.ComponentType<{ className?: string }>;
  onTaskClick?: (taskId: string) => void;
}

export function KanbanColumn({ id, title, tasks, color, icon: Icon, onTaskClick }: KanbanColumnProps) {
  const { setNodeRef, isOver } = useDroppable({
    id,
  });

  return (
    <div className="flex flex-col h-full">
      {/* Column Header */}
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-lg ${color}`}>
            <Icon className="w-4 h-4 text-white" />
          </div>
          <h3 className="font-semibold text-foreground">{title}</h3>
        </div>
        <Badge variant="secondary" className="text-xs">
          {tasks.length}
        </Badge>
      </div>

      {/* Droppable Area */}
      <Card className="flex-1 flex flex-col min-h-[200px]">
        <CardContent className="flex-1 p-3">
          <div
            ref={setNodeRef}
            className={`flex-1 min-h-full rounded-lg transition-colors ${
              isOver ? 'bg-primary/5 border-2 border-dashed border-primary' : ''
            }`}
            data-testid={`kanban-column-${id}`}
          >
            <SortableContext items={tasks.map(task => task.id)} strategy={verticalListSortingStrategy}>
              <div className="space-y-3">
                {tasks.length === 0 ? (
                  <div className="flex items-center justify-center h-24 text-muted-foreground text-sm border-2 border-dashed border-muted rounded-lg">
                    <div className="text-center">
                      <Icon className="w-6 h-6 mx-auto mb-2 opacity-50" />
                      <p>No {title.toLowerCase()} tasks</p>
                    </div>
                  </div>
                ) : (
                  tasks.map((task) => (
                    <TaskCard key={task.id} task={task} onClick={onTaskClick} />
                  ))
                )}
              </div>
            </SortableContext>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default KanbanColumn;