import { Button } from "@/components/ui/button";
import { Bell, Plus } from "lucide-react";

interface HeaderProps {
  title: string;
  description?: string;
  showCreateButton?: boolean;
  onCreateClick?: () => void;
  createButtonText?: string;
  children?: React.ReactNode;
}

export default function Header({ 
  title, 
  description, 
  showCreateButton = false, 
  onCreateClick,
  createButtonText = "New Project",
  children
}: HeaderProps) {
  return (
    <header className="bg-card border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">{title}</h1>
          {description && (
            <p className="text-muted-foreground">{description}</p>
          )}
        </div>
        <div className="flex items-center space-x-4">
          {children}
          <Button
            variant="ghost"
            size="sm"
            className="relative p-2"
            data-testid="button-notifications"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-destructive rounded-full"></span>
          </Button>
          {showCreateButton && (
            <Button 
              onClick={onCreateClick}
              data-testid="button-create"
            >
              <Plus className="w-4 h-4 mr-2" />
              {createButtonText}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
