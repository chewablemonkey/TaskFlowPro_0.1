import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Upload, 
  Download, 
  Trash2, 
  FileText, 
  Image as ImageIcon, 
  File,
  Video,
  Archive,
  Music
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ObjectUploader } from "@/components/ObjectUploader";
import type { TaskAttachment, User } from "@shared/schema";
import type { UploadResult } from "@uppy/core";

interface AttachmentWithUser extends TaskAttachment {
  uploadedBy: User;
}

interface FileAttachmentsProps {
  taskId: string;
}

// File type configurations
const fileTypeConfig = {
  image: { icon: ImageIcon, color: "bg-green-500/10 text-green-600", extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'] },
  video: { icon: Video, color: "bg-purple-500/10 text-purple-600", extensions: ['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv'] },
  audio: { icon: Music, color: "bg-orange-500/10 text-orange-600", extensions: ['mp3', 'wav', 'ogg', 'aac', 'flac'] },
  document: { icon: FileText, color: "bg-blue-500/10 text-blue-600", extensions: ['pdf', 'doc', 'docx', 'txt', 'rtf'] },
  archive: { icon: Archive, color: "bg-yellow-500/10 text-yellow-600", extensions: ['zip', 'rar', '7z', 'tar', 'gz'] },
  default: { icon: File, color: "bg-gray-500/10 text-gray-600", extensions: [] },
};

function getFileType(fileName: string): keyof typeof fileTypeConfig {
  const extension = fileName.split('.').pop()?.toLowerCase();
  if (!extension) return 'default';
  
  for (const [type, config] of Object.entries(fileTypeConfig)) {
    if (type !== 'default' && config.extensions.includes(extension)) {
      return type as keyof typeof fileTypeConfig;
    }
  }
  return 'default';
}

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export default function FileAttachments({ taskId }: FileAttachmentsProps) {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const { data: attachments, isLoading } = useQuery<AttachmentWithUser[]>({
    queryKey: ["/api/tasks", taskId, "attachments"],
  });

  const deleteAttachmentMutation = useMutation({
    mutationFn: async (attachmentId: string) => {
      await apiRequest("DELETE", `/api/tasks/${taskId}/attachments/${attachmentId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId, "attachments"] });
      toast({
        title: "Success",
        description: "File deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete file",
        variant: "destructive",
      });
    },
  });

  const handleGetUploadParameters = async () => {
    try {
      const response = await apiRequest("POST", "/api/objects/upload", {});
      return {
        method: "PUT" as const,
        url: response.uploadURL,
      };
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get upload URL",
        variant: "destructive",
      });
      throw error;
    }
  };

  const handleUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    try {
      setIsUploading(true);
      
      for (const file of result.successful) {
        await apiRequest("POST", `/api/tasks/${taskId}/attachments`, {
          fileName: file.name,
          originalFileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
          uploadURL: file.uploadURL,
        });
      }

      queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId, "attachments"] });
      toast({
        title: "Success",
        description: `${result.successful.length} file(s) uploaded successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save file information",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDownload = (attachment: AttachmentWithUser) => {
    const downloadUrl = `/objects/${attachment.objectPath}`;
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = attachment.originalFileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDeleteAttachment = (attachmentId: string, fileName: string) => {
    if (confirm(`Are you sure you want to delete "${fileName}"?`)) {
      deleteAttachmentMutation.mutate(attachmentId);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col" data-testid="file-attachments">
      {/* Upload Section */}
      <div className="flex-shrink-0 mb-4">
        <ObjectUploader
          maxNumberOfFiles={5}
          maxFileSize={50 * 1024 * 1024} // 50MB
          onGetUploadParameters={handleGetUploadParameters}
          onComplete={handleUploadComplete}
          buttonClassName="w-full"
        >
          <div className="flex items-center justify-center gap-2 py-8 border-2 border-dashed border-muted-foreground/25 rounded-lg hover:border-muted-foreground/50 transition-colors">
            <Upload className="w-5 h-5" />
            <span>{isUploading ? "Uploading..." : "Upload Files"}</span>
          </div>
        </ObjectUploader>
      </div>

      {/* Attachments List */}
      <ScrollArea className="flex-1">
        <div className="space-y-3">
          {attachments?.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground text-sm">No files attached</p>
              <p className="text-muted-foreground text-xs mt-1">Upload files to share with your team</p>
            </div>
          ) : (
            attachments?.map((attachment) => {
              const fileType = getFileType(attachment.fileName);
              const config = fileTypeConfig[fileType];
              const FileIcon = config.icon;

              return (
                <Card key={attachment.id} className="group hover:shadow-md transition-shadow" data-testid={`attachment-${attachment.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${config.color} flex-shrink-0`}>
                        <FileIcon className="w-6 h-6" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <h4 className="font-medium text-sm truncate" title={attachment.originalFileName} data-testid={`attachment-name-${attachment.id}`}>
                            {attachment.originalFileName}
                          </h4>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDownload(attachment)}
                              className="h-8 w-8 p-0"
                              data-testid={`button-download-${attachment.id}`}
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDeleteAttachment(attachment.id, attachment.originalFileName)}
                              className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                              data-testid={`button-delete-attachment-${attachment.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="outline" className="text-xs" data-testid={`attachment-size-${attachment.id}`}>
                            {formatFileSize(attachment.fileSize)}
                          </Badge>
                          <span>•</span>
                          <div className="flex items-center gap-1">
                            <Avatar className="w-4 h-4">
                              <AvatarImage src={attachment.uploadedBy.profileImageUrl || ''} />
                              <AvatarFallback className="text-[8px]">
                                {`${attachment.uploadedBy.firstName || ''}${attachment.uploadedBy.lastName || ''}`.slice(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span data-testid={`attachment-uploader-${attachment.id}`}>
                              {`${attachment.uploadedBy.firstName || ''} ${attachment.uploadedBy.lastName || ''}`.trim() || attachment.uploadedBy.email}
                            </span>
                          </div>
                          <span>•</span>
                          <span data-testid={`attachment-uploaded-time-${attachment.id}`}>
                            {formatDistanceToNow(new Date(attachment.createdAt))} ago
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}