import { useQuery } from "@tanstack/react-query";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  MessageSquare, 
  Paperclip, 
  Edit, 
  UserPlus, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  Calendar,
  Target,
  User
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import type { TaskComment, TaskAttachment, User as UserType } from "@shared/schema";

interface CommentWithAuthor extends TaskComment {
  author: UserType;
}

interface AttachmentWithUser extends TaskAttachment {
  uploadedBy: UserType;
}

interface ActivityTimelineProps {
  taskId: string;
}

interface ActivityItem {
  id: string;
  type: 'comment' | 'attachment' | 'status_change' | 'priority_change' | 'assignment' | 'due_date' | 'creation' | 'edit';
  timestamp: string;
  user: UserType;
  content: string;
  details?: string;
  metadata?: any;
}

const activityConfig = {
  comment: { 
    icon: MessageSquare, 
    color: "bg-blue-500/10 text-blue-600",
    label: "commented"
  },
  attachment: { 
    icon: Paperclip, 
    color: "bg-green-500/10 text-green-600",
    label: "uploaded"
  },
  status_change: { 
    icon: CheckCircle, 
    color: "bg-purple-500/10 text-purple-600",
    label: "changed status"
  },
  priority_change: { 
    icon: AlertTriangle, 
    color: "bg-orange-500/10 text-orange-600",
    label: "changed priority"
  },
  assignment: { 
    icon: UserPlus, 
    color: "bg-cyan-500/10 text-cyan-600",
    label: "assigned"
  },
  due_date: { 
    icon: Calendar, 
    color: "bg-red-500/10 text-red-600",
    label: "updated due date"
  },
  creation: { 
    icon: Target, 
    color: "bg-gray-500/10 text-gray-600",
    label: "created task"
  },
  edit: { 
    icon: Edit, 
    color: "bg-yellow-500/10 text-yellow-600",
    label: "edited"
  },
};

export default function ActivityTimeline({ taskId }: ActivityTimelineProps) {
  const { data: comments, isLoading: commentsLoading } = useQuery<CommentWithAuthor[]>({
    queryKey: ["/api/tasks", taskId, "comments"],
  });

  const { data: attachments, isLoading: attachmentsLoading } = useQuery<AttachmentWithUser[]>({
    queryKey: ["/api/tasks", taskId, "attachments"],
  });

  const isLoading = commentsLoading || attachmentsLoading;

  // Create activity timeline from comments and attachments
  const activities: ActivityItem[] = [];

  // Add comments as activities
  comments?.forEach((comment) => {
    activities.push({
      id: `comment-${comment.id}`,
      type: 'comment',
      timestamp: comment.createdAt,
      user: comment.author,
      content: comment.content,
    });
  });

  // Add attachments as activities
  attachments?.forEach((attachment) => {
    activities.push({
      id: `attachment-${attachment.id}`,
      type: 'attachment',
      timestamp: attachment.createdAt,
      user: attachment.uploadedBy,
      content: attachment.originalFileName,
      details: `${(attachment.fileSize / 1024 / 1024).toFixed(2)} MB`,
    });
  });

  // Sort activities by timestamp (newest first)
  activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className="text-center py-8" data-testid="activity-timeline-empty">
        <p className="text-muted-foreground text-sm">No activity yet</p>
        <p className="text-muted-foreground text-xs mt-1">Activity will appear here as you work on this task</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-full" data-testid="activity-timeline">
      <div className="space-y-4 pr-4">
        {activities.map((activity, index) => {
          const config = activityConfig[activity.type];
          const ActivityIcon = config.icon;
          const isLast = index === activities.length - 1;

          return (
            <div key={activity.id} className="relative" data-testid={`activity-${activity.id}`}>
              {/* Timeline line */}
              {!isLast && (
                <div className="absolute left-6 top-12 w-px h-full bg-border"></div>
              )}
              
              <div className="flex items-start gap-3">
                {/* Icon */}
                <div className={`p-2 rounded-full ${config.color} flex-shrink-0 relative z-10`}>
                  <ActivityIcon className="w-4 h-4" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <Card className="border-l-4 border-l-primary/20">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <Avatar className="w-6 h-6" data-testid={`activity-user-avatar-${activity.id}`}>
                            <AvatarImage src={activity.user.profileImageUrl || ''} />
                            <AvatarFallback className="text-xs">
                              {`${activity.user.firstName || ''}${activity.user.lastName || ''}`.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-sm truncate" data-testid={`activity-user-name-${activity.id}`}>
                            {`${activity.user.firstName || ''} ${activity.user.lastName || ''}`.trim() || activity.user.email}
                          </span>
                          <span className="text-sm text-muted-foreground">{config.label}</span>
                          {activity.details && (
                            <Badge variant="outline" className="text-xs">
                              {activity.details}
                            </Badge>
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground whitespace-nowrap" data-testid={`activity-timestamp-${activity.id}`}>
                          {formatDistanceToNow(new Date(activity.timestamp))} ago
                        </span>
                      </div>

                      {/* Activity content */}
                      <div className="text-sm text-foreground" data-testid={`activity-content-${activity.id}`}>
                        {activity.type === 'comment' ? (
                          <div className="bg-muted/50 p-3 rounded-lg whitespace-pre-wrap">
                            {activity.content}
                          </div>
                        ) : activity.type === 'attachment' ? (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Paperclip className="w-4 h-4" />
                            <span className="font-medium">{activity.content}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">{activity.content}</span>
                        )}
                      </div>

                      {/* Absolute timestamp for detailed view */}
                      <div className="text-xs text-muted-foreground mt-2 opacity-70">
                        {format(new Date(activity.timestamp), "MMM dd, yyyy 'at' HH:mm")}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </ScrollArea>
  );
}