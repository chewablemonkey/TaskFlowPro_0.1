import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  CalendarDays, 
  Clock, 
  User, 
  AlertTriangle, 
  CheckCircle, 
  Edit2, 
  Save, 
  X,
  MessageSquare,
  Paperclip,
  Activity,
  MoreVertical
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Task, Project, User as UserType } from "@shared/schema";
import CommentThread from "./CommentThread";
import FileAttachments from "./FileAttachments";
import ActivityTimeline from "./ActivityTimeline";

interface TaskWithDetails extends Task {
  project?: Project;
  assignee?: UserType;
  creator?: UserType;
}

interface TaskDetailsModalProps {
  taskId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const priorityConfig = {
  low: { color: "bg-green-500/10 text-green-700 border-green-200", icon: Clock },
  medium: { color: "bg-yellow-500/10 text-yellow-700 border-yellow-200", icon: Clock },
  high: { color: "bg-red-500/10 text-red-700 border-red-200", icon: AlertTriangle },
};

const statusConfig = {
  todo: { color: "bg-gray-500/10 text-gray-700 border-gray-200", label: "To Do" },
  in_progress: { color: "bg-blue-500/10 text-blue-700 border-blue-200", label: "In Progress" },
  completed: { color: "bg-green-500/10 text-green-700 border-green-200", label: "Completed" },
  cancelled: { color: "bg-red-500/10 text-red-700 border-red-200", label: "Cancelled" },
};

export default function TaskDetailsModal({ taskId, open, onOpenChange }: TaskDetailsModalProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<Task>>({});
  const { toast } = useToast();

  const { data: task, isLoading } = useQuery<TaskWithDetails>({
    queryKey: ["/api/tasks", taskId],
    enabled: open && !!taskId,
  });

  const { data: users } = useQuery<UserType[]>({
    queryKey: ["/api/team/users"],
    enabled: open,
  });

  const updateTaskMutation = useMutation({
    mutationFn: async (updates: Partial<Task>) => {
      await apiRequest("PUT", `/api/tasks/${taskId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId] });
      setIsEditing(false);
      toast({
        title: "Success",
        description: "Task updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (task && isEditing) {
      setEditData({
        title: task.title,
        description: task.description || "",
        status: task.status,
        priority: task.priority,
        assigneeId: task.assigneeId || "",
        dueDate: task.dueDate || "",
        estimatedHours: task.estimatedHours || 0,
        actualHours: task.actualHours || 0,
      });
    }
  }, [task, isEditing]);

  const handleSave = () => {
    if (!editData.title?.trim()) {
      toast({
        title: "Error",
        description: "Task title is required",
        variant: "destructive",
      });
      return;
    }
    updateTaskMutation.mutate(editData);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditData({});
  };

  if (isLoading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!task) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <div className="flex items-center justify-center h-64">
            <p className="text-muted-foreground">Task not found</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const PriorityIcon = priorityConfig[task.priority || 'medium'].icon;
  const isOverdue = task.dueDate && new Date() > new Date(task.dueDate) && task.status !== 'completed';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col" data-testid="task-details-modal">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              {isEditing ? (
                <Input
                  value={editData.title || ""}
                  onChange={(e) => setEditData({ ...editData, title: e.target.value })}
                  className="text-lg font-semibold border-none px-0 focus-visible:ring-0"
                  placeholder="Task title"
                  data-testid="input-task-title"
                />
              ) : (
                <DialogTitle className="text-lg font-semibold pr-4" data-testid="text-task-title">
                  {task.title}
                </DialogTitle>
              )}
              {task.project && (
                <p className="text-sm text-muted-foreground mt-1" data-testid="text-project-name">
                  {task.project.name}
                </p>
              )}
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {isEditing ? (
                <>
                  <Button size="sm" onClick={handleSave} disabled={updateTaskMutation.isPending} data-testid="button-save-task">
                    <Save className="w-4 h-4 mr-1" />
                    Save
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleCancel} data-testid="button-cancel-edit">
                    <X className="w-4 h-4 mr-1" />
                    Cancel
                  </Button>
                </>
              ) : (
                <Button size="sm" variant="outline" onClick={() => setIsEditing(true)} data-testid="button-edit-task">
                  <Edit2 className="w-4 h-4 mr-1" />
                  Edit
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex gap-6">
          {/* Main Content */}
          <div className="flex-1 overflow-hidden flex flex-col">
            {/* Task Details Section */}
            <div className="flex-shrink-0 space-y-4 pb-4">
              {/* Status and Priority */}
              <div className="flex items-center gap-4">
                {isEditing ? (
                  <>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-muted-foreground">Status</label>
                      <Select value={editData.status} onValueChange={(value) => setEditData({ ...editData, status: value as Task['status'] })}>
                        <SelectTrigger className="w-32" data-testid="select-task-status">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todo">To Do</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-muted-foreground">Priority</label>
                      <Select value={editData.priority} onValueChange={(value) => setEditData({ ...editData, priority: value as Task['priority'] })}>
                        <SelectTrigger className="w-24" data-testid="select-task-priority">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                ) : (
                  <>
                    <Badge
                      variant="outline"
                      className={`${statusConfig[task.status || 'todo'].color}`}
                      data-testid={`badge-task-status-${task.status}`}
                    >
                      {statusConfig[task.status || 'todo'].label}
                    </Badge>
                    <Badge
                      variant="outline"
                      className={`${priorityConfig[task.priority || 'medium'].color}`}
                      data-testid={`badge-task-priority-${task.priority}`}
                    >
                      <PriorityIcon className="w-3 h-3 mr-1" />
                      {task.priority || 'medium'}
                    </Badge>
                    {isOverdue && (
                      <Badge variant="destructive" data-testid="badge-task-overdue">
                        Overdue
                      </Badge>
                    )}
                  </>
                )}
              </div>

              {/* Assignee and Due Date */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-muted-foreground">Assignee</label>
                  {isEditing ? (
                    <Select value={editData.assigneeId} onValueChange={(value) => setEditData({ ...editData, assigneeId: value })}>
                      <SelectTrigger data-testid="select-task-assignee">
                        <SelectValue placeholder="Unassigned" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Unassigned</SelectItem>
                        {users?.map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            {`${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="flex items-center gap-2">
                      {task.assignee ? (
                        <>
                          <Avatar className="w-6 h-6" data-testid="avatar-task-assignee">
                            <AvatarImage src={task.assignee.profileImageUrl || ''} />
                            <AvatarFallback className="text-xs">
                              {`${task.assignee.firstName || ''}${task.assignee.lastName || ''}`.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-sm" data-testid="text-assignee-name">
                            {`${task.assignee.firstName || ''} ${task.assignee.lastName || ''}`.trim()}
                          </span>
                        </>
                      ) : (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <User className="w-4 h-4" />
                          <span className="text-sm">Unassigned</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-muted-foreground">Due Date</label>
                  {isEditing ? (
                    <Input
                      type="datetime-local"
                      value={editData.dueDate ? new Date(editData.dueDate).toISOString().slice(0, 16) : ""}
                      onChange={(e) => setEditData({ ...editData, dueDate: e.target.value ? new Date(e.target.value).toISOString() : "" })}
                      data-testid="input-task-due-date"
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      {task.dueDate ? (
                        <>
                          <CalendarDays className={`w-4 h-4 ${isOverdue ? 'text-red-500' : 'text-muted-foreground'}`} />
                          <span className={`text-sm ${isOverdue ? 'text-red-500 font-medium' : ''}`} data-testid="text-task-due-date">
                            {format(new Date(task.dueDate), "MMM dd, yyyy 'at' HH:mm")}
                          </span>
                        </>
                      ) : (
                        <span className="text-sm text-muted-foreground">No due date</span>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Time Tracking */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-muted-foreground">Estimated Hours</label>
                  {isEditing ? (
                    <Input
                      type="number"
                      min="0"
                      step="0.5"
                      value={editData.estimatedHours || ""}
                      onChange={(e) => setEditData({ ...editData, estimatedHours: parseInt(e.target.value) || 0 })}
                      data-testid="input-estimated-hours"
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm" data-testid="text-estimated-hours">
                        {task.estimatedHours ? `${task.estimatedHours}h` : 'Not set'}
                      </span>
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-muted-foreground">Actual Hours</label>
                  {isEditing ? (
                    <Input
                      type="number"
                      min="0"
                      step="0.5"
                      value={editData.actualHours || ""}
                      onChange={(e) => setEditData({ ...editData, actualHours: parseInt(e.target.value) || 0 })}
                      data-testid="input-actual-hours"
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm" data-testid="text-actual-hours">
                        {task.actualHours ? `${task.actualHours}h` : 'Not tracked'}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-muted-foreground">Description</label>
                {isEditing ? (
                  <Textarea
                    value={editData.description || ""}
                    onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                    placeholder="Add a description..."
                    className="min-h-[100px]"
                    data-testid="textarea-task-description"
                  />
                ) : (
                  <div className="text-sm text-foreground whitespace-pre-wrap" data-testid="text-task-description">
                    {task.description || <span className="text-muted-foreground italic">No description</span>}
                  </div>
                )}
              </div>

              {/* Metadata */}
              <div className="text-xs text-muted-foreground space-y-1">
                <div>Created {formatDistanceToNow(new Date(task.createdAt))} ago by {task.creator ? `${task.creator.firstName} ${task.creator.lastName}` : 'Unknown'}</div>
                {task.updatedAt !== task.createdAt && (
                  <div>Updated {formatDistanceToNow(new Date(task.updatedAt))} ago</div>
                )}
              </div>
            </div>

            <Separator />

            {/* Tabs Section */}
            <div className="flex-1 overflow-hidden pt-4">
              <Tabs defaultValue="comments" className="h-full flex flex-col">
                <TabsList className="grid w-full grid-cols-3 flex-shrink-0">
                  <TabsTrigger value="comments" className="flex items-center gap-2" data-testid="tab-comments">
                    <MessageSquare className="w-4 h-4" />
                    Comments
                  </TabsTrigger>
                  <TabsTrigger value="attachments" className="flex items-center gap-2" data-testid="tab-attachments">
                    <Paperclip className="w-4 h-4" />
                    Files
                  </TabsTrigger>
                  <TabsTrigger value="activity" className="flex items-center gap-2" data-testid="tab-activity">
                    <Activity className="w-4 h-4" />
                    Activity
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="comments" className="flex-1 overflow-hidden mt-4">
                  <CommentThread taskId={taskId} />
                </TabsContent>

                <TabsContent value="attachments" className="flex-1 overflow-hidden mt-4">
                  <FileAttachments taskId={taskId} />
                </TabsContent>

                <TabsContent value="activity" className="flex-1 overflow-hidden mt-4">
                  <ActivityTimeline taskId={taskId} />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}