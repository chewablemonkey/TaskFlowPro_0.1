import { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { DashboardGrid } from './DashboardGrid';
import { DashboardManager } from './DashboardManager';
import { WidgetCatalog } from './WidgetCatalog';
import { Widget } from './Widget';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import type { DashboardLayout as BackendDashboardLayout } from "@shared/schema";

// Import all widget components
import { ProjectStatusWidget } from './widgets/ProjectStatusWidget';
import { TaskCompletionWidget } from './widgets/TaskCompletionWidget';
import { TeamProductivityWidget } from './widgets/TeamProductivityWidget';
import { PriorityDistributionWidget } from './widgets/PriorityDistributionWidget';
import { BurndownChartWidget } from './widgets/BurndownChartWidget';
import { TeamWorkloadWidget } from './widgets/TeamWorkloadWidget';
import { TimelineGanttWidget } from './widgets/TimelineGanttWidget';
import { ActivityFeedWidget } from './widgets/ActivityFeedWidget';
import { DeadlinesWidget } from './widgets/DeadlinesWidget';
import { ActiveMembersWidget } from './widgets/ActiveMembersWidget';
import { NotificationsWidget } from './widgets/NotificationsWidget';
import { PortfolioOverviewWidget } from './widgets/PortfolioOverviewWidget';
import { ResourceUtilizationWidget } from './widgets/ResourceUtilizationWidget';
import { RiskIndicatorsWidget } from './widgets/RiskIndicatorsWidget';

import type { WidgetConfig, DashboardLayout, WidgetSize } from './types';

interface DashboardWidgetsProps {
  className?: string;
}

// Widget component registry
const widgetComponents = {
  ProjectStatusWidget,
  TaskCompletionWidget,
  TeamProductivityWidget,
  PriorityDistributionWidget,
  BurndownChartWidget,
  TeamWorkloadWidget,
  TimelineGanttWidget,
  ActivityFeedWidget,
  DeadlinesWidget,
  ActiveMembersWidget,
  NotificationsWidget,
  PortfolioOverviewWidget,
  ResourceUtilizationWidget,
  RiskIndicatorsWidget,
} as const;

// Default layouts for different user roles
const defaultLayouts: DashboardLayout[] = [
  {
    id: 'default-manager',
    name: 'Manager Dashboard',
    isDefault: true,
    userRole: ['manager'],
    widgets: [
      {
        id: 'portfolio-overview-1',
        type: 'PortfolioOverviewWidget',
        title: 'Portfolio Overview',
        size: '3x2',
        position: { x: 0, y: 0 },
        props: { view: 'overview' },
      },
      {
        id: 'project-status-1',
        type: 'ProjectStatusWidget',
        title: 'Project Status',
        size: '2x2',
        position: { x: 3, y: 0 },
        props: {},
      },
      {
        id: 'team-productivity-1',
        type: 'TeamProductivityWidget',
        title: 'Team Productivity',
        size: '3x1',
        position: { x: 0, y: 2 },
        props: { variant: 'chart' },
      },
      {
        id: 'deadlines-1',
        type: 'DeadlinesWidget',
        title: 'Upcoming Deadlines',
        size: '2x1',
        position: { x: 3, y: 2 },
        props: { daysAhead: 7 },
      },
    ],
  },
  {
    id: 'default-developer',
    name: 'Developer Dashboard',
    isDefault: true,
    userRole: ['developer'],
    widgets: [
      {
        id: 'task-completion-1',
        type: 'TaskCompletionWidget',
        title: 'My Tasks',
        size: '2x1',
        position: { x: 0, y: 0 },
        props: {},
      },
      {
        id: 'burndown-chart-1',
        type: 'BurndownChartWidget',
        title: 'Sprint Burndown',
        size: '2x2',
        position: { x: 2, y: 0 },
        props: { timeRange: 'sprint' },
      },
      {
        id: 'priority-distribution-1',
        type: 'PriorityDistributionWidget',
        title: 'Task Priorities',
        size: '2x2',
        position: { x: 0, y: 1 },
        props: {},
      },
      {
        id: 'activity-feed-1',
        type: 'ActivityFeedWidget',
        title: 'Recent Activity',
        size: '2x2',
        position: { x: 2, y: 2 },
        props: { maxItems: 8 },
      },
    ],
  },
  {
    id: 'default-executive',
    name: 'Executive Dashboard',
    isDefault: true,
    userRole: ['admin'],
    widgets: [
      {
        id: 'portfolio-overview-exec',
        type: 'PortfolioOverviewWidget',
        title: 'Portfolio Health',
        size: '4x2',
        position: { x: 0, y: 0 },
        props: { view: 'overview', showBudgets: true },
      },
      {
        id: 'resource-utilization-1',
        type: 'ResourceUtilizationWidget',
        title: 'Resource Utilization',
        size: '2x2',
        position: { x: 0, y: 2 },
        props: { view: 'utilization' },
      },
      {
        id: 'risk-indicators-1',
        type: 'RiskIndicatorsWidget',
        title: 'Risk Indicators',
        size: '2x2',
        position: { x: 2, y: 2 },
        props: { severityFilter: 'all' },
      },
    ],
  },
];

export function DashboardWidgets({ className }: DashboardWidgetsProps) {
  const [widgets, setWidgets] = useState<WidgetConfig[]>([]);
  const [currentLayout, setCurrentLayout] = useState<DashboardLayout | null>(null);
  const [availableLayouts, setAvailableLayouts] = useState<DashboardLayout[]>(defaultLayouts);
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();
  const { user, isLoading: isAuthLoading } = useAuth();
  const queryClient = useQueryClient();

  // LocalStorage utilities
  const STORAGE_KEY = 'dashboard-layouts-cache';
  const getLocalStorageLayouts = useCallback((): BackendDashboardLayout[] => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY);
      return cached ? JSON.parse(cached) : [];
    } catch {
      return [];
    }
  }, []);

  const setLocalStorageLayouts = useCallback((layouts: BackendDashboardLayout[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(layouts));
    } catch (error) {
      console.warn('Failed to cache layouts to localStorage:', error);
    }
  }, []);

  // Fetch user's dashboard layouts from backend
  const { 
    data: backendLayouts = [], 
    isLoading: isLoadingLayouts, 
    error: layoutsError 
  } = useQuery({
    queryKey: ['/api/dashboard/layouts'],
    enabled: !!user && !isAuthLoading,
    staleTime: 5 * 60 * 1000, // 5 minutes
    onSuccess: (data) => {
      setLocalStorageLayouts(data);
    },
    onError: () => {
      // Fallback to localStorage on API error
      const cachedLayouts = getLocalStorageLayouts();
      if (cachedLayouts.length > 0) {
        toast({
          title: "Using Cached Data",
          description: "Loading layouts from local cache due to network issue.",
          variant: "default",
        });
      }
    }
  });

  // Convert backend layouts to frontend format and merge with defaults
  const availableLayoutsWithDefaults = useMemo(() => {
    const userRole = user?.role || 'employee';
    const userDefaultLayouts = defaultLayouts.filter(layout => 
      layout.userRole?.includes(userRole)
    );

    // Convert backend layouts to frontend format
    const frontendBackendLayouts: DashboardLayout[] = backendLayouts.map(layout => ({
      id: layout.id,
      name: layout.name,
      widgets: layout.widgets as WidgetConfig[],
      isDefault: layout.isDefault,
      createdBy: layout.userId,
    }));

    return [...userDefaultLayouts, ...frontendBackendLayouts];
  }, [backendLayouts, user?.role]);

  // Initialize dashboard with user's layout or default
  useEffect(() => {
    if (isAuthLoading || !user || isLoadingLayouts) return;

    if (layoutsError) {
      // Try localStorage fallback
      const cachedLayouts = getLocalStorageLayouts();
      if (cachedLayouts.length > 0) {
        const cachedDefault = cachedLayouts.find(l => l.isDefault);
        if (cachedDefault) {
          const frontendLayout = {
            id: cachedDefault.id,
            name: cachedDefault.name,
            widgets: cachedDefault.widgets as WidgetConfig[],
            isDefault: cachedDefault.isDefault,
            createdBy: cachedDefault.userId,
          };
          setCurrentLayout(frontendLayout);
          setWidgets(frontendLayout.widgets);
          return;
        }
      }
    }

    // Find user's default layout or fallback to role-based default
    const userDefaultLayout = backendLayouts.find(l => l.isDefault);
    if (userDefaultLayout) {
      const frontendLayout = {
        id: userDefaultLayout.id,
        name: userDefaultLayout.name,
        widgets: userDefaultLayout.widgets as WidgetConfig[],
        isDefault: userDefaultLayout.isDefault,
        createdBy: userDefaultLayout.userId,
      };
      setCurrentLayout(frontendLayout);
      setWidgets(frontendLayout.widgets);
    } else {
      // Fallback to default layout based on role
      const userRole = user.role || 'employee';
      const roleDefaultLayout = defaultLayouts.find(layout => 
        layout.userRole?.includes(userRole)
      ) || defaultLayouts[0];
      
      setCurrentLayout(roleDefaultLayout);
      setWidgets(roleDefaultLayout.widgets);
    }
  }, [user, isAuthLoading, backendLayouts, isLoadingLayouts, layoutsError, getLocalStorageLayouts]);

  // Update available layouts state with computed value
  useEffect(() => {
    setAvailableLayouts(availableLayoutsWithDefaults);
  }, [availableLayoutsWithDefaults]);

  // Mutations for layout CRUD operations
  const createLayoutMutation = useMutation({
    mutationFn: async (layout: { name: string; widgets: WidgetConfig[]; isDefault?: boolean }) => {
      return await apiRequest('/api/dashboard/layouts', {
        method: 'POST',
        body: JSON.stringify(layout)
      });
    },
    onSuccess: (newLayout) => {
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/layouts'] });
      // Update localStorage optimistically
      const current = getLocalStorageLayouts();
      setLocalStorageLayouts([...current, newLayout]);
      toast({
        title: "Layout Saved",
        description: `Dashboard layout "${newLayout.name}" has been saved.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Save Failed",
        description: "Failed to save dashboard layout. Please try again.",
        variant: "destructive",
      });
    }
  });

  const updateLayoutMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<{ name: string; widgets: WidgetConfig[]; isDefault?: boolean }> }) => {
      return await apiRequest(`/api/dashboard/layouts/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates)
      });
    },
    onSuccess: (updatedLayout) => {
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/layouts'] });
      // Update localStorage optimistically
      const current = getLocalStorageLayouts();
      const updated = current.map(l => l.id === updatedLayout.id ? updatedLayout : l);
      setLocalStorageLayouts(updated);
      toast({
        title: "Layout Updated",
        description: `Dashboard layout "${updatedLayout.name}" has been updated.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: "Failed to update dashboard layout. Please try again.",
        variant: "destructive",
      });
    }
  });

  const deleteLayoutMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest(`/api/dashboard/layouts/${id}`, {
        method: 'DELETE'
      });
    },
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/layouts'] });
      // Update localStorage optimistically
      const current = getLocalStorageLayouts();
      setLocalStorageLayouts(current.filter(l => l.id !== deletedId));
      toast({
        title: "Layout Deleted",
        description: "Dashboard layout has been deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete dashboard layout. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Render a widget component based on its type
  const renderWidget = useCallback((widget: WidgetConfig) => {
    const WidgetComponent = widgetComponents[widget.type as keyof typeof widgetComponents];
    
    if (!WidgetComponent) {
      console.warn(`Widget type "${widget.type}" not found`);
      return (
        <Widget
          key={widget.id}
          id={widget.id}
          title={widget.title}
          size={widget.size}
          error="Widget type not found"
        >
          <div className="flex items-center justify-center h-full">
            <span className="text-muted-foreground">Unknown widget type</span>
          </div>
        </Widget>
      );
    }

    const handleRemove = () => {
      setWidgets(prev => prev.filter(w => w.id !== widget.id));
      toast({
        title: "Widget Removed",
        description: `"${widget.title}" has been removed from the dashboard.`,
      });
    };

    const handleResize = (newSize: WidgetSize) => {
      setWidgets(prev => prev.map(w => 
        w.id === widget.id ? { ...w, size: newSize } : w
      ));
    };

    return (
      <WidgetComponent
        key={widget.id}
        id={widget.id}
        title={widget.title}
        size={widget.size}
        onRemove={isEditing ? handleRemove : undefined}
        onResize={isEditing ? handleResize : undefined}
        refreshInterval={widget.refreshInterval}
        {...widget.props}
      />
    );
  }, [isEditing, toast]);

  // Handle adding a new widget
  const handleAddWidget = useCallback((widget: WidgetConfig) => {
    setWidgets(prev => [...prev, widget]);
    toast({
      title: "Widget Added",
      description: `"${widget.title}" has been added to your dashboard.`,
    });
  }, [toast]);

  // Handle saving a layout (create or update)
  const handleSaveLayout = useCallback(async (layout: DashboardLayout) => {
    const layoutData = {
      name: layout.name,
      widgets: widgets,
      isDefault: layout.isDefault || false
    };

    // Check if this is an existing backend layout (has createdBy field) 
    const isBackendLayout = 'createdBy' in layout && layout.createdBy;
    
    if (isBackendLayout) {
      // Update existing backend layout
      updateLayoutMutation.mutate({ 
        id: layout.id, 
        updates: layoutData 
      });
    } else if (layout.id.startsWith('default-')) {
      // Create new layout based on default template
      createLayoutMutation.mutate(layoutData);
    } else {
      // Update existing user-created layout
      updateLayoutMutation.mutate({ 
        id: layout.id, 
        updates: layoutData 
      });
    }
  }, [widgets, createLayoutMutation, updateLayoutMutation]);

  // Handle loading a layout
  const handleLoadLayout = useCallback((layout: DashboardLayout) => {
    setWidgets(layout.widgets);
    setCurrentLayout(layout);
    setIsEditing(false);
    
    // Save current layout selection to localStorage for persistence
    try {
      localStorage.setItem('dashboard-current-layout', layout.id);
    } catch (error) {
      console.warn('Failed to save current layout preference:', error);
    }
  }, []);

  // Handle deleting a layout
  const handleDeleteLayout = useCallback((layoutId: string) => {
    // Only allow deletion of user-created layouts (not default templates)
    if (layoutId.startsWith('default-')) {
      toast({
        title: "Cannot Delete",
        description: "Default layouts cannot be deleted.",
        variant: "destructive",
      });
      return;
    }

    deleteLayoutMutation.mutate(layoutId);
    
    // If we're deleting the current layout, switch to default
    if (currentLayout?.id === layoutId) {
      const userRole = user?.role || 'employee';
      const fallbackLayout = defaultLayouts.find(layout => 
        layout.userRole?.includes(userRole)
      ) || defaultLayouts[0];
      
      setCurrentLayout(fallbackLayout);
      setWidgets(fallbackLayout.widgets);
    }
  }, [currentLayout, deleteLayoutMutation, user?.role, toast]);

  // Auto-save functionality with debouncing
  const autoSaveTimeoutRef = useRef<NodeJS.Timeout>();
  const lastSavedWidgetsRef = useRef<WidgetConfig[]>([]);

  // Debounced auto-save effect
  useEffect(() => {
    // Only auto-save if we have a current layout and widgets have actually changed
    if (!currentLayout || !user || isAuthLoading) return;
    if (JSON.stringify(widgets) === JSON.stringify(lastSavedWidgetsRef.current)) return;

    // Clear existing timeout
    if (autoSaveTimeoutRef.current) {
      clearTimeout(autoSaveTimeoutRef.current);
    }

    // Set new timeout for auto-save
    autoSaveTimeoutRef.current = setTimeout(() => {
      // Only auto-save user-created layouts, not default templates
      if (!currentLayout.id.startsWith('default-') && 'createdBy' in currentLayout) {
        const layoutData = {
          name: currentLayout.name,
          widgets: widgets,
          isDefault: currentLayout.isDefault || false
        };

        // Update backend with debounced save
        updateLayoutMutation.mutate(
          { id: currentLayout.id, updates: layoutData },
          {
            onSuccess: () => {
              lastSavedWidgetsRef.current = [...widgets];
            },
            onError: (error) => {
              // On error, save to localStorage as backup
              try {
                const backupLayouts = getLocalStorageLayouts();
                const updated = backupLayouts.map(l => 
                  l.id === currentLayout.id 
                    ? { ...l, widgets: widgets as any, updatedAt: new Date().toISOString() }
                    : l
                );
                setLocalStorageLayouts(updated);
                console.warn('Auto-save to backend failed, saved to localStorage as backup');
              } catch (backupError) {
                console.error('Failed to save layout to localStorage backup:', backupError);
              }
            }
          }
        );
      } else {
        // For default layouts, just save to localStorage
        try {
          const currentLayoutData = {
            ...currentLayout,
            widgets: widgets
          };
          localStorage.setItem('dashboard-temp-layout', JSON.stringify(currentLayoutData));
        } catch (error) {
          console.warn('Failed to save temporary layout changes:', error);
        }
      }
    }, 2000); // 2 second debounce

    // Cleanup timeout on unmount
    return () => {
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
    };
  }, [widgets, currentLayout, updateLayoutMutation, user, isAuthLoading, getLocalStorageLayouts, setLocalStorageLayouts]);

  // Error boundary for localStorage operations
  const safeLocalStorageOperation = useCallback((operation: () => void, errorMessage: string) => {
    try {
      operation();
    } catch (error) {
      console.warn(errorMessage, error);
      toast({
        title: "Storage Warning",
        description: "Some changes may not be saved locally due to storage limitations.",
        variant: "default",
      });
    }
  }, [toast]);

  // Handle exporting a layout
  const handleExportLayout = useCallback((layout: DashboardLayout) => {
    const dataStr = JSON.stringify(layout, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `dashboard-${layout.name.toLowerCase().replace(/\s+/g, '-')}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  }, []);

  // Handle importing a layout (placeholder for file upload)
  const handleImportLayout = useCallback((layout: DashboardLayout) => {
    // In a real app, this would handle file upload and parsing
    setAvailableLayouts(prev => [...prev, layout]);
    toast({
      title: "Layout Imported",
      description: `Dashboard layout "${layout.name}" has been imported.`,
    });
  }, [toast]);

  return (
    <div className={className}>
      {/* Dashboard controls */}
      <div className="flex items-center justify-between mb-6 p-4 bg-card rounded-lg border">
        <div className="flex items-center gap-4">
          <h1 className="text-xl font-semibold">Dashboard</h1>
          {currentLayout && (
            <span className="text-sm text-muted-foreground">
              Layout: {currentLayout.name}
            </span>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          <DashboardManager
            currentLayout={currentLayout}
            availableLayouts={availableLayouts}
            onSaveLayout={handleSaveLayout}
            onLoadLayout={handleLoadLayout}
            onDeleteLayout={handleDeleteLayout}
            onExportLayout={handleExportLayout}
            onImportLayout={handleImportLayout}
            widgets={widgets}
            isEditing={isEditing}
            onEditingChange={setIsEditing}
          />
          
          {isEditing && (
            <WidgetCatalog onAddWidget={handleAddWidget} />
          )}
        </div>
      </div>

      {/* Dashboard grid */}
      <DashboardGrid
        widgets={widgets}
        onWidgetsChange={setWidgets}
        renderWidget={renderWidget}
        isEditing={isEditing}
        className="min-h-[600px]"
      />

      {/* Empty state */}
      {widgets.length === 0 && (
        <div className="text-center py-12">
          <div className="text-muted-foreground mb-4">Your dashboard is empty</div>
          <WidgetCatalog 
            onAddWidget={handleAddWidget}
            trigger={
              <button className="text-primary hover:underline">
                Add your first widget
              </button>
            }
          />
        </div>
      )}
    </div>
  );
}