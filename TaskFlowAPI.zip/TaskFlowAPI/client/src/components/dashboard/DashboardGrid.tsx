import { useState, useCallback } from 'react';
import {
  DndContext,
  DragOverlay,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragStartEvent,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import {
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { cn } from "@/lib/utils";
import type { WidgetConfig, WidgetSize } from './types';

interface DashboardGridProps {
  widgets: WidgetConfig[];
  onWidgetsChange: (widgets: WidgetConfig[]) => void;
  renderWidget: (widget: WidgetConfig) => React.ReactNode;
  className?: string;
  isEditing?: boolean;
}

interface SortableWidgetProps {
  widget: WidgetConfig;
  children: React.ReactNode;
  isEditing: boolean;
}

const sizeClasses: Record<WidgetSize, string> = {
  '1x1': 'col-span-1 row-span-1',
  '2x1': 'col-span-2 row-span-1', 
  '2x2': 'col-span-2 row-span-2',
  '3x1': 'col-span-3 row-span-1',
  '3x2': 'col-span-3 row-span-2',
  '4x2': 'col-span-4 row-span-2',
};

function SortableWidget({ widget, children, isEditing }: SortableWidgetProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ 
    id: widget.id,
    disabled: !isEditing,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "relative",
        sizeClasses[widget.size],
        isDragging && "opacity-50 z-50",
        isEditing && "cursor-grab active:cursor-grabbing"
      )}
      {...attributes}
      {...(isEditing ? listeners : {})}
      data-testid={`sortable-widget-${widget.id}`}
    >
      {children}
    </div>
  );
}

export function DashboardGrid({
  widgets,
  onWidgetsChange,
  renderWidget,
  className,
  isEditing = false,
}: DashboardGridProps) {
  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  }, []);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;

    if (active.id !== over?.id) {
      const oldIndex = widgets.findIndex((w) => w.id === active.id);
      const newIndex = widgets.findIndex((w) => w.id === over?.id);

      const newWidgets = arrayMove(widgets, oldIndex, newIndex);
      onWidgetsChange(newWidgets);
    }

    setActiveId(null);
  }, [widgets, onWidgetsChange]);

  const activeWidget = activeId ? widgets.find((w) => w.id === activeId) : null;

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <SortableContext 
        items={widgets.map(w => w.id)} 
        strategy={rectSortingStrategy}
      >
        <div 
          className={cn(
            "grid grid-cols-4 gap-6 auto-rows-[200px]",
            "min-h-[400px]",
            className
          )}
          data-testid="dashboard-grid"
        >
          {widgets.map((widget) => (
            <SortableWidget
              key={widget.id}
              widget={widget}
              isEditing={isEditing}
            >
              {renderWidget(widget)}
            </SortableWidget>
          ))}
        </div>
      </SortableContext>

      <DragOverlay>
        {activeWidget ? (
          <div className={cn(
            "opacity-90 rotate-3 shadow-lg",
            sizeClasses[activeWidget.size]
          )}>
            {renderWidget(activeWidget)}
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}