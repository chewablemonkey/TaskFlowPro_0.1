import { useState, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { 
  Save, 
  Layout,
  Trash2,
  Copy,
  Edit,
  Download,
  Upload,
  Settings,
  Eye,
  EyeOff
} from "lucide-react";
import { nanoid } from 'nanoid';
import type { DashboardLayout, WidgetConfig } from './types';

interface DashboardManagerProps {
  currentLayout: DashboardLayout | null;
  availableLayouts: DashboardLayout[];
  onSaveLayout: (layout: DashboardLayout) => void;
  onLoadLayout: (layout: DashboardLayout) => void;
  onDeleteLayout: (layoutId: string) => void;
  onExportLayout: (layout: DashboardLayout) => void;
  onImportLayout: (layout: DashboardLayout) => void;
  widgets: WidgetConfig[];
  isEditing: boolean;
  onEditingChange: (editing: boolean) => void;
}

export function DashboardManager({
  currentLayout,
  availableLayouts,
  onSaveLayout,
  onLoadLayout,
  onDeleteLayout,
  onExportLayout,
  onImportLayout,
  widgets,
  isEditing,
  onEditingChange,
}: DashboardManagerProps) {
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [loadDialogOpen, setLoadDialogOpen] = useState(false);
  const [newLayoutName, setNewLayoutName] = useState('');
  const [selectedUserRole, setSelectedUserRole] = useState<string>('');
  const { toast } = useToast();

  const handleSaveLayout = useCallback(() => {
    if (!newLayoutName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a layout name",
        variant: "destructive",
      });
      return;
    }

    const layout: DashboardLayout = {
      id: currentLayout?.id || nanoid(),
      name: newLayoutName.trim(),
      widgets: widgets,
      createdBy: 'current-user', // In real app, get from auth
      isDefault: false,
      userRole: selectedUserRole ? [selectedUserRole] : undefined,
    };

    onSaveLayout(layout);
    setSaveDialogOpen(false);
    setNewLayoutName('');
    setSelectedUserRole('');
    
    toast({
      title: "Layout Saved",
      description: `Dashboard layout "${layout.name}" has been saved successfully.`,
    });
  }, [newLayoutName, selectedUserRole, widgets, currentLayout, onSaveLayout, toast]);

  const handleLoadLayout = useCallback((layout: DashboardLayout) => {
    onLoadLayout(layout);
    setLoadDialogOpen(false);
    toast({
      title: "Layout Loaded",
      description: `Dashboard layout "${layout.name}" has been loaded.`,
    });
  }, [onLoadLayout, toast]);

  const handleDeleteLayout = useCallback((layoutId: string, layoutName: string) => {
    onDeleteLayout(layoutId);
    toast({
      title: "Layout Deleted",
      description: `Dashboard layout "${layoutName}" has been deleted.`,
      variant: "destructive",
    });
  }, [onDeleteLayout, toast]);

  const handleDuplicateLayout = useCallback((layout: DashboardLayout) => {
    const duplicatedLayout: DashboardLayout = {
      ...layout,
      id: nanoid(),
      name: `${layout.name} (Copy)`,
      isDefault: false,
    };
    onSaveLayout(duplicatedLayout);
    toast({
      title: "Layout Duplicated",
      description: `Dashboard layout "${duplicatedLayout.name}" has been created.`,
    });
  }, [onSaveLayout, toast]);

  const handleExportLayout = useCallback((layout: DashboardLayout) => {
    onExportLayout(layout);
    toast({
      title: "Layout Exported",
      description: `Dashboard layout "${layout.name}" has been exported.`,
    });
  }, [onExportLayout, toast]);

  const toggleEditing = useCallback(() => {
    onEditingChange(!isEditing);
    toast({
      title: isEditing ? "Edit Mode Disabled" : "Edit Mode Enabled",
      description: isEditing 
        ? "You can now interact with widgets normally" 
        : "You can now drag, resize, and modify widgets",
    });
  }, [isEditing, onEditingChange, toast]);

  return (
    <div className="flex items-center gap-2">
      {/* Edit mode toggle */}
      <Button
        variant={isEditing ? "default" : "outline"}
        size="sm"
        onClick={toggleEditing}
        className="gap-2"
        data-testid="toggle-edit-mode"
      >
        {isEditing ? <EyeOff className="h-4 w-4" /> : <Edit className="h-4 w-4" />}
        {isEditing ? "Exit Edit" : "Edit Dashboard"}
      </Button>

      {/* Save layout */}
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2" data-testid="save-layout-button">
            <Save className="h-4 w-4" />
            Save Layout
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Dashboard Layout</DialogTitle>
            <DialogDescription>
              Save your current dashboard configuration for future use
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Layout Name</label>
              <Input
                placeholder="Enter layout name"
                value={newLayoutName}
                onChange={(e) => setNewLayoutName(e.target.value)}
                data-testid="layout-name-input"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">User Role (Optional)</label>
              <Select value={selectedUserRole} onValueChange={setSelectedUserRole}>
                <SelectTrigger data-testid="user-role-select">
                  <SelectValue placeholder="Select user role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Users</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="developer">Developer</SelectItem>
                  <SelectItem value="designer">Designer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setSaveDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveLayout} data-testid="save-layout-confirm">
                Save Layout
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Load layout */}
      <Dialog open={loadDialogOpen} onOpenChange={setLoadDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2" data-testid="load-layout-button">
            <Layout className="h-4 w-4" />
            Load Layout
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Load Dashboard Layout</DialogTitle>
            <DialogDescription>
              Choose from your saved dashboard layouts
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-96 overflow-y-auto">
            {availableLayouts.length > 0 ? (
              <div className="grid gap-3">
                {availableLayouts.map((layout) => (
                  <Card 
                    key={layout.id} 
                    className="hover:shadow-sm transition-shadow"
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-base">{layout.name}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              {layout.widgets.length} widgets
                            </Badge>
                            {layout.isDefault && (
                              <Badge variant="outline" className="text-xs">
                                Default
                              </Badge>
                            )}
                            {layout.userRole && layout.userRole.length > 0 && (
                              <Badge variant="outline" className="text-xs">
                                {layout.userRole[0]}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {/* Load layout */}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleLoadLayout(layout)}
                            data-testid={`load-layout-${layout.id}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          
                          {/* Duplicate layout */}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDuplicateLayout(layout)}
                            data-testid={`duplicate-layout-${layout.id}`}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          
                          {/* Export layout */}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleExportLayout(layout)}
                            data-testid={`export-layout-${layout.id}`}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                          
                          {/* Delete layout */}
                          {!layout.isDefault && (
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-destructive hover:text-destructive"
                                  data-testid={`delete-layout-${layout.id}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Layout</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to delete "{layout.name}"? This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDeleteLayout(layout.id, layout.name)}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-sm">
                        Created by {layout.createdBy || 'Unknown'} • {layout.widgets.length} widgets configured
                      </CardDescription>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Layout className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <div>No saved layouts found</div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Current layout info */}
      {currentLayout && (
        <Badge variant="outline" className="text-xs">
          {currentLayout.name}
        </Badge>
      )}
    </div>
  );
}