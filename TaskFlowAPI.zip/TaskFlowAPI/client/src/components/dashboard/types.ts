import { ReactNode } from 'react';

export type WidgetSize = '1x1' | '2x1' | '2x2' | '3x1' | '3x2' | '4x2';

// Widget-specific props interfaces
export interface BaseWidgetProps {
  view?: string;
  variant?: string;
  timeRange?: string;
  daysAhead?: number;
  maxItems?: number;
  showBudgets?: boolean;
  severityFilter?: string;
}

export interface WidgetConfig {
  id: string;
  type: string;
  title: string;
  size: WidgetSize;
  position: { x: number; y: number };
  props?: BaseWidgetProps;
  refreshInterval?: number; // in seconds, 0 means no auto-refresh
}

export interface WidgetProps {
  id: string;
  title: string;
  size: WidgetSize;
  className?: string;
  onRemove?: () => void;
  onResize?: (size: WidgetSize) => void;
  onRefresh?: () => void;
  isLoading?: boolean;
  error?: string | null;
  lastUpdated?: Date;
  refreshInterval?: number;
  children: ReactNode;
  actions?: ReactNode[];
}

export interface DashboardLayout {
  id: string;
  name: string;
  widgets: WidgetConfig[];
  createdBy?: string;
  isDefault?: boolean;
  userRole?: string[];
}

export interface WidgetDataHook<T = unknown> {
  data: T | undefined;
  isLoading: boolean;
  error: string | null;
  refetch: () => void;
  lastUpdated: Date | null;
}

// KPI Widget Data Types
export interface ProjectStatusData {
  status: string;
  count: number;
  percentage: number;
}

export interface TaskCompletionData {
  totalTasks: number;
  completedTasks: number;
  overdueTasks: number;
  completionRate: number;
  trend: number; // percentage change from previous period
}

export interface TeamProductivityData {
  memberId: string;
  memberName: string;
  tasksCompleted: number;
  tasksInProgress: number;
  averageCompletionTime: number; // in hours
  efficiency: number; // percentage
}

export interface ProjectTimelineHealth {
  onTime: number;
  delayed: number;
  atRisk: number; // due soon but not started
  totalProjects: number;
}

export interface ResourceAllocationData {
  memberId: string;
  memberName: string;
  allocatedHours: number;
  actualHours: number;
  utilization: number; // percentage
  availability: number; // percentage
}

// Chart Widget Data Types
export interface PriorityDistributionData {
  priority: 'low' | 'medium' | 'high';
  count: number;
  percentage: number;
}

export interface BurndownData {
  date: string;
  planned: number;
  actual: number;
  remaining: number;
}

export interface WorkloadData {
  assignee: string;
  tasks: number;
  hours: number;
  status: 'normal' | 'overloaded' | 'underutilized';
}

// Activity Feed Data Types
export interface ActivityItem {
  id: string;
  type: 'task_created' | 'task_completed' | 'task_assigned' | 'comment_added' | 'file_uploaded' | 'project_created';
  title: string;
  description: string;
  user: {
    id: string;
    name: string;
    avatar?: string;
  };
  timestamp: Date;
  metadata?: {
    projectId?: string;
    taskId?: string;
    projectName?: string;
    taskTitle?: string;
  };
}

export interface DeadlineAlert {
  id: string;
  type: 'task' | 'project';
  title: string;
  dueDate: Date;
  priority: 'low' | 'medium' | 'high';
  status: 'upcoming' | 'overdue';
  assignee?: string;
  projectName?: string;
}

export interface ActiveMember {
  id: string;
  name: string;
  avatar?: string;
  status: 'online' | 'offline' | 'busy';
  currentTask?: {
    id: string;
    title: string;
    progress: number;
  };
  lastActive: Date;
}