import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MoreVertical, 
  RefreshCw, 
  X, 
  Maximize2,
  Calendar
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import type { WidgetProps, WidgetSize } from './types';

const sizeClasses: Record<WidgetSize, string> = {
  '1x1': 'col-span-1 row-span-1',
  '2x1': 'col-span-2 row-span-1', 
  '2x2': 'col-span-2 row-span-2',
  '3x1': 'col-span-3 row-span-1',
  '3x2': 'col-span-3 row-span-2',
  '4x2': 'col-span-4 row-span-2',
};

const sizeOptions: { value: WidgetSize; label: string }[] = [
  { value: '1x1', label: 'Small (1×1)' },
  { value: '2x1', label: 'Wide (2×1)' },
  { value: '2x2', label: 'Large (2×2)' },
  { value: '3x1', label: 'Extra Wide (3×1)' },
  { value: '3x2', label: 'Extra Large (3×2)' },
  { value: '4x2', label: 'Full Width (4×2)' },
];

export function Widget({
  id,
  title,
  size,
  className,
  onRemove,
  onResize,
  onRefresh,
  isLoading = false,
  error = null,
  lastUpdated,
  refreshInterval,
  children,
  actions = [],
}: WidgetProps) {
  const handleRefresh = () => {
    if (onRefresh) {
      onRefresh();
    }
  };

  const handleResize = (newSize: WidgetSize) => {
    if (onResize) {
      onResize(newSize);
    }
  };

  const handleRemove = () => {
    if (onRemove) {
      onRemove();
    }
  };

  return (
    <Card 
      className={cn(
        "h-full relative transition-all duration-200 hover:shadow-md",
        sizeClasses[size],
        className
      )}
      data-testid={`widget-${id}`}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-sm text-foreground" data-testid={`widget-title-${id}`}>
              {title}
            </h3>
            {refreshInterval && refreshInterval > 0 && (
              <Badge variant="secondary" className="text-xs">
                Auto {refreshInterval}s
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            {/* Custom actions */}
            {actions.map((action, index) => (
              <div key={index}>{action}</div>
            ))}
            
            {/* Refresh button */}
            {onRefresh && (
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleRefresh}
                disabled={isLoading}
                data-testid={`widget-refresh-${id}`}
                className="h-8 w-8 p-0"
              >
                <RefreshCw className={cn("h-3 w-3", isLoading && "animate-spin")} />
              </Button>
            )}
            
            {/* Widget menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm"
                  data-testid={`widget-menu-${id}`}
                  className="h-8 w-8 p-0"
                >
                  <MoreVertical className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {onResize && (
                  <>
                    <DropdownMenuItem className="text-xs font-medium text-muted-foreground">
                      Resize Widget
                    </DropdownMenuItem>
                    {sizeOptions.map((option) => (
                      <DropdownMenuItem
                        key={option.value}
                        onClick={() => handleResize(option.value)}
                        className={cn(
                          "text-xs",
                          size === option.value && "bg-accent"
                        )}
                        data-testid={`widget-resize-${option.value}-${id}`}
                      >
                        <Maximize2 className="h-3 w-3 mr-2" />
                        {option.label}
                      </DropdownMenuItem>
                    ))}
                    <DropdownMenuSeparator />
                  </>
                )}
                
                {onRefresh && (
                  <DropdownMenuItem onClick={handleRefresh} disabled={isLoading}>
                    <RefreshCw className="h-3 w-3 mr-2" />
                    Refresh Data
                  </DropdownMenuItem>
                )}
                
                {onRemove && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={handleRemove}
                      className="text-destructive focus:text-destructive"
                      data-testid={`widget-remove-${id}`}
                    >
                      <X className="h-3 w-3 mr-2" />
                      Remove Widget
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        {/* Last updated info */}
        {lastUpdated && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            Updated {format(lastUpdated, 'MMM dd, HH:mm')}
          </div>
        )}
      </CardHeader>
      
      <CardContent className="pt-0 h-[calc(100%-80px)]">
        {error ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="text-sm text-destructive mb-2">Failed to load data</div>
              <div className="text-xs text-muted-foreground">{error}</div>
              {onRefresh && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleRefresh}
                  className="mt-2"
                >
                  Try Again
                </Button>
              )}
            </div>
          </div>
        ) : isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2 text-muted-foreground" />
              <div className="text-sm text-muted-foreground">Loading...</div>
            </div>
          </div>
        ) : (
          children
        )}
      </CardContent>
    </Card>
  );
}