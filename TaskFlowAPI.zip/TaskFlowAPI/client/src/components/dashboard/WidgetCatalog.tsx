import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Plus, 
  Search,
  BarChart3,
  PieChart,
  Users,
  Clock,
  TrendingUp,
  Activity,
  Target,
  Shield,
  Briefcase,
  Bell,
  Calendar
} from "lucide-react";
import { nanoid } from 'nanoid';
import type { WidgetConfig, WidgetSize, BaseWidgetProps } from './types';

interface WidgetTemplate {
  id: string;
  type: string;
  name: string;
  description: string;
  category: 'kpi' | 'visualization' | 'realtime' | 'executive';
  icon: React.ComponentType<{ className?: string }>;
  defaultSize: WidgetSize;
  defaultProps?: BaseWidgetProps;
  preview?: string;
}

interface WidgetCatalogProps {
  onAddWidget: (widget: WidgetConfig) => void;
  trigger?: React.ReactNode;
}

const widgetTemplates: WidgetTemplate[] = [
  // KPI Widgets
  {
    id: 'project-status',
    type: 'ProjectStatusWidget',
    name: 'Project Status',
    description: 'Overview of project statuses with completion percentages',
    category: 'kpi',
    icon: PieChart,
    defaultSize: '2x2',
    preview: 'Donut chart showing project status distribution',
  },
  {
    id: 'task-completion',
    type: 'TaskCompletionWidget', 
    name: 'Task Completion',
    description: 'Task completion rates and overdue tasks tracking',
    category: 'kpi',
    icon: Target,
    defaultSize: '2x1',
    preview: 'Progress indicators and task breakdowns',
  },
  {
    id: 'team-productivity',
    type: 'TeamProductivityWidget',
    name: 'Team Productivity',
    description: 'Team member productivity metrics and task completion',
    category: 'kpi',
    icon: Users,
    defaultSize: '3x2',
    defaultProps: { variant: 'chart' },
    preview: 'Bar chart of team member productivity',
  },

  // Visualization Widgets
  {
    id: 'priority-distribution',
    type: 'PriorityDistributionWidget',
    name: 'Priority Distribution',
    description: 'Task priority breakdown with alerts for high-priority items',
    category: 'visualization',
    icon: BarChart3,
    defaultSize: '2x2',
    preview: 'Pie chart showing task priority distribution',
  },
  {
    id: 'burndown-chart',
    type: 'BurndownChartWidget',
    name: 'Burndown Chart',
    description: 'Project progress tracking with planned vs actual progress',
    category: 'visualization',
    icon: TrendingUp,
    defaultSize: '3x2',
    defaultProps: { timeRange: 'week' },
    preview: 'Line chart showing project burndown',
  },
  {
    id: 'team-workload',
    type: 'TeamWorkloadWidget',
    name: 'Team Workload',
    description: 'Team member workload analysis with overload warnings',
    category: 'visualization',
    icon: BarChart3,
    defaultSize: '3x1',
    defaultProps: { variant: 'chart' },
    preview: 'Bar chart of team workload distribution',
  },
  {
    id: 'timeline-gantt',
    type: 'TimelineGanttWidget',
    name: 'Timeline View',
    description: 'Gantt-style timeline for projects and tasks',
    category: 'visualization',
    icon: Calendar,
    defaultSize: '4x2',
    defaultProps: { showProjects: true, showTasks: true },
    preview: 'Timeline view of projects and tasks',
  },

  // Real-time Widgets
  {
    id: 'activity-feed',
    type: 'ActivityFeedWidget',
    name: 'Activity Feed',
    description: 'Recent activity feed with task updates and changes',
    category: 'realtime',
    icon: Activity,
    defaultSize: '2x2',
    defaultProps: { maxItems: 10, showUserAvatars: true },
    preview: 'Live feed of recent activities',
  },
  {
    id: 'deadlines',
    type: 'DeadlinesWidget',
    name: 'Upcoming Deadlines',
    description: 'Deadline alerts and milestone tracking',
    category: 'realtime',
    icon: Clock,
    defaultSize: '2x2',
    defaultProps: { daysAhead: 7 },
    preview: 'List of upcoming deadlines and overdue items',
  },
  {
    id: 'active-members',
    type: 'ActiveMembersWidget',
    name: 'Active Team Members',
    description: 'Real-time team member status and current tasks',
    category: 'realtime',
    icon: Users,
    defaultSize: '2x2',
    defaultProps: { maxMembers: 8 },
    preview: 'Live team member status and activities',
  },
  {
    id: 'notifications',
    type: 'NotificationsWidget',
    name: 'Notifications',
    description: 'System notifications and alerts',
    category: 'realtime',
    icon: Bell,
    defaultSize: '2x2',
    defaultProps: { maxNotifications: 10 },
    preview: 'Notification center with alerts',
  },

  // Executive Widgets
  {
    id: 'portfolio-overview',
    type: 'PortfolioOverviewWidget',
    name: 'Portfolio Overview',
    description: 'High-level portfolio health and project overview',
    category: 'executive',
    icon: Briefcase,
    defaultSize: '3x2',
    defaultProps: { view: 'overview' },
    preview: 'Executive dashboard of portfolio health',
  },
  {
    id: 'resource-utilization',
    type: 'ResourceUtilizationWidget',
    name: 'Resource Utilization',
    description: 'Team resource allocation and capacity planning',
    category: 'executive',
    icon: Users,
    defaultSize: '3x2',
    defaultProps: { view: 'utilization' },
    preview: 'Resource utilization and capacity metrics',
  },
  {
    id: 'risk-indicators',
    type: 'RiskIndicatorsWidget',
    name: 'Risk Indicators',
    description: 'Project risk analysis and mitigation tracking',
    category: 'executive',
    icon: Shield,
    defaultSize: '3x2',
    defaultProps: { severityFilter: 'all', showMitigations: true },
    preview: 'Risk assessment and indicators',
  },
];

const categoryLabels = {
  kpi: 'KPI Metrics',
  visualization: 'Data Visualization',
  realtime: 'Real-time',
  executive: 'Executive Summary',
};

const categoryColors = {
  kpi: 'bg-blue-50 text-blue-700 border-blue-200',
  visualization: 'bg-green-50 text-green-700 border-green-200',
  realtime: 'bg-orange-50 text-orange-700 border-orange-200',
  executive: 'bg-purple-50 text-purple-700 border-purple-200',
};

export function WidgetCatalog({ onAddWidget, trigger }: WidgetCatalogProps) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredTemplates = widgetTemplates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddWidget = (template: WidgetTemplate, size?: WidgetSize) => {
    const widget: WidgetConfig = {
      id: nanoid(),
      type: template.type,
      title: template.name,
      size: size || template.defaultSize,
      position: { x: 0, y: 0 }, // Will be positioned by the grid
      props: template.defaultProps || {},
      refreshInterval: template.category === 'realtime' ? 30 : 0, // 30s for real-time widgets
    };

    onAddWidget(widget);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="gap-2" data-testid="add-widget-button">
            <Plus className="h-4 w-4" />
            Add Widget
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>Add Widget to Dashboard</DialogTitle>
          <DialogDescription>
            Choose from our collection of widgets to customize your dashboard
          </DialogDescription>
        </DialogHeader>

        {/* Search and filters */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search widgets..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="widget-search"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-48" data-testid="category-filter">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {Object.entries(categoryLabels).map(([key, label]) => (
                <SelectItem key={key} value={key}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Widget grid */}
        <div className="overflow-y-auto max-h-96">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTemplates.map((template) => {
              const Icon = template.icon;
              
              return (
                <Card 
                  key={template.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => handleAddWidget(template)}
                  data-testid={`widget-template-${template.id}`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-base">{template.name}</CardTitle>
                          <Badge 
                            variant="outline" 
                            className={`text-xs mt-1 ${categoryColors[template.category]}`}
                          >
                            {categoryLabels[template.category]}
                          </Badge>
                        </div>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {template.defaultSize}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-sm mb-3">
                      {template.description}
                    </CardDescription>
                    {template.preview && (
                      <div className="text-xs text-muted-foreground italic">
                        {template.preview}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {filteredTemplates.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <div>No widgets found matching your criteria</div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}