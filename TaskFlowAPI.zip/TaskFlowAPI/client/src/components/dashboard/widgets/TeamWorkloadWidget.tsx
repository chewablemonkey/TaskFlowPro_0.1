import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { BarChart } from '@/components/charts';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, AlertTriangle } from "lucide-react";
import type { WidgetProps, WorkloadData } from '../types';

interface TeamWorkloadWidgetProps extends Omit<WidgetProps, 'children'> {
  onMemberClick?: (memberId: string) => void;
  variant?: 'chart' | 'list';
  showOverloadWarnings?: boolean;
}

export function TeamWorkloadWidget({ 
  onMemberClick,
  variant = 'chart',
  showOverloadWarnings = true,
  ...widgetProps 
}: TeamWorkloadWidgetProps) {
  const { data: tasks, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/tasks'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  // Calculate workload data
  const workloadData: WorkloadData[] = tasks ? (() => {
    const memberWorkload = new Map<string, { 
      name: string; 
      tasks: number; 
      hours: number;
      completedTasks: number;
    }>();

    tasks.forEach((task: any) => {
      if (task.assignee) {
        const id = task.assignee.id;
        const name = `${task.assignee.firstName || ''} ${task.assignee.lastName || ''}`.trim() || task.assignee.email;
        
        if (!memberWorkload.has(id)) {
          memberWorkload.set(id, { name, tasks: 0, hours: 0, completedTasks: 0 });
        }

        const member = memberWorkload.get(id)!;
        member.tasks += 1;
        member.hours += task.estimatedHours || 8; // Default 8 hours per task
        
        if (task.status === 'completed') {
          member.completedTasks += 1;
        }
      }
    });

    const result: WorkloadData[] = Array.from(memberWorkload.entries()).map(([id, data]) => {
      // Determine workload status
      let status: 'normal' | 'overloaded' | 'underutilized' = 'normal';
      if (data.tasks > 10) status = 'overloaded';
      else if (data.tasks < 3) status = 'underutilized';

      return {
        assignee: data.name,
        tasks: data.tasks,
        hours: data.hours,
        status,
      };
    });

    return result.sort((a, b) => b.tasks - a.tasks).slice(0, 8);
  })() : [];

  const chartData = workloadData.length > 0 ? {
    labels: workloadData.map(item => 
      item.assignee.split(' ').map(n => n.charAt(0).toUpperCase() + n.slice(1)).join(' ')
    ),
    datasets: [
      {
        label: 'Active Tasks',
        data: workloadData.map(item => item.tasks),
        backgroundColor: workloadData.map(item => {
          switch (item.status) {
            case 'overloaded': return 'rgba(239, 68, 68, 0.8)';
            case 'underutilized': return 'rgba(251, 191, 36, 0.8)';
            default: return 'rgba(59, 130, 246, 0.8)';
          }
        }),
      },
    ],
  } : null;

  const handleBarClick = (label: string, value: number, datasetIndex: number, index: number) => {
    if (onMemberClick && workloadData[index]) {
      // In real app, you'd need to map back to member ID
      onMemberClick(`member-${index}`);
    }
  };

  const overloadedCount = workloadData.filter(item => item.status === 'overloaded').length;
  const underutilizedCount = workloadData.filter(item => item.status === 'underutilized').length;

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {workloadData.length > 0 ? (
          variant === 'chart' ? (
            <>
              <div className="flex-1 min-h-0">
                <BarChart
                  data={chartData!}
                  height={200}
                  onBarClick={handleBarClick}
                  options={{
                    scales: {
                      x: {
                        ticks: {
                          maxRotation: 45,
                          minRotation: 0,
                        },
                      },
                      y: {
                        title: {
                          display: true,
                          text: 'Task Count',
                        },
                      },
                    },
                  }}
                  data-testid={`team-workload-chart-${widgetProps.id}`}
                />
              </div>
              
              {/* Summary */}
              <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 bg-blue-50 rounded">
                  <div className="font-semibold text-blue-700">
                    {workloadData.filter(item => item.status === 'normal').length}
                  </div>
                  <div className="text-blue-600">Normal</div>
                </div>
                <div className="p-2 bg-red-50 rounded">
                  <div className="font-semibold text-red-700">{overloadedCount}</div>
                  <div className="text-red-600">Overloaded</div>
                </div>
                <div className="p-2 bg-yellow-50 rounded">
                  <div className="font-semibold text-yellow-700">{underutilizedCount}</div>
                  <div className="text-yellow-600">Under-utilized</div>
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-3 overflow-y-auto">
              {workloadData.map((item, index) => (
                <div 
                  key={index}
                  className="p-3 rounded-lg bg-muted/50 hover:bg-muted/80 transition-colors cursor-pointer"
                  onClick={() => onMemberClick?.(`member-${index}`)}
                  data-testid={`workload-member-${index}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={`https://avatar.vercel.sh/member-${index}`} />
                        <AvatarFallback className="text-xs">
                          {item.assignee.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="font-medium text-sm">{item.assignee}</span>
                    </div>
                    
                    <Badge 
                      variant="outline"
                      className={
                        item.status === 'overloaded' ? "text-red-600 border-red-200 bg-red-50" :
                        item.status === 'underutilized' ? "text-yellow-600 border-yellow-200 bg-yellow-50" :
                        "text-blue-600 border-blue-200 bg-blue-50"
                      }
                    >
                      {item.status}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>{item.tasks} tasks</span>
                    <span>{item.hours}h estimated</span>
                  </div>
                  
                  <Progress 
                    value={Math.min(100, (item.tasks / 10) * 100)} 
                    className="h-1"
                  />
                </div>
              ))}
            </div>
          )
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No workload data available</div>
          </div>
        )}

        {/* Overload warning */}
        {showOverloadWarnings && overloadedCount > 0 && (
          <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="h-4 w-4" />
              <span className="text-sm font-medium">
                {overloadedCount} team member{overloadedCount !== 1 ? 's' : ''} overloaded
              </span>
            </div>
          </div>
        )}
      </div>
    </Widget>
  );
}