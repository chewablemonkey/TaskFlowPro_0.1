import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { BarChart } from '@/components/charts';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  Clock,
  TrendingUp,
  AlertTriangle,
  CheckCircle
} from "lucide-react";
import type { WidgetProps, ResourceAllocationData } from '../types';

interface ResourceUtilizationWidgetProps extends Omit<WidgetProps, 'children'> {
  onMemberClick?: (memberId: string) => void;
  view?: 'utilization' | 'capacity' | 'allocation';
  showOverallocated?: boolean;
}

export function ResourceUtilizationWidget({ 
  onMemberClick,
  view = 'utilization',
  showOverallocated = true,
  ...widgetProps 
}: ResourceUtilizationWidgetProps) {
  const { data: tasks, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/tasks'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  // Calculate resource utilization metrics
  const resourceData: ResourceAllocationData[] = tasks ? (() => {
    const memberMap = new Map<string, ResourceAllocationData>();

    tasks.forEach((task: any) => {
      if (task.assignee) {
        const memberId = task.assignee.id;
        const memberName = `${task.assignee.firstName || ''} ${task.assignee.lastName || ''}`.trim() || task.assignee.email;
        
        if (!memberMap.has(memberId)) {
          memberMap.set(memberId, {
            memberId,
            memberName,
            allocatedHours: 0,
            actualHours: 0,
            utilization: 0,
            availability: 100, // Mock data
          });
        }

        const member = memberMap.get(memberId)!;
        member.allocatedHours += task.estimatedHours || 8;
        member.actualHours += task.actualHours || (task.status === 'completed' ? (task.estimatedHours || 8) : 0);
      }
    });

    // Calculate utilization and availability
    const result = Array.from(memberMap.values()).map(member => {
      const weeklyCapacity = 40; // 40 hours per week
      member.utilization = Math.round((member.allocatedHours / weeklyCapacity) * 100);
      member.availability = Math.max(0, 100 - member.utilization);
      return member;
    });

    return result.sort((a, b) => b.utilization - a.utilization);
  })() : [];

  const chartData = resourceData.length > 0 ? {
    labels: resourceData.map(member => 
      member.memberName.split(' ').map(n => n.charAt(0).toUpperCase() + n.slice(1)).join(' ')
    ),
    datasets: [
      {
        label: 'Utilization %',
        data: resourceData.map(member => member.utilization),
        backgroundColor: resourceData.map(member => 
          member.utilization > 100 ? 'rgba(239, 68, 68, 0.8)' :
          member.utilization > 80 ? 'rgba(245, 158, 11, 0.8)' :
          'rgba(16, 185, 129, 0.8)'
        ),
      },
    ],
  } : null;

  const handleMemberClick = (member: ResourceAllocationData) => {
    if (onMemberClick) {
      onMemberClick(member.memberId);
    }
  };

  // Calculate summary metrics
  const averageUtilization = resourceData.length > 0 
    ? Math.round(resourceData.reduce((sum, member) => sum + member.utilization, 0) / resourceData.length)
    : 0;
  
  const overallocatedCount = resourceData.filter(member => member.utilization > 100).length;
  const underutilizedCount = resourceData.filter(member => member.utilization < 60).length;
  const optimalCount = resourceData.filter(member => member.utilization >= 60 && member.utilization <= 100).length;

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {resourceData.length > 0 ? (
          view === 'utilization' ? (
            <>
              {/* Summary metrics */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="text-center p-2 bg-green-50 rounded">
                  <div className="text-sm font-bold text-green-700">{optimalCount}</div>
                  <div className="text-xs text-green-600">Optimal</div>
                </div>
                <div className="text-center p-2 bg-red-50 rounded">
                  <div className="text-sm font-bold text-red-700">{overallocatedCount}</div>
                  <div className="text-xs text-red-600">Overloaded</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="text-sm font-bold text-yellow-700">{underutilizedCount}</div>
                  <div className="text-xs text-yellow-600">Under-used</div>
                </div>
              </div>

              {/* Utilization chart */}
              <div className="flex-1 min-h-0">
                <BarChart
                  data={chartData!}
                  height={180}
                  options={{
                    scales: {
                      x: {
                        ticks: {
                          maxRotation: 45,
                          minRotation: 0,
                        },
                      },
                      y: {
                        beginAtZero: true,
                        title: {
                          display: true,
                          text: 'Utilization %',
                        },
                        ticks: {
                          callback: function(value) {
                            return value + '%';
                          },
                        },
                      },
                    },
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                  }}
                  data-testid={`resource-utilization-chart-${widgetProps.id}`}
                />
              </div>

              {/* Average utilization */}
              <div className="mt-3 p-2 bg-muted/50 rounded-lg">
                <div className="flex justify-between text-sm">
                  <span>Team Average</span>
                  <span className="font-medium">{averageUtilization}%</span>
                </div>
                <Progress value={Math.min(100, averageUtilization)} className="h-2 mt-1" />
              </div>
            </>
          ) : view === 'capacity' ? (
            <>
              {/* Capacity planning view */}
              <div className="space-y-3 overflow-y-auto">
                {resourceData.map((member) => (
                  <div 
                    key={member.memberId}
                    className="p-3 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => handleMemberClick(member)}
                    data-testid={`resource-member-${member.memberId}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={`https://avatar.vercel.sh/${member.memberId}`} />
                          <AvatarFallback className="text-xs">
                            {member.memberName.split(' ').map(n => n[0]).join('').toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium text-sm">{member.memberName}</span>
                      </div>
                      
                      <Badge 
                        variant="outline"
                        className={
                          member.utilization > 100 ? 'text-red-600 border-red-200 bg-red-50' :
                          member.utilization > 80 ? 'text-yellow-600 border-yellow-200 bg-yellow-50' :
                          member.utilization < 60 ? 'text-blue-600 border-blue-200 bg-blue-50' :
                          'text-green-600 border-green-200 bg-green-50'
                        }
                      >
                        {member.utilization}%
                      </Badge>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Allocated: {member.allocatedHours}h</span>
                        <span>Available: {Math.max(0, 40 - member.allocatedHours)}h</span>
                      </div>
                      <Progress 
                        value={Math.min(100, member.utilization)} 
                        className="h-2"
                      />
                    </div>

                    {member.utilization > 100 && showOverallocated && (
                      <div className="mt-2 flex items-center gap-1 text-xs text-red-600">
                        <AlertTriangle className="h-3 w-3" />
                        <span>Overallocated by {member.allocatedHours - 40}h</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          ) : (
            <>
              {/* Allocation view */}
              <div className="space-y-3 overflow-y-auto">
                <div className="text-center mb-4">
                  <div className="text-2xl font-bold text-foreground">{averageUtilization}%</div>
                  <div className="text-sm text-muted-foreground">Average Team Utilization</div>
                </div>

                {resourceData.slice(0, 5).map((member, index) => (
                  <div 
                    key={member.memberId}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => handleMemberClick(member)}
                  >
                    <div className="text-sm font-medium text-muted-foreground w-4">
                      #{index + 1}
                    </div>
                    
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={`https://avatar.vercel.sh/${member.memberId}`} />
                      <AvatarFallback className="text-xs">
                        {member.memberName.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{member.memberName}</div>
                      <div className="text-xs text-muted-foreground">
                        {member.allocatedHours}h allocated
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className={`text-sm font-medium ${
                        member.utilization > 100 ? 'text-red-600' :
                        member.utilization > 80 ? 'text-yellow-600' :
                        'text-green-600'
                      }`}>
                        {member.utilization}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No resource data available</div>
          </div>
        )}
      </div>
    </Widget>
  );
}