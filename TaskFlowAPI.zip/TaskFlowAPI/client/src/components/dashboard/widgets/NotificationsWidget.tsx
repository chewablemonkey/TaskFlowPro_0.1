import { useState } from 'react';
import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Bell, 
  AlertTriangle, 
  Info,
  CheckCircle,
  X,
  Eye,
  EyeOff
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { WidgetProps } from '../types';

interface Notification {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
  actionUrl?: string;
  metadata?: Record<string, any>;
}

interface NotificationsWidgetProps extends Omit<WidgetProps, 'children'> {
  onNotificationClick?: (notificationId: string) => void;
  onMarkAllRead?: () => void;
  showUnreadOnly?: boolean;
  maxNotifications?: number;
}

const notificationIcons = {
  info: Info,
  warning: AlertTriangle,
  error: AlertTriangle,
  success: CheckCircle,
};

const notificationColors = {
  info: 'text-blue-500 bg-blue-50 border-blue-200',
  warning: 'text-yellow-500 bg-yellow-50 border-yellow-200',
  error: 'text-red-500 bg-red-50 border-red-200',
  success: 'text-green-500 bg-green-50 border-green-200',
};

export function NotificationsWidget({ 
  onNotificationClick,
  onMarkAllRead,
  showUnreadOnly = false,
  maxNotifications = 10,
  ...widgetProps 
}: NotificationsWidgetProps) {
  const [localNotifications, setLocalNotifications] = useState<Notification[]>([]);

  const { data: tasks } = useQuery({
    queryKey: ['/api/tasks'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  const { data: projects } = useQuery({
    queryKey: ['/api/projects'],
  });

  // Generate notifications from tasks and projects data
  const notifications: Notification[] = (() => {
    const notificationList: Notification[] = [];
    const now = new Date();

    // Generate notifications from tasks
    if (tasks) {
      tasks.forEach((task: any) => {
        // Overdue task notifications
        if (task.dueDate && new Date(task.dueDate) < now && task.status !== 'completed') {
          notificationList.push({
            id: `overdue-task-${task.id}`,
            type: 'error',
            title: 'Task Overdue',
            message: `"${task.title}" was due ${formatDistanceToNow(new Date(task.dueDate), { addSuffix: true })}`,
            timestamp: new Date(task.dueDate),
            isRead: false,
            actionUrl: `/tasks/${task.id}`,
            metadata: { taskId: task.id, projectId: task.projectId },
          });
        }

        // Task completed notifications
        if (task.status === 'completed' && task.completedAt) {
          const completedAt = new Date(task.completedAt);
          if (now.getTime() - completedAt.getTime() < 24 * 60 * 60 * 1000) { // Last 24 hours
            notificationList.push({
              id: `completed-task-${task.id}`,
              type: 'success',
              title: 'Task Completed',
              message: `"${task.title}" has been completed`,
              timestamp: completedAt,
              isRead: false,
              actionUrl: `/tasks/${task.id}`,
              metadata: { taskId: task.id, projectId: task.projectId },
            });
          }
        }

        // High priority task assignments
        if (task.priority === 'high' && task.status !== 'completed') {
          notificationList.push({
            id: `high-priority-${task.id}`,
            type: 'warning',
            title: 'High Priority Task',
            message: `"${task.title}" requires immediate attention`,
            timestamp: new Date(task.updatedAt),
            isRead: Math.random() > 0.5, // Random read status for demo
            actionUrl: `/tasks/${task.id}`,
            metadata: { taskId: task.id, projectId: task.projectId },
          });
        }
      });
    }

    // Generate notifications from projects
    if (projects) {
      projects.forEach((project: any) => {
        // Project deadline approaching
        if (project.dueDate && project.status !== 'completed') {
          const dueDate = new Date(project.dueDate);
          const daysUntilDue = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          
          if (daysUntilDue <= 3 && daysUntilDue > 0) {
            notificationList.push({
              id: `project-deadline-${project.id}`,
              type: 'warning',
              title: 'Project Deadline Approaching',
              message: `"${project.name}" is due in ${daysUntilDue} day${daysUntilDue !== 1 ? 's' : ''}`,
              timestamp: new Date(project.updatedAt),
              isRead: false,
              actionUrl: `/projects/${project.id}`,
              metadata: { projectId: project.id },
            });
          }
        }

        // New project notifications
        const createdAt = new Date(project.createdAt);
        if (now.getTime() - createdAt.getTime() < 24 * 60 * 60 * 1000) { // Last 24 hours
          notificationList.push({
            id: `new-project-${project.id}`,
            type: 'info',
            title: 'New Project Created',
            message: `"${project.name}" has been created`,
            timestamp: createdAt,
            isRead: Math.random() > 0.3, // Random read status for demo
            actionUrl: `/projects/${project.id}`,
            metadata: { projectId: project.id },
          });
        }
      });
    }

    // Add some system notifications
    notificationList.push(
      {
        id: 'system-backup',
        type: 'info',
        title: 'System Backup',
        message: 'Daily backup completed successfully',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        isRead: true,
      },
      {
        id: 'maintenance-window',
        type: 'warning',
        title: 'Scheduled Maintenance',
        message: 'System maintenance scheduled for this weekend',
        timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        isRead: false,
      }
    );

    // Sort by timestamp (newest first) and apply filters
    let filtered = notificationList.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    if (showUnreadOnly) {
      filtered = filtered.filter(n => !n.isRead);
    }
    
    return filtered.slice(0, maxNotifications);
  })();

  const handleNotificationClick = (notification: Notification) => {
    if (onNotificationClick) {
      onNotificationClick(notification.id);
    }
  };

  const handleMarkAsRead = (notificationId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    // In real app, this would update the notification status
    console.log('Mark as read:', notificationId);
  };

  const handleMarkAllRead = () => {
    if (onMarkAllRead) {
      onMarkAllRead();
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <Widget 
      {...widgetProps}
      isLoading={false}
      error={null}
      onRefresh={() => {}}
      lastUpdated={new Date()}
      actions={[
        unreadCount > 0 && (
          <Button
            key="mark-all-read"
            variant="ghost"
            size="sm"
            onClick={handleMarkAllRead}
            className="h-8 px-2 text-xs"
            data-testid="mark-all-read-button"
          >
            Mark all read
          </Button>
        ),
      ].filter(Boolean)}
    >
      <div className="h-full flex flex-col">
        {notifications.length > 0 ? (
          <>
            {/* Header */}
            <div className="flex items-center justify-between mb-4 pb-2 border-b">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Notifications</span>
              </div>
              {unreadCount > 0 && (
                <Badge variant="destructive" className="text-xs">
                  {unreadCount} new
                </Badge>
              )}
            </div>

            {/* Notifications list */}
            <div className="space-y-2 overflow-y-auto">
              {notifications.map((notification) => {
                const Icon = notificationIcons[notification.type];
                
                return (
                  <div 
                    key={notification.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors hover:bg-muted/50 ${
                      !notification.isRead ? 'border-l-4 border-l-primary bg-muted/20' : ''
                    }`}
                    onClick={() => handleNotificationClick(notification)}
                    data-testid={`notification-${notification.id}`}
                  >
                    <div className="flex items-start gap-3">
                      {/* Icon */}
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 border ${notificationColors[notification.type]}`}>
                        <Icon className="h-3 w-3" />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className={`text-sm font-medium ${!notification.isRead ? 'text-foreground' : 'text-muted-foreground'}`}>
                            {notification.title}
                          </span>
                          <div className="flex items-center gap-1">
                            {!notification.isRead && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => handleMarkAsRead(notification.id, e)}
                                className="h-6 w-6 p-0"
                                data-testid={`mark-read-${notification.id}`}
                              >
                                <Eye className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                        
                        <p className={`text-sm ${!notification.isRead ? 'text-foreground' : 'text-muted-foreground'} mb-1`}>
                          {notification.message}
                        </p>
                        
                        <div className="text-xs text-muted-foreground">
                          {formatDistanceToNow(notification.timestamp, { addSuffix: true })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Bell className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">
              {showUnreadOnly ? 'No unread notifications' : 'No notifications'}
            </div>
          </div>
        )}
      </div>
    </Widget>
  );
}