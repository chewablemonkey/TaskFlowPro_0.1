import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Clock, 
  AlertTriangle, 
  Calendar,
  Target,
  CheckCircle
} from "lucide-react";
import { format, differenceInDays, isAfter, isBefore, addDays } from "date-fns";
import type { WidgetProps, DeadlineAlert } from '../types';

interface DeadlinesWidgetProps extends Omit<WidgetProps, 'children'> {
  onDeadlineClick?: (id: string, type: 'task' | 'project') => void;
  showOverdueOnly?: boolean;
  daysAhead?: number;
  maxItems?: number;
}

export function DeadlinesWidget({ 
  onDeadlineClick,
  showOverdueOnly = false,
  daysAhead = 7,
  maxItems = 8,
  ...widgetProps 
}: DeadlinesWidgetProps) {
  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ['/api/projects'],
  });

  const isLoading = tasksLoading || projectsLoading;

  // Generate deadline alerts
  const deadlines: DeadlineAlert[] = (() => {
    const deadlineList: DeadlineAlert[] = [];
    const now = new Date();
    const futureLimit = addDays(now, daysAhead);

    // Add task deadlines
    if (tasks) {
      tasks.forEach((task: any) => {
        if (task.dueDate && task.status !== 'completed') {
          const dueDate = new Date(task.dueDate);
          const isOverdue = isAfter(now, dueDate);
          const isUpcoming = !isOverdue && isBefore(dueDate, futureLimit);

          if ((showOverdueOnly && isOverdue) || (!showOverdueOnly && (isOverdue || isUpcoming))) {
            deadlineList.push({
              id: task.id,
              type: 'task',
              title: task.title,
              dueDate,
              priority: task.priority || 'medium',
              status: isOverdue ? 'overdue' : 'upcoming',
              assignee: task.assignee ? `${task.assignee.firstName || ''} ${task.assignee.lastName || ''}`.trim() : undefined,
              projectName: task.project?.name,
            });
          }
        }
      });
    }

    // Add project deadlines
    if (projects) {
      projects.forEach((project: any) => {
        if (project.dueDate && project.status !== 'completed') {
          const dueDate = new Date(project.dueDate);
          const isOverdue = isAfter(now, dueDate);
          const isUpcoming = !isOverdue && isBefore(dueDate, futureLimit);

          if ((showOverdueOnly && isOverdue) || (!showOverdueOnly && (isOverdue || isUpcoming))) {
            deadlineList.push({
              id: project.id,
              type: 'project',
              title: project.name,
              dueDate,
              priority: 'high', // Projects are generally high priority
              status: isOverdue ? 'overdue' : 'upcoming',
            });
          }
        }
      });
    }

    // Sort by due date (most urgent first) and limit
    return deadlineList
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
      .slice(0, maxItems);
  })();

  const handleDeadlineClick = (deadline: DeadlineAlert) => {
    if (onDeadlineClick) {
      onDeadlineClick(deadline.id, deadline.type);
    }
  };

  const refetch = () => {
    // In real app, refetch both queries
  };

  const overdueCount = deadlines.filter(d => d.status === 'overdue').length;
  const upcomingCount = deadlines.filter(d => d.status === 'upcoming').length;

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={null}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {deadlines.length > 0 ? (
          <>
            {/* Summary header */}
            <div className="flex items-center justify-between mb-4 pb-2 border-b">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Deadlines</span>
              </div>
              <div className="flex gap-1">
                {overdueCount > 0 && (
                  <Badge variant="destructive" className="text-xs">
                    {overdueCount} overdue
                  </Badge>
                )}
                {upcomingCount > 0 && (
                  <Badge variant="outline" className="text-xs text-yellow-600 border-yellow-200">
                    {upcomingCount} upcoming
                  </Badge>
                )}
              </div>
            </div>

            {/* Deadline list */}
            <div className="space-y-3 overflow-y-auto">
              {deadlines.map((deadline) => {
                const daysRemaining = differenceInDays(deadline.dueDate, new Date());
                const isOverdue = deadline.status === 'overdue';
                
                return (
                  <div 
                    key={`${deadline.type}-${deadline.id}`}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors hover:bg-muted/50 ${
                      isOverdue 
                        ? 'border-red-200 bg-red-50/50' 
                        : 'border-yellow-200 bg-yellow-50/50'
                    }`}
                    onClick={() => handleDeadlineClick(deadline)}
                    data-testid={`deadline-item-${deadline.type}-${deadline.id}`}
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {deadline.type === 'project' ? (
                          <Target className="h-4 w-4 text-indigo-500" />
                        ) : (
                          <CheckCircle className="h-4 w-4 text-blue-500" />
                        )}
                        <span className="font-medium text-sm">{deadline.title}</span>
                        <Badge variant="outline" className="text-xs">
                          {deadline.type}
                        </Badge>
                      </div>
                      
                      {isOverdue ? (
                        <AlertTriangle className="h-4 w-4 text-red-500" />
                      ) : (
                        <Clock className="h-4 w-4 text-yellow-500" />
                      )}
                    </div>

                    {/* Due date and time remaining */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        {format(deadline.dueDate, 'MMM dd, yyyy')}
                      </div>
                      
                      <span className={`text-sm font-medium ${
                        isOverdue ? 'text-red-600' : 'text-yellow-600'
                      }`}>
                        {isOverdue 
                          ? `${Math.abs(daysRemaining)} days overdue`
                          : `${daysRemaining} days left`
                        }
                      </span>
                    </div>

                    {/* Additional info */}
                    <div className="flex items-center justify-between">
                      {deadline.assignee && (
                        <div className="flex items-center gap-2">
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={`https://avatar.vercel.sh/${deadline.assignee}`} />
                            <AvatarFallback className="text-xs">
                              {deadline.assignee.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-muted-foreground">{deadline.assignee}</span>
                        </div>
                      )}
                      
                      {deadline.projectName && deadline.type === 'task' && (
                        <Badge variant="secondary" className="text-xs">
                          {deadline.projectName}
                        </Badge>
                      )}
                      
                      <Badge 
                        variant="outline"
                        className={`text-xs ${
                          deadline.priority === 'high' ? 'text-red-600 border-red-200' :
                          deadline.priority === 'medium' ? 'text-yellow-600 border-yellow-200' :
                          'text-green-600 border-green-200'
                        }`}
                      >
                        {deadline.priority}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
            <div className="text-sm text-muted-foreground">
              {showOverdueOnly ? 'No overdue items' : 'No upcoming deadlines'}
            </div>
          </div>
        )}
      </div>
    </Widget>
  );
}