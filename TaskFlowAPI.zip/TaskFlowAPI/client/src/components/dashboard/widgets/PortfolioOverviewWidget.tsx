import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { DonutChart, BarChart } from '@/components/charts';
import { chartColors } from '@/components/charts/BaseChart';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  CheckCircle,
  Briefcase,
  Target,
  DollarSign
} from "lucide-react";
import type { WidgetProps } from '../types';

interface ProjectHealth {
  id: string;
  name: string;
  status: 'healthy' | 'at_risk' | 'critical';
  completion: number;
  daysRemaining: number;
  budget?: {
    allocated: number;
    spent: number;
    remaining: number;
  };
}

interface PortfolioOverviewWidgetProps extends Omit<WidgetProps, 'children'> {
  onProjectClick?: (projectId: string) => void;
  showBudgets?: boolean;
  view?: 'overview' | 'health' | 'budget';
}

export function PortfolioOverviewWidget({ 
  onProjectClick,
  showBudgets = false,
  view = 'overview',
  ...widgetProps 
}: PortfolioOverviewWidgetProps) {
  const { data: projects, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/projects'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  const { data: tasks } = useQuery({
    queryKey: ['/api/tasks'],
  });

  // Calculate portfolio metrics
  const portfolioData = projects && tasks ? (() => {
    const projectHealths: ProjectHealth[] = projects.map((project: any) => {
      const projectTasks = tasks.filter((task: any) => task.projectId === project.id);
      const completedTasks = projectTasks.filter((task: any) => task.status === 'completed').length;
      const completion = projectTasks.length > 0 ? Math.round((completedTasks / projectTasks.length) * 100) : 0;
      
      // Calculate days remaining
      const daysRemaining = project.dueDate ? 
        Math.max(0, Math.ceil((new Date(project.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))) : 0;
      
      // Determine health status
      let status: 'healthy' | 'at_risk' | 'critical' = 'healthy';
      if (completion < 25 && daysRemaining < 7) status = 'critical';
      else if (completion < 50 && daysRemaining < 14) status = 'at_risk';
      else if (project.status === 'cancelled') status = 'critical';
      
      // Mock budget data for demo
      const budget = showBudgets ? {
        allocated: Math.floor(Math.random() * 100000) + 20000,
        spent: Math.floor(Math.random() * 60000) + 10000,
        remaining: 0,
      } : undefined;
      
      if (budget) {
        budget.remaining = budget.allocated - budget.spent;
      }

      return {
        id: project.id,
        name: project.name,
        status,
        completion,
        daysRemaining,
        budget,
      };
    });

    // Calculate portfolio summary
    const totalProjects = projects.length;
    const healthyProjects = projectHealths.filter(p => p.status === 'healthy').length;
    const atRiskProjects = projectHealths.filter(p => p.status === 'at_risk').length;
    const criticalProjects = projectHealths.filter(p => p.status === 'critical').length;
    
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter((task: any) => task.status === 'completed').length;
    const overallCompletion = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    
    // Budget summary
    const totalBudget = showBudgets ? projectHealths.reduce((sum, p) => sum + (p.budget?.allocated || 0), 0) : 0;
    const spentBudget = showBudgets ? projectHealths.reduce((sum, p) => sum + (p.budget?.spent || 0), 0) : 0;
    const budgetUtilization = totalBudget > 0 ? Math.round((spentBudget / totalBudget) * 100) : 0;

    return {
      summary: {
        totalProjects,
        healthyProjects,
        atRiskProjects,
        criticalProjects,
        overallCompletion,
        totalBudget,
        spentBudget,
        budgetUtilization,
      },
      projects: projectHealths.slice(0, 6), // Top 6 projects
    };
  })() : null;

  const statusData = portfolioData ? {
    labels: ['Healthy', 'At Risk', 'Critical'],
    datasets: [{
      data: [
        portfolioData.summary.healthyProjects,
        portfolioData.summary.atRiskProjects,
        portfolioData.summary.criticalProjects,
      ],
      backgroundColor: [
        chartColors.status.completed,
        '#f59e0b',
        chartColors.status.cancelled,
      ],
    }],
  } : null;

  const completionData = portfolioData ? {
    labels: portfolioData.projects.map(p => p.name.length > 12 ? p.name.substring(0, 12) + '...' : p.name),
    datasets: [{
      label: 'Completion %',
      data: portfolioData.projects.map(p => p.completion),
      backgroundColor: portfolioData.projects.map(p => 
        p.status === 'critical' ? 'rgba(239, 68, 68, 0.8)' :
        p.status === 'at_risk' ? 'rgba(245, 158, 11, 0.8)' :
        'rgba(16, 185, 129, 0.8)'
      ),
    }],
  } : null;

  const handleProjectClick = (projectId: string) => {
    if (onProjectClick) {
      onProjectClick(projectId);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {portfolioData ? (
          view === 'overview' ? (
            <>
              {/* Overview metrics */}
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="text-center p-2 bg-green-50 rounded-lg">
                  <div className="text-lg font-bold text-green-700">
                    {portfolioData.summary.healthyProjects}
                  </div>
                  <div className="text-xs text-green-600">Healthy</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded-lg">
                  <div className="text-lg font-bold text-yellow-700">
                    {portfolioData.summary.atRiskProjects}
                  </div>
                  <div className="text-xs text-yellow-600">At Risk</div>
                </div>
                <div className="text-center p-2 bg-red-50 rounded-lg">
                  <div className="text-lg font-bold text-red-700">
                    {portfolioData.summary.criticalProjects}
                  </div>
                  <div className="text-xs text-red-600">Critical</div>
                </div>
              </div>

              {/* Portfolio health chart */}
              <div className="flex-1 min-h-0">
                <DonutChart
                  data={statusData!}
                  height={150}
                  centerText={portfolioData.summary.totalProjects.toString()}
                  centerSubtext="Total Projects"
                  data-testid={`portfolio-health-chart-${widgetProps.id}`}
                />
              </div>

              {/* Overall completion */}
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Portfolio Completion</span>
                  <span className="font-medium">{portfolioData.summary.overallCompletion}%</span>
                </div>
                <Progress value={portfolioData.summary.overallCompletion} className="h-2" />
              </div>

              {/* Budget overview if enabled */}
              {showBudgets && portfolioData.summary.totalBudget > 0 && (
                <div className="mt-3 p-2 bg-muted/50 rounded-lg">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Budget Utilization</span>
                    <span className="font-medium">{portfolioData.summary.budgetUtilization}%</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatCurrency(portfolioData.summary.spentBudget)} of {formatCurrency(portfolioData.summary.totalBudget)}
                  </div>
                </div>
              )}
            </>
          ) : view === 'health' ? (
            <>
              {/* Project health list */}
              <div className="space-y-2 overflow-y-auto">
                {portfolioData.projects.map((project) => (
                  <div 
                    key={project.id}
                    className="p-3 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => handleProjectClick(project.id)}
                    data-testid={`portfolio-project-${project.id}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm truncate">{project.name}</span>
                      <Badge 
                        variant="outline"
                        className={
                          project.status === 'healthy' ? 'text-green-600 border-green-200' :
                          project.status === 'at_risk' ? 'text-yellow-600 border-yellow-200' :
                          'text-red-600 border-red-200'
                        }
                      >
                        {project.status === 'at_risk' ? 'At Risk' : project.status}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>Completion</span>
                      <span>{project.completion}%</span>
                    </div>
                    <Progress value={project.completion} className="h-1 mb-2" />
                    
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{project.daysRemaining} days remaining</span>
                      {project.budget && (
                        <span>{formatCurrency(project.budget.spent)} spent</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <>
              {/* Budget view */}
              <div className="flex-1">
                <BarChart
                  data={completionData!}
                  height={200}
                  options={{
                    scales: {
                      y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                          display: true,
                          text: 'Completion %',
                        },
                      },
                    },
                  }}
                  data-testid={`portfolio-completion-chart-${widgetProps.id}`}
                />
              </div>
            </>
          )
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Briefcase className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No portfolio data available</div>
          </div>
        )}
      </div>
    </Widget>
  );
}