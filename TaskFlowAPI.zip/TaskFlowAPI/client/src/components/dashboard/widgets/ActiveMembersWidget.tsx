import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  Circle,
  CheckCircle,
  Clock,
  MessageCircle
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { WidgetProps, ActiveMember } from '../types';

interface ActiveMembersWidgetProps extends Omit<WidgetProps, 'children'> {
  onMemberClick?: (memberId: string) => void;
  showOnlineOnly?: boolean;
  maxMembers?: number;
}

const statusIndicators = {
  online: { color: 'bg-green-500', icon: Circle },
  offline: { color: 'bg-gray-400', icon: Circle },
  busy: { color: 'bg-red-500', icon: Circle },
};

export function ActiveMembersWidget({ 
  onMemberClick,
  showOnlineOnly = false,
  maxMembers = 8,
  ...widgetProps 
}: ActiveMembersWidgetProps) {
  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ['/api/projects'],
  });

  const isLoading = tasksLoading || projectsLoading;

  // Generate active members data
  const activeMembers: ActiveMember[] = (() => {
    const memberMap = new Map<string, ActiveMember>();

    if (tasks) {
      tasks.forEach((task: any) => {
        if (task.assignee) {
          const memberId = task.assignee.id;
          const memberName = `${task.assignee.firstName || ''} ${task.assignee.lastName || ''}`.trim() || task.assignee.email;
          
          if (!memberMap.has(memberId)) {
            // Mock status and activity for demo
            const statuses: ('online' | 'offline' | 'busy')[] = ['online', 'offline', 'busy'];
            const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
            
            memberMap.set(memberId, {
              id: memberId,
              name: memberName,
              avatar: task.assignee.profileImageUrl,
              status: randomStatus,
              lastActive: new Date(Date.now() - Math.random() * 86400000), // Random within last 24h
            });
          }

          const member = memberMap.get(memberId)!;
          
          // Set current task if in progress
          if (task.status === 'in_progress' && !member.currentTask) {
            member.currentTask = {
              id: task.id,
              title: task.title,
              progress: Math.floor(Math.random() * 80) + 10, // Mock progress 10-90%
            };
          }
        }
      });
    }

    const result = Array.from(memberMap.values());
    
    // Filter online only if requested
    const filtered = showOnlineOnly 
      ? result.filter(member => member.status === 'online')
      : result;
    
    // Sort by status (online first) then by last active
    return filtered
      .sort((a, b) => {
        if (a.status === 'online' && b.status !== 'online') return -1;
        if (b.status === 'online' && a.status !== 'online') return 1;
        return b.lastActive.getTime() - a.lastActive.getTime();
      })
      .slice(0, maxMembers);
  })();

  const handleMemberClick = (member: ActiveMember) => {
    if (onMemberClick) {
      onMemberClick(member.id);
    }
  };

  const refetch = () => {
    // In real app, refetch both queries
  };

  const onlineCount = activeMembers.filter(m => m.status === 'online').length;
  const busyCount = activeMembers.filter(m => m.status === 'busy').length;
  const totalMembers = activeMembers.length;

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={null}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {activeMembers.length > 0 ? (
          <>
            {/* Header with status summary */}
            <div className="flex items-center justify-between mb-4 pb-2 border-b">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Team Status</span>
              </div>
              <div className="flex gap-1">
                <Badge variant="outline" className="text-xs text-green-600 border-green-200">
                  {onlineCount} online
                </Badge>
                {busyCount > 0 && (
                  <Badge variant="outline" className="text-xs text-red-600 border-red-200">
                    {busyCount} busy
                  </Badge>
                )}
              </div>
            </div>

            {/* Members list */}
            <div className="space-y-3 overflow-y-auto">
              {activeMembers.map((member) => {
                const statusConfig = statusIndicators[member.status];
                const StatusIcon = statusConfig.icon;
                
                return (
                  <div 
                    key={member.id}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => handleMemberClick(member)}
                    data-testid={`active-member-${member.id}`}
                  >
                    {/* Avatar with status indicator */}
                    <div className="relative">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={member.avatar || `https://avatar.vercel.sh/${member.id}`} />
                        <AvatarFallback className="text-sm">
                          {member.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background ${statusConfig.color}`} />
                    </div>

                    {/* Member info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm truncate">{member.name}</span>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            member.status === 'online' ? 'text-green-600 border-green-200' :
                            member.status === 'busy' ? 'text-red-600 border-red-200' :
                            'text-gray-600 border-gray-200'
                          }`}
                        >
                          {member.status}
                        </Badge>
                      </div>
                      
                      {/* Current task */}
                      {member.currentTask ? (
                        <div className="space-y-1">
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span className="truncate">{member.currentTask.title}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Progress 
                              value={member.currentTask.progress} 
                              className="h-1 flex-1"
                            />
                            <span className="text-xs text-muted-foreground">
                              {member.currentTask.progress}%
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground">
                          {member.status === 'online' ? 'Available' : `Last seen ${formatDistanceToNow(member.lastActive, { addSuffix: true })}`}
                        </div>
                      )}
                    </div>

                    {/* Action indicator */}
                    {member.status === 'online' && (
                      <MessageCircle className="h-4 w-4 text-muted-foreground hover:text-primary" />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Team stats */}
            <div className="mt-4 pt-3 border-t grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 bg-green-50 rounded">
                <div className="font-semibold text-green-700">{onlineCount}</div>
                <div className="text-green-600">Online</div>
              </div>
              <div className="p-2 bg-red-50 rounded">
                <div className="font-semibold text-red-700">{busyCount}</div>
                <div className="text-red-600">Busy</div>
              </div>
              <div className="p-2 bg-gray-50 rounded">
                <div className="font-semibold text-gray-700">{totalMembers - onlineCount - busyCount}</div>
                <div className="text-gray-600">Away</div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No team members found</div>
          </div>
        )}
      </div>
    </Widget>
  );
}