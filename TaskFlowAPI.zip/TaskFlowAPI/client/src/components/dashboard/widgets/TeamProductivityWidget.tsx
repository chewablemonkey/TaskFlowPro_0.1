import { useMemo } from 'react';
import { Widget } from '../Widget';
import { BarChart } from '@/components/charts';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { WidgetErrorBoundary } from '../ErrorBoundary';
import { useTeamProductivityData } from '@/hooks/useDashboardData';
import { useNavigationHelpers } from '@/hooks/useNavigationHelpers';
import { exportTeamProductivityData, exportChartData } from '@/lib/exportUtils';
import { Users, Download, ExternalLink } from "lucide-react";
import type { WidgetProps, TeamProductivityData } from '../types';

interface TeamProductivityWidgetProps extends Omit<WidgetProps, 'children'> {
  onMemberClick?: (memberId: string) => void;
  variant?: 'chart' | 'list';
  enableNavigation?: boolean;
  enableExport?: boolean;
}

function TeamProductivityWidgetInner({ 
  onMemberClick,
  variant = 'chart',
  enableNavigation = true,
  enableExport = true,
  ...widgetProps 
}: TeamProductivityWidgetProps) {
  const { data: productivityData, isLoading, error, refetch, lastUpdated } = useTeamProductivityData(widgetProps.refreshInterval);
  const { navigateToTasks, navigateToTeam } = useNavigationHelpers();

  // Memoized chart data transformation
  const chartData = useMemo(() => {
    if (!productivityData || productivityData.length === 0) return null;

    return {
      labels: productivityData.map(member => 
        member.memberName.split(' ').map(n => n.charAt(0).toUpperCase() + n.slice(1)).join(' ')
      ),
      datasets: [
        {
          label: 'Completed Tasks',
          data: productivityData.map(member => member.tasksCompleted),
          backgroundColor: 'rgba(59, 130, 246, 0.8)',
          borderColor: 'rgb(59, 130, 246)',
        },
        {
          label: 'In Progress',
          data: productivityData.map(member => member.tasksInProgress),
          backgroundColor: 'rgba(249, 115, 22, 0.8)',
          borderColor: 'rgb(249, 115, 22)',
        },
      ],
    };
  }, [productivityData]);


  // Handle chart clicks with navigation
  const handleMemberClick = (label: string, value: number, datasetIndex: number, index: number) => {
    if (!productivityData || !productivityData[index]) return;
    
    const member = productivityData[index];
    
    // Custom callback first
    if (onMemberClick) {
      onMemberClick(member.memberId);
    }
    
    // Navigate to tasks filtered by assignee if enabled
    if (enableNavigation) {
      navigateToTasks({ assignee: member.memberId });
    }
  };

  // Handle list item clicks
  const handleListMemberClick = (memberId: string) => {
    // Custom callback first
    if (onMemberClick) {
      onMemberClick(memberId);
    }
    
    // Navigate to tasks filtered by assignee if enabled
    if (enableNavigation) {
      navigateToTasks({ assignee: memberId });
    }
  };

  // Export functionality
  const handleExportCSV = () => {
    if (productivityData && productivityData.length > 0) {
      exportTeamProductivityData(productivityData);
    }
  };

  const handleExportChart = () => {
    if (chartData) {
      exportChartData(chartData, `team-productivity-chart-${new Date().toISOString().split('T')[0]}.csv`);
    }
  };

  // Widget actions
  const actions = enableExport ? [
    <Button
      key="export-csv"
      variant="ghost"
      size="sm"
      onClick={handleExportCSV}
      className="h-8 w-8 p-0"
      title="Export as CSV"
      data-testid={`export-csv-${widgetProps.id}`}
    >
      <Download className="h-3 w-3" />
    </Button>,
    enableNavigation && (
      <Button
        key="view-team"
        variant="ghost"
        size="sm"
        onClick={() => navigateToTeam()}
        className="h-8 w-8 p-0"
        title="View team page"
        data-testid={`view-team-${widgetProps.id}`}
      >
        <ExternalLink className="h-3 w-3" />
      </Button>
    )
  ].filter(Boolean) : [];

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error?.message || null}
      onRefresh={refetch}
      lastUpdated={lastUpdated}
      actions={actions}
    >
      <div className="h-full flex flex-col">
        {productivityData && productivityData.length > 0 ? (
          variant === 'chart' ? (
            <div className="h-full">
              <BarChart
                data={chartData!}
                height={280}
                onBarClick={handleMemberClick}
                stacked={false}
                options={{
                  scales: {
                    x: {
                      ticks: {
                        maxRotation: 45,
                        minRotation: 0,
                      },
                    },
                  },
                }}
                data-testid={`team-productivity-chart-${widgetProps.id}`}
              />
            </div>
          ) : (
            <div className="space-y-3 overflow-y-auto">
              {productivityData.map((member, index) => (
                <div 
                  key={member.memberId}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted/80 transition-colors cursor-pointer"
                  onClick={() => handleListMemberClick(member.memberId)}
                  data-testid={`team-member-${member.memberId}`}
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={`https://avatar.vercel.sh/${member.memberId}`} />
                      <AvatarFallback className="text-xs">
                        {member.memberName.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-sm">{member.memberName}</div>
                      <div className="text-xs text-muted-foreground">
                        {member.tasksCompleted} completed, {member.tasksInProgress} in progress
                      </div>
                    </div>
                  </div>
                  
                  <Badge 
                    variant="outline" 
                    className={
                      member.efficiency >= 80 ? "text-green-600 border-green-200" :
                      member.efficiency >= 60 ? "text-yellow-600 border-yellow-200" :
                      "text-red-600 border-red-200"
                    }
                  >
                    {member.efficiency}%
                  </Badge>
                </div>
              ))}
            </div>
          )
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No team data available</div>
          </div>
        )}
      </div>
    </Widget>
  );
}

// Export the component wrapped with error boundary
export function TeamProductivityWidget(props: TeamProductivityWidgetProps) {
  return (
    <WidgetErrorBoundary widgetId={props.id}>
      <TeamProductivityWidgetInner {...props} />
    </WidgetErrorBoundary>
  );
}