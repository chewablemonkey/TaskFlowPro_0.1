import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  AlertTriangle, 
  Shield,
  Clock,
  TrendingDown,
  Target,
  Users,
  Calendar,
  DollarSign
} from "lucide-react";
import { differenceInDays, isAfter } from "date-fns";
import type { WidgetProps } from '../types';

interface RiskIndicator {
  id: string;
  type: 'schedule' | 'budget' | 'resource' | 'quality' | 'scope';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  impact: number; // 1-100
  probability: number; // 1-100
  riskScore: number; // calculated
  affectedProjects: string[];
  mitigationActions?: string[];
}

interface RiskIndicatorsWidgetProps extends Omit<WidgetProps, 'children'> {
  onRiskClick?: (riskId: string) => void;
  showMitigations?: boolean;
  severityFilter?: 'all' | 'high' | 'critical';
}

const riskIcons = {
  schedule: Clock,
  budget: DollarSign,
  resource: Users,
  quality: Shield,
  scope: Target,
};

const severityColors = {
  low: 'text-green-600 border-green-200 bg-green-50',
  medium: 'text-yellow-600 border-yellow-200 bg-yellow-50',
  high: 'text-orange-600 border-orange-200 bg-orange-50',
  critical: 'text-red-600 border-red-200 bg-red-50',
};

export function RiskIndicatorsWidget({ 
  onRiskClick,
  showMitigations = true,
  severityFilter = 'all',
  ...widgetProps 
}: RiskIndicatorsWidgetProps) {
  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ['/api/projects'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
  });

  const isLoading = projectsLoading || tasksLoading;

  // Generate risk indicators from projects and tasks data
  const riskIndicators: RiskIndicator[] = projects && tasks ? (() => {
    const risks: RiskIndicator[] = [];
    const now = new Date();

    // Analyze schedule risks
    projects.forEach((project: any) => {
      if (project.dueDate && project.status !== 'completed') {
        const dueDate = new Date(project.dueDate);
        const daysRemaining = differenceInDays(dueDate, now);
        const isOverdue = isAfter(now, dueDate);
        
        const projectTasks = tasks.filter((task: any) => task.projectId === project.id);
        const completedTasks = projectTasks.filter((task: any) => task.status === 'completed').length;
        const completion = projectTasks.length > 0 ? (completedTasks / projectTasks.length) * 100 : 0;
        
        // Schedule risk based on progress vs time remaining
        if (isOverdue || (daysRemaining < 7 && completion < 75)) {
          risks.push({
            id: `schedule-${project.id}`,
            type: 'schedule',
            severity: isOverdue ? 'critical' : daysRemaining < 3 ? 'high' : 'medium',
            title: isOverdue ? 'Project Overdue' : 'Schedule Risk',
            description: isOverdue 
              ? `${project.name} is ${Math.abs(daysRemaining)} days overdue`
              : `${project.name} may miss deadline (${completion.toFixed(0)}% complete, ${daysRemaining} days left)`,
            impact: isOverdue ? 90 : 70,
            probability: isOverdue ? 100 : 75,
            riskScore: 0, // Will be calculated
            affectedProjects: [project.id],
            mitigationActions: isOverdue 
              ? ['Reassign resources', 'Reduce scope', 'Extend deadline']
              : ['Increase team size', 'Prioritize critical tasks', 'Daily standups'],
          });
        }
      }
    });

    // Analyze resource risks
    const memberWorkload = new Map<string, { tasks: number; projects: Set<string> }>();
    tasks.forEach((task: any) => {
      if (task.assignee && task.status !== 'completed') {
        const memberId = task.assignee.id;
        if (!memberWorkload.has(memberId)) {
          memberWorkload.set(memberId, { tasks: 0, projects: new Set() });
        }
        const workload = memberWorkload.get(memberId)!;
        workload.tasks += 1;
        workload.projects.add(task.projectId);
      }
    });

    // Check for overallocated team members
    memberWorkload.forEach((workload, memberId) => {
      if (workload.tasks > 8) { // More than 8 active tasks
        risks.push({
          id: `resource-${memberId}`,
          type: 'resource',
          severity: workload.tasks > 12 ? 'critical' : 'high',
          title: 'Resource Overallocation',
          description: `Team member overloaded with ${workload.tasks} active tasks`,
          impact: 60,
          probability: 80,
          riskScore: 0,
          affectedProjects: Array.from(workload.projects),
          mitigationActions: ['Redistribute tasks', 'Hire additional resources', 'Reduce task scope'],
        });
      }
    });

    // Quality risks - high number of overdue tasks
    projects.forEach((project: any) => {
      const projectTasks = tasks.filter((task: any) => task.projectId === project.id);
      const overdueTasks = projectTasks.filter((task: any) => 
        task.dueDate && isAfter(now, new Date(task.dueDate)) && task.status !== 'completed'
      );
      
      if (overdueTasks.length > 3) {
        risks.push({
          id: `quality-${project.id}`,
          type: 'quality',
          severity: overdueTasks.length > 6 ? 'critical' : 'high',
          title: 'Quality Risk',
          description: `${project.name} has ${overdueTasks.length} overdue tasks`,
          impact: 70,
          probability: 85,
          riskScore: 0,
          affectedProjects: [project.id],
          mitigationActions: ['Code review', 'QA testing', 'Task prioritization'],
        });
      }
    });

    // Mock budget risks for demo
    if (projects.length > 0) {
      const randomProject = projects[Math.floor(Math.random() * projects.length)];
      risks.push({
        id: `budget-${randomProject.id}`,
        type: 'budget',
        severity: 'medium',
        title: 'Budget Risk',
        description: `${randomProject.name} spending tracking shows potential overrun`,
        impact: 50,
        probability: 60,
        riskScore: 0,
        affectedProjects: [randomProject.id],
        mitigationActions: ['Budget review', 'Cost optimization', 'Scope adjustment'],
      });
    }

    // Calculate risk scores and sort by severity
    risks.forEach(risk => {
      risk.riskScore = Math.round((risk.impact * risk.probability) / 100);
    });

    // Filter by severity if specified
    const filtered = severityFilter === 'all' 
      ? risks 
      : risks.filter(risk => 
          severityFilter === 'high' ? ['high', 'critical'].includes(risk.severity) :
          risk.severity === severityFilter
        );

    return filtered.sort((a, b) => b.riskScore - a.riskScore).slice(0, 8);
  })() : [];

  const handleRiskClick = (risk: RiskIndicator) => {
    if (onRiskClick) {
      onRiskClick(risk.id);
    }
  };

  const refetch = () => {
    // In real app, refetch both queries
  };

  // Calculate summary metrics
  const criticalCount = riskIndicators.filter(r => r.severity === 'critical').length;
  const highCount = riskIndicators.filter(r => r.severity === 'high').length;
  const totalRiskScore = riskIndicators.reduce((sum, risk) => sum + risk.riskScore, 0);
  const averageRiskScore = riskIndicators.length > 0 ? Math.round(totalRiskScore / riskIndicators.length) : 0;

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={null}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {riskIndicators.length > 0 ? (
          <>
            {/* Risk summary */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="text-center p-2 bg-red-50 rounded">
                <div className="text-sm font-bold text-red-700">{criticalCount}</div>
                <div className="text-xs text-red-600">Critical</div>
              </div>
              <div className="text-center p-2 bg-orange-50 rounded">
                <div className="text-sm font-bold text-orange-700">{highCount}</div>
                <div className="text-xs text-orange-600">High</div>
              </div>
              <div className="text-center p-2 bg-muted rounded">
                <div className="text-sm font-bold text-foreground">{averageRiskScore}</div>
                <div className="text-xs text-muted-foreground">Avg Score</div>
              </div>
            </div>

            {/* Risk list */}
            <div className="space-y-3 overflow-y-auto">
              {riskIndicators.map((risk) => {
                const Icon = riskIcons[risk.type];
                
                return (
                  <div 
                    key={risk.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors hover:bg-muted/50 ${
                      risk.severity === 'critical' ? 'border-red-200 bg-red-50/30' :
                      risk.severity === 'high' ? 'border-orange-200 bg-orange-50/30' :
                      ''
                    }`}
                    onClick={() => handleRiskClick(risk)}
                    data-testid={`risk-indicator-${risk.id}`}
                  >
                    {/* Risk header */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium text-sm">{risk.title}</span>
                        <Badge variant="outline" className="text-xs capitalize">
                          {risk.type}
                        </Badge>
                      </div>
                      
                      <Badge 
                        variant="outline"
                        className={`text-xs ${severityColors[risk.severity]}`}
                      >
                        {risk.severity}
                      </Badge>
                    </div>

                    {/* Risk description */}
                    <p className="text-sm text-muted-foreground mb-2">
                      {risk.description}
                    </p>

                    {/* Risk metrics */}
                    <div className="grid grid-cols-3 gap-2 mb-2">
                      <div className="text-center p-1 bg-muted/50 rounded">
                        <div className="text-xs font-medium">{risk.impact}</div>
                        <div className="text-xs text-muted-foreground">Impact</div>
                      </div>
                      <div className="text-center p-1 bg-muted/50 rounded">
                        <div className="text-xs font-medium">{risk.probability}%</div>
                        <div className="text-xs text-muted-foreground">Probability</div>
                      </div>
                      <div className="text-center p-1 bg-muted/50 rounded">
                        <div className="text-xs font-medium">{risk.riskScore}</div>
                        <div className="text-xs text-muted-foreground">Risk Score</div>
                      </div>
                    </div>

                    {/* Risk score bar */}
                    <div className="mb-2">
                      <Progress value={risk.riskScore} className="h-1" />
                    </div>

                    {/* Mitigation actions */}
                    {showMitigations && risk.mitigationActions && risk.mitigationActions.length > 0 && (
                      <div className="text-xs">
                        <span className="text-muted-foreground">Mitigations: </span>
                        <span className="text-foreground">
                          {risk.mitigationActions.slice(0, 2).join(', ')}
                          {risk.mitigationActions.length > 2 && '...'}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Shield className="h-12 w-12 text-green-500 mb-4" />
            <div className="text-sm text-muted-foreground">No significant risks detected</div>
            <div className="text-xs text-muted-foreground mt-1">Your projects are on track</div>
          </div>
        )}
      </div>
    </Widget>
  );
}