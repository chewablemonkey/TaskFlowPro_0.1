import { useMemo } from 'react';
import { Widget } from '../Widget';
import { DonutChart } from '@/components/charts';
import { chartColors } from '@/components/charts/BaseChart';
import { Button } from '@/components/ui/button';
import { WidgetErrorBoundary } from '../ErrorBoundary';
import { useProjectStatusData } from '@/hooks/useDashboardData';
import { useNavigationHelpers } from '@/hooks/useNavigationHelpers';
import { exportProjectStatusData, exportChartData } from '@/lib/exportUtils';
import type { WidgetProps, ProjectStatusData } from '../types';
import { Folder, Download, ExternalLink } from "lucide-react";

interface ProjectStatusWidgetProps extends Omit<WidgetProps, 'children'> {
  onProjectClick?: (status: string) => void;
  enableNavigation?: boolean;
  enableExport?: boolean;
}

function ProjectStatusWidgetInner({ 
  onProjectClick,
  enableNavigation = true,
  enableExport = true,
  ...widgetProps 
}: ProjectStatusWidgetProps) {
  const { data: statusData, isLoading, error, refetch, lastUpdated } = useProjectStatusData(widgetProps.refreshInterval);
  const { navigateToProjects } = useNavigationHelpers();

  // Memoized chart data transformation
  const chartData = useMemo(() => {
    if (!statusData || !Array.isArray(statusData) || statusData.length === 0) return null;

    return {
      labels: statusData.map(item => item.status.charAt(0).toUpperCase() + item.status.slice(1)),
      datasets: [{
        data: statusData.map(item => item.count),
        backgroundColor: statusData.map(item => {
          switch (item.status) {
            case 'planning': return chartColors.status.planning;
            case 'active': return chartColors.status.active;
            case 'completed': return chartColors.status.completed;
            case 'cancelled': return chartColors.status.cancelled;
            default: return chartColors.muted;
          }
        }),
      }],
    };
  }, [statusData]);

  // Memoized summary calculations
  const { totalProjects, activeProjects, completionRate } = useMemo(() => {
    if (!statusData || !Array.isArray(statusData) || statusData.length === 0) {
      return { totalProjects: 0, activeProjects: 0, completionRate: 0 };
    }

    const total = statusData.reduce((sum, item) => sum + item.count, 0);
    const active = statusData.find(item => item.status === 'active')?.count || 0;
    const completed = statusData.find(item => item.status === 'completed')?.count || 0;
    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;

    return {
      totalProjects: total,
      activeProjects: active,
      completionRate: rate
    };
  }, [statusData]);

  // Handle chart segment clicks with navigation
  const handleSegmentClick = (label: string) => {
    const status = label.toLowerCase();
    
    // Custom callback first
    if (onProjectClick) {
      onProjectClick(status);
    }
    
    // Navigate to projects with filter if enabled
    if (enableNavigation) {
      navigateToProjects({ status });
    }
  };

  // Export functionality
  const handleExportCSV = () => {
    if (statusData && statusData.length > 0) {
      exportProjectStatusData(statusData);
    }
  };

  const handleExportChart = () => {
    if (chartData) {
      exportChartData(chartData, `project-status-chart-${new Date().toISOString().split('T')[0]}.csv`);
    }
  };

  // Widget actions
  const actions = enableExport ? [
    <Button
      key="export-csv"
      variant="ghost"
      size="sm"
      onClick={handleExportCSV}
      className="h-8 w-8 p-0"
      title="Export as CSV"
      data-testid={`export-csv-${widgetProps.id}`}
    >
      <Download className="h-3 w-3" />
    </Button>,
    enableNavigation && (
      <Button
        key="view-projects"
        variant="ghost"
        size="sm"
        onClick={() => navigateToProjects()}
        className="h-8 w-8 p-0"
        title="View all projects"
        data-testid={`view-projects-${widgetProps.id}`}
      >
        <ExternalLink className="h-3 w-3" />
      </Button>
    )
  ].filter(Boolean) : [];

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error?.message || null}
      onRefresh={refetch}
      lastUpdated={lastUpdated}
      actions={actions}
    >
      <div className="h-full flex flex-col">
        {chartData && chartData.datasets[0].data.length > 0 ? (
          <>
            <div className="flex-1 min-h-0">
              <DonutChart
                data={chartData}
                height={200}
                centerText={totalProjects.toString()}
                centerSubtext="Total Projects"
                onSegmentClick={handleSegmentClick}
                data-testid={`project-status-chart-${widgetProps.id}`}
              />
            </div>
            
            {/* Status summary */}
            <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
              <div className="text-center p-2 bg-muted/50 rounded">
                <div className="font-semibold text-primary" data-testid="active-projects-count">
                  {activeProjects}
                </div>
                <div className="text-xs text-muted-foreground">Active</div>
              </div>
              <div className="text-center p-2 bg-muted/50 rounded">
                <div className="font-semibold text-green-600" data-testid="completion-rate">
                  {completionRate}%
                </div>
                <div className="text-xs text-muted-foreground">Complete</div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Folder className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No projects found</div>
          </div>
        )}
      </div>
    </Widget>
  );
}

// Export the component wrapped with error boundary
export function ProjectStatusWidget(props: ProjectStatusWidgetProps) {
  return (
    <WidgetErrorBoundary widgetId={props.id}>
      <ProjectStatusWidgetInner {...props} />
    </WidgetErrorBoundary>
  );
}