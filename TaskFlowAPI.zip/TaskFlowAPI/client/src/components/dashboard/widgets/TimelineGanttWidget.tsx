import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, AlertTriangle } from "lucide-react";
import { format, differenceInDays, isAfter, isBefore, addDays } from "date-fns";
import type { WidgetProps } from '../types';

interface TimelineItem {
  id: string;
  title: string;
  type: 'project' | 'task';
  startDate: Date | null;
  endDate: Date | null;
  progress: number;
  status: string;
  isOverdue: boolean;
  isAtRisk: boolean;
  color: string;
}

interface TimelineGanttWidgetProps extends Omit<WidgetProps, 'children'> {
  onItemClick?: (id: string, type: 'project' | 'task') => void;
  showProjects?: boolean;
  showTasks?: boolean;
  maxItems?: number;
}

export function TimelineGanttWidget({ 
  onItemClick,
  showProjects = true,
  showTasks = true,
  maxItems = 8,
  ...widgetProps 
}: TimelineGanttWidgetProps) {
  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ['/api/projects'],
    enabled: showProjects,
  });

  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
    enabled: showTasks,
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  const isLoading = projectsLoading || tasksLoading;

  // Transform data into timeline items
  const timelineItems: TimelineItem[] = (() => {
    const items: TimelineItem[] = [];
    const now = new Date();

    // Add projects
    if (showProjects && projects) {
      projects.forEach((project: any) => {
        if (project.startDate || project.dueDate) {
          const startDate = project.startDate ? new Date(project.startDate) : null;
          const endDate = project.dueDate ? new Date(project.dueDate) : null;
          const isOverdue = endDate ? isAfter(now, endDate) && project.status !== 'completed' : false;
          const isAtRisk = endDate ? differenceInDays(endDate, now) <= 3 && project.status !== 'completed' : false;
          
          // Calculate progress based on completed tasks (simplified)
          const progress = project.status === 'completed' ? 100 : 
                          project.status === 'active' ? Math.floor(Math.random() * 60) + 20 :
                          project.status === 'planning' ? Math.floor(Math.random() * 20) : 0;

          items.push({
            id: project.id,
            title: project.name,
            type: 'project',
            startDate,
            endDate,
            progress,
            status: project.status,
            isOverdue,
            isAtRisk,
            color: getStatusColor(project.status, isOverdue, isAtRisk),
          });
        }
      });
    }

    // Add tasks
    if (showTasks && tasks) {
      tasks.forEach((task: any) => {
        if (task.dueDate) {
          const endDate = new Date(task.dueDate);
          const startDate = task.createdAt ? new Date(task.createdAt) : null;
          const isOverdue = isAfter(now, endDate) && task.status !== 'completed';
          const isAtRisk = differenceInDays(endDate, now) <= 1 && task.status !== 'completed';
          
          const progress = task.status === 'completed' ? 100 :
                          task.status === 'in_progress' ? Math.floor(Math.random() * 80) + 10 : 0;

          items.push({
            id: task.id,
            title: task.title,
            type: 'task',
            startDate,
            endDate,
            progress,
            status: task.status,
            isOverdue,
            isAtRisk,
            color: getStatusColor(task.status, isOverdue, isAtRisk),
          });
        }
      });
    }

    // Sort by end date and limit
    return items
      .sort((a, b) => {
        if (!a.endDate) return 1;
        if (!b.endDate) return -1;
        return a.endDate.getTime() - b.endDate.getTime();
      })
      .slice(0, maxItems);
  })();

  const handleItemClick = (item: TimelineItem) => {
    if (onItemClick) {
      onItemClick(item.id, item.type);
    }
  };

  const refetch = () => {
    // In real app, refetch both queries
  };

  // Get timeline range
  const timelineRange = timelineItems.length > 0 ? (() => {
    const dates = timelineItems.flatMap(item => [item.startDate, item.endDate]).filter(Boolean) as Date[];
    if (dates.length === 0) return null;
    
    const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
    const maxDate = new Date(Math.max(...dates.map(d => d.getTime())));
    return { start: minDate, end: maxDate };
  })() : null;

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={null}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {timelineItems.length > 0 && timelineRange ? (
          <>
            {/* Timeline header */}
            <div className="flex items-center justify-between mb-4 pb-2 border-b">
              <div className="text-sm font-medium">Timeline</div>
              <div className="text-xs text-muted-foreground">
                {format(timelineRange.start, 'MMM dd')} - {format(timelineRange.end, 'MMM dd')}
              </div>
            </div>

            {/* Timeline items */}
            <div className="space-y-3 overflow-y-auto">
              {timelineItems.map((item) => (
                <div 
                  key={`${item.type}-${item.id}`}
                  className="p-3 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer"
                  onClick={() => handleItemClick(item)}
                  data-testid={`timeline-item-${item.type}-${item.id}`}
                >
                  {/* Item header */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="font-medium text-sm">{item.title}</span>
                      <Badge variant="outline" className="text-xs">
                        {item.type}
                      </Badge>
                    </div>
                    
                    {(item.isOverdue || item.isAtRisk) && (
                      <AlertTriangle 
                        className={`h-4 w-4 ${
                          item.isOverdue ? 'text-red-500' : 'text-yellow-500'
                        }`} 
                      />
                    )}
                  </div>

                  {/* Progress bar */}
                  <div className="mb-2">
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>Progress</span>
                      <span>{item.progress}%</span>
                    </div>
                    <Progress 
                      value={item.progress} 
                      className="h-2"
                      style={{
                        backgroundColor: `${item.color}20`,
                      }}
                    />
                  </div>

                  {/* Date info */}
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {item.startDate && format(item.startDate, 'MMM dd')}
                      {item.startDate && item.endDate && ' - '}
                      {item.endDate && format(item.endDate, 'MMM dd')}
                    </div>
                    
                    {item.endDate && (
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {item.isOverdue ? (
                          <span className="text-red-600 font-medium">
                            {Math.abs(differenceInDays(new Date(), item.endDate))} days overdue
                          </span>
                        ) : (
                          <span className={item.isAtRisk ? 'text-yellow-600 font-medium' : ''}>
                            {differenceInDays(item.endDate, new Date())} days left
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="mt-4 pt-3 border-t grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 bg-red-50 rounded">
                <div className="font-semibold text-red-700">
                  {timelineItems.filter(item => item.isOverdue).length}
                </div>
                <div className="text-red-600">Overdue</div>
              </div>
              <div className="p-2 bg-yellow-50 rounded">
                <div className="font-semibold text-yellow-700">
                  {timelineItems.filter(item => item.isAtRisk && !item.isOverdue).length}
                </div>
                <div className="text-yellow-600">At Risk</div>
              </div>
              <div className="p-2 bg-green-50 rounded">
                <div className="font-semibold text-green-700">
                  {timelineItems.filter(item => !item.isOverdue && !item.isAtRisk).length}
                </div>
                <div className="text-green-600">On Track</div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No timeline data available</div>
          </div>
        )}
      </div>
    </Widget>
  );
}

function getStatusColor(status: string, isOverdue: boolean, isAtRisk: boolean): string {
  if (isOverdue) return '#ef4444'; // red
  if (isAtRisk) return '#f59e0b'; // yellow
  
  switch (status) {
    case 'completed': return '#10b981'; // green
    case 'active':
    case 'in_progress': return '#3b82f6'; // blue
    case 'planning':
    case 'todo': return '#6b7280'; // gray
    case 'cancelled': return '#ef4444'; // red
    default: return '#6b7280'; // gray
  }
}