import { Widget } from '../Widget';
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";
import type { WidgetProps } from '../types';

interface KPIData {
  value: string | number;
  label: string;
  trend?: {
    value: number;
    direction: 'up' | 'down' | 'neutral';
    period: string;
  };
  target?: {
    value: number;
    label: string;
  };
  status?: 'success' | 'warning' | 'danger' | 'info';
  icon?: React.ReactNode;
}

interface KPIWidgetProps extends Omit<WidgetProps, 'children'> {
  data: KPIData;
  variant?: 'default' | 'compact' | 'detailed';
}

const statusColors = {
  success: 'text-green-600 bg-green-50 border-green-200',
  warning: 'text-yellow-600 bg-yellow-50 border-yellow-200',
  danger: 'text-red-600 bg-red-50 border-red-200',
  info: 'text-blue-600 bg-blue-50 border-blue-200',
};

const trendIcons = {
  up: TrendingUp,
  down: TrendingDown,
  neutral: Minus,
};

const trendColors = {
  up: 'text-green-600',
  down: 'text-red-600',
  neutral: 'text-gray-600',
};

export function KPIWidget({ 
  data, 
  variant = 'default',
  ...widgetProps 
}: KPIWidgetProps) {
  const TrendIcon = data.trend ? trendIcons[data.trend.direction] : null;

  return (
    <Widget {...widgetProps}>
      <div className={cn(
        "h-full flex flex-col justify-center",
        variant === 'compact' ? "items-center text-center" : "space-y-3"
      )}>
        {/* Icon */}
        {data.icon && variant !== 'compact' && (
          <div className={cn(
            "w-12 h-12 rounded-lg flex items-center justify-center",
            data.status ? statusColors[data.status] : "bg-primary/10 text-primary"
          )}>
            {data.icon}
          </div>
        )}

        {/* Main content */}
        <div className={cn(
          variant === 'compact' ? "space-y-1" : "space-y-2"
        )}>
          <div className="flex items-center gap-2">
            {data.icon && variant === 'compact' && (
              <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-primary/10 text-primary">
                {data.icon}
              </div>
            )}
            <div className={cn(
              "text-2xl font-bold text-foreground",
              variant === 'compact' && "text-xl"
            )} data-testid={`kpi-value-${widgetProps.id}`}>
              {data.value}
            </div>
          </div>

          <div className={cn(
            "text-sm font-medium text-muted-foreground",
            variant === 'compact' && "text-xs"
          )} data-testid={`kpi-label-${widgetProps.id}`}>
            {data.label}
          </div>

          {/* Trend indicator */}
          {data.trend && (
            <div className="flex items-center gap-1">
              {TrendIcon && (
                <TrendIcon className={cn(
                  "h-4 w-4",
                  trendColors[data.trend.direction]
                )} />
              )}
              <span className={cn(
                "text-sm font-medium",
                trendColors[data.trend.direction]
              )} data-testid={`kpi-trend-${widgetProps.id}`}>
                {Math.abs(data.trend.value)}%
              </span>
              <span className="text-xs text-muted-foreground">
                vs {data.trend.period}
              </span>
            </div>
          )}

          {/* Target progress */}
          {data.target && variant === 'detailed' && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Target: {data.target.value}</span>
                <span>{data.target.label}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={cn(
                    "h-2 rounded-full transition-all duration-300",
                    data.status === 'success' ? "bg-green-500" :
                    data.status === 'warning' ? "bg-yellow-500" :
                    data.status === 'danger' ? "bg-red-500" : "bg-blue-500"
                  )}
                  style={{ 
                    width: `${Math.min(
                      100, 
                      (Number(data.value) / data.target.value) * 100
                    )}%` 
                  }}
                />
              </div>
            </div>
          )}

          {/* Status badge */}
          {data.status && variant === 'detailed' && (
            <Badge 
              variant="outline" 
              className={cn(
                "w-fit",
                statusColors[data.status]
              )}
            >
              {data.status.charAt(0).toUpperCase() + data.status.slice(1)}
            </Badge>
          )}
        </div>
      </div>
    </Widget>
  );
}