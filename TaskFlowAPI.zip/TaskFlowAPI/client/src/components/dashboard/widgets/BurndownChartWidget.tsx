import { useQuery } from "@tanstack/react-query";
import { Widget } from '../Widget';
import { LineChart } from '@/components/charts';
import { Badge } from "@/components/ui/badge";
import { TrendingDown, TrendingUp, Calendar } from "lucide-react";
import { format, subDays, eachDayOfInterval, differenceInDays } from "date-fns";
import type { WidgetProps, BurndownData } from '../types';
import type { Task } from '@shared/schema';

interface BurndownChartWidgetProps extends Omit<WidgetProps, 'children'> {
  projectId?: string;
  timeRange?: 'week' | 'month' | 'sprint';
  onPointClick?: (date: string) => void;
}

export function BurndownChartWidget({ 
  projectId,
  timeRange = 'week',
  onPointClick,
  ...widgetProps 
}: BurndownChartWidgetProps) {
  const { data: tasks, isLoading, error, refetch } = useQuery({
    queryKey: projectId ? ['/api/tasks', { project: projectId }] : ['/api/tasks'],
    refetchInterval: widgetProps.refreshInterval ? widgetProps.refreshInterval * 1000 : false,
  });

  // Generate burndown data
  const burndownData: BurndownData[] = tasks ? (() => {
    const endDate = new Date();
    const daysBack = timeRange === 'week' ? 7 : timeRange === 'month' ? 30 : 14; // sprint = 2 weeks
    const startDate = subDays(endDate, daysBack);
    
    const dateRange = eachDayOfInterval({ start: startDate, end: endDate });
    
    // Calculate planned burndown (linear)
    const totalTasks = tasks.length;
    const totalDays = dateRange.length;
    
    return dateRange.map((date, index) => {
      const dayProgress = index / (totalDays - 1);
      const planned = Math.round(totalTasks * (1 - dayProgress));
      
      // Calculate actual remaining tasks up to this date
      const tasksCompletedByDate = tasks.filter((task: Task) => 
        task.completedAt && new Date(task.completedAt) <= date
      ).length;
      const actual = totalTasks - tasksCompletedByDate;
      
      return {
        date: format(date, 'MMM dd'),
        planned,
        actual,
        remaining: actual,
      };
    });
  })() : [];

  const chartData = burndownData.length > 0 ? {
    labels: burndownData.map(item => item.date),
    datasets: [
      {
        label: 'Planned',
        data: burndownData.map(item => item.planned),
        borderColor: 'rgb(107, 114, 128)',
        backgroundColor: 'rgba(107, 114, 128, 0.1)',
        borderDash: [5, 5],
        tension: 0,
      },
      {
        label: 'Actual',
        data: burndownData.map(item => item.actual),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.2,
      },
    ],
  } : null;

  const handlePointClick = (label: string) => {
    if (onPointClick) {
      onPointClick(label);
    }
  };

  // Calculate trend
  const currentRemaining = burndownData[burndownData.length - 1]?.actual || 0;
  const plannedRemaining = burndownData[burndownData.length - 1]?.planned || 0;
  const isAheadOfSchedule = currentRemaining < plannedRemaining;
  const variance = Math.abs(currentRemaining - plannedRemaining);

  const completedTasks = tasks?.filter((task: Task) => task.status === 'completed').length || 0;
  const totalTasks = tasks?.length || 0;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error}
      onRefresh={refetch}
      lastUpdated={new Date()}
    >
      <div className="h-full flex flex-col">
        {chartData && burndownData.length > 0 ? (
          <>
            {/* Chart */}
            <div className="flex-1 min-h-0">
              <LineChart
                data={chartData}
                height={200}
                onPointClick={handlePointClick}
                smooth={false}
                options={{
                  scales: {
                    y: {
                      beginAtZero: true,
                      title: {
                        display: true,
                        text: 'Remaining Tasks',
                      },
                    },
                    x: {
                      title: {
                        display: true,
                        text: 'Date',
                      },
                    },
                  },
                  plugins: {
                    legend: {
                      position: 'top' as const,
                    },
                  },
                }}
                data-testid={`burndown-chart-${widgetProps.id}`}
              />
            </div>
            
            {/* Metrics */}
            <div className="mt-4 grid grid-cols-2 gap-3">
              {/* Completion rate */}
              <div className="text-center p-2 bg-muted/50 rounded">
                <div className="text-lg font-bold text-foreground">
                  {completionRate}%
                </div>
                <div className="text-xs text-muted-foreground">Complete</div>
              </div>
              
              {/* Schedule status */}
              <div className="text-center p-2 bg-muted/50 rounded">
                <div className={`text-lg font-bold ${
                  isAheadOfSchedule ? 'text-green-600' : 'text-red-600'
                }`}>
                  {isAheadOfSchedule ? (
                    <TrendingDown className="h-5 w-5 mx-auto" />
                  ) : (
                    <TrendingUp className="h-5 w-5 mx-auto" />
                  )}
                </div>
                <div className="text-xs text-muted-foreground">
                  {isAheadOfSchedule ? 'Ahead' : 'Behind'}
                </div>
              </div>
            </div>

            {/* Status summary */}
            <div className="mt-3 flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {currentRemaining} tasks remaining
              </div>
              
              <Badge 
                variant="outline" 
                className={
                  isAheadOfSchedule 
                    ? "text-green-600 border-green-200 bg-green-50" 
                    : "text-red-600 border-red-200 bg-red-50"
                }
              >
                {isAheadOfSchedule ? '-' : '+'}{variance} vs plan
              </Badge>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No burndown data available</div>
          </div>
        )}
      </div>
    </Widget>
  );
}