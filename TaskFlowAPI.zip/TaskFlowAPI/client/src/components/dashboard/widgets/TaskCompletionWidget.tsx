import { useMemo } from 'react';
import { Widget } from '../Widget';
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { WidgetErrorBoundary } from '../ErrorBoundary';
import { useDashboardData } from '@/hooks/useDashboardData';
import { useNavigationHelpers } from '@/hooks/useNavigationHelpers';
import { exportWidgetData } from '@/lib/exportUtils';
import { CheckSquare, Clock, AlertTriangle, Download, ExternalLink } from "lucide-react";
import type { WidgetProps, TaskCompletionData } from '../types';

interface TaskCompletionWidgetProps extends Omit<WidgetProps, 'children'> {
  onTaskClick?: (status: string) => void;
  enableNavigation?: boolean;
  enableExport?: boolean;
}

function TaskCompletionWidgetInner({ 
  onTaskClick,
  enableNavigation = true,
  enableExport = true,
  ...widgetProps 
}: TaskCompletionWidgetProps) {
  const { stats, isLoading, error, refetch, lastUpdated } = useDashboardData(widgetProps.refreshInterval);
  const { navigateToTasks } = useNavigationHelpers();

  // Memoized task completion metrics
  const metrics: TaskCompletionData = useMemo(() => {
    if (!stats) {
      return {
        totalTasks: 0,
        completedTasks: 0,
        overdueTasks: 0,
        completionRate: 0,
        trend: 0,
      };
    }

    const totalTasks = stats.totalTasks || 0;
    const completedTasks = stats.completedTasks || 0;
    const overdueTasks = stats.overdueTasks || 0;
    const completionRate = stats.completionRate || 0;
    
    // Mock trend calculation (in real app, this would come from historical data)
    const trend = 5.2; // +5.2% vs previous period

    return {
      totalTasks,
      completedTasks,
      overdueTasks,
      completionRate,
      trend,
    };
  }, [stats]);

  const inProgressTasks = metrics.totalTasks - metrics.completedTasks;

  // Handle task status clicks with navigation
  const handleTaskStatusClick = (status: string) => {
    // Custom callback first
    if (onTaskClick) {
      onTaskClick(status);
    }
    
    // Navigate to tasks with filter if enabled
    if (enableNavigation) {
      if (status === 'overdue') {
        // For overdue, we might want to show tasks with past due dates
        navigateToTasks({ status: 'todo' }); // or create a special overdue filter
      } else {
        navigateToTasks({ status });
      }
    }
  };

  // Export functionality
  const handleExportCSV = () => {
    const exportData = [
      { metric: 'Total Tasks', value: metrics.totalTasks },
      { metric: 'Completed Tasks', value: metrics.completedTasks },
      { metric: 'In Progress Tasks', value: inProgressTasks },
      { metric: 'Overdue Tasks', value: metrics.overdueTasks },
      { metric: 'Completion Rate (%)', value: metrics.completionRate },
      { metric: 'Trend (%)', value: metrics.trend },
    ];
    
    exportWidgetData('Task Completion Metrics', exportData);
  };

  // Widget actions
  const actions = enableExport ? [
    <Button
      key="export-csv"
      variant="ghost"
      size="sm"
      onClick={handleExportCSV}
      className="h-8 w-8 p-0"
      title="Export as CSV"
      data-testid={`export-csv-${widgetProps.id}`}
    >
      <Download className="h-3 w-3" />
    </Button>,
    enableNavigation && (
      <Button
        key="view-tasks"
        variant="ghost"
        size="sm"
        onClick={() => navigateToTasks()}
        className="h-8 w-8 p-0"
        title="View all tasks"
        data-testid={`view-tasks-${widgetProps.id}`}
      >
        <ExternalLink className="h-3 w-3" />
      </Button>
    )
  ].filter(Boolean) : [];

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error?.message || null}
      onRefresh={refetch}
      lastUpdated={lastUpdated}
      actions={actions}
    >
      <div className="h-full flex flex-col space-y-4">
        {/* Main completion rate */}
        <div className="text-center">
          <div className="text-3xl font-bold text-foreground mb-1" data-testid="completion-rate">
            {metrics.completionRate}%
          </div>
          <div className="text-sm text-muted-foreground">Task Completion Rate</div>
          <div className="mt-2">
            <Progress 
              value={metrics.completionRate} 
              className="h-2"
              data-testid="completion-progress"
            />
          </div>
        </div>

        {/* Task breakdown */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div 
            className="p-2 rounded-lg bg-green-50 border border-green-200 cursor-pointer hover:bg-green-100 transition-colors"
            onClick={() => handleTaskStatusClick('completed')}
            data-testid="completed-tasks-card"
          >
            <CheckSquare className="h-5 w-5 text-green-600 mx-auto mb-1" />
            <div className="text-lg font-semibold text-green-700">
              {metrics.completedTasks}
            </div>
            <div className="text-xs text-green-600">Completed</div>
          </div>

          <div 
            className="p-2 rounded-lg bg-blue-50 border border-blue-200 cursor-pointer hover:bg-blue-100 transition-colors"
            onClick={() => handleTaskStatusClick('in_progress')}
            data-testid="in-progress-tasks-card"
          >
            <Clock className="h-5 w-5 text-blue-600 mx-auto mb-1" />
            <div className="text-lg font-semibold text-blue-700">
              {inProgressTasks}
            </div>
            <div className="text-xs text-blue-600">In Progress</div>
          </div>

          <div 
            className="p-2 rounded-lg bg-red-50 border border-red-200 cursor-pointer hover:bg-red-100 transition-colors"
            onClick={() => handleTaskStatusClick('overdue')}
            data-testid="overdue-tasks-card"
          >
            <AlertTriangle className="h-5 w-5 text-red-600 mx-auto mb-1" />
            <div className="text-lg font-semibold text-red-700">
              {metrics.overdueTasks}
            </div>
            <div className="text-xs text-red-600">Overdue</div>
          </div>
        </div>

        {/* Trend and total */}
        <div className="flex justify-between items-center pt-2 border-t">
          <div className="text-sm text-muted-foreground">
            Total: <span className="font-medium text-foreground">{metrics.totalTasks}</span> tasks
          </div>
          
          {metrics.trend !== 0 && (
            <Badge variant="outline" className={
              metrics.trend > 0 
                ? "text-green-600 border-green-200 bg-green-50" 
                : "text-red-600 border-red-200 bg-red-50"
            }>
              {metrics.trend > 0 ? '+' : ''}{metrics.trend}%
            </Badge>
          )}
        </div>
      </div>
    </Widget>
  );
}

// Export the component wrapped with error boundary
export function TaskCompletionWidget(props: TaskCompletionWidgetProps) {
  return (
    <WidgetErrorBoundary widgetId={props.id}>
      <TaskCompletionWidgetInner {...props} />
    </WidgetErrorBoundary>
  );
}