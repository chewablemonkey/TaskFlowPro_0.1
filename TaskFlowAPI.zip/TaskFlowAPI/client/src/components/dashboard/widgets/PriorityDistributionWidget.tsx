import { useMemo } from 'react';
import { Widget } from '../Widget';
import { PieChart } from '@/components/charts';
import { chartColors } from '@/components/charts/BaseChart';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { WidgetErrorBoundary } from '../ErrorBoundary';
import { usePriorityDistributionData } from '@/hooks/useDashboardData';
import { useNavigationHelpers } from '@/hooks/useNavigationHelpers';
import { exportPriorityDistributionData, exportChartData } from '@/lib/exportUtils';
import { AlertTriangle, Minus, ArrowDown, Download, ExternalLink } from "lucide-react";
import type { WidgetProps, PriorityDistributionData } from '../types';

interface PriorityDistributionWidgetProps extends Omit<WidgetProps, 'children'> {
  onPriorityClick?: (priority: string) => void;
  enableNavigation?: boolean;
  enableExport?: boolean;
}

const priorityIcons = {
  high: AlertTriangle,
  medium: Minus,
  low: ArrowDown,
};

function PriorityDistributionWidgetInner({ 
  onPriorityClick,
  enableNavigation = true,
  enableExport = true,
  ...widgetProps 
}: PriorityDistributionWidgetProps) {
  const { data: priorityData, isLoading, error, refetch, lastUpdated } = usePriorityDistributionData(widgetProps.refreshInterval);
  const { navigateToTasks } = useNavigationHelpers();

  // Memoized chart data transformation
  const chartData = useMemo(() => {
    if (!priorityData || priorityData.length === 0) return null;

    return {
      labels: priorityData.map(item => item.priority.charAt(0).toUpperCase() + item.priority.slice(1)),
      datasets: [{
        data: priorityData.map(item => item.count),
        backgroundColor: priorityData.map(item => chartColors.priority[item.priority]),
        borderColor: priorityData.map(item => chartColors.priority[item.priority]),
      }],
    };
  }, [priorityData]);


  // Handle chart segment clicks with navigation
  const handleSegmentClick = (label: string) => {
    const priority = label.toLowerCase();
    
    // Custom callback first
    if (onPriorityClick) {
      onPriorityClick(priority);
    }
    
    // Navigate to tasks with priority filter if enabled
    if (enableNavigation) {
      navigateToTasks({ priority });
    }
  };

  // Handle priority item clicks
  const handlePriorityItemClick = (priority: string) => {
    // Custom callback first
    if (onPriorityClick) {
      onPriorityClick(priority);
    }
    
    // Navigate to tasks with priority filter if enabled
    if (enableNavigation) {
      navigateToTasks({ priority });
    }
  };

  // Export functionality
  const handleExportCSV = () => {
    if (priorityData && priorityData.length > 0) {
      exportPriorityDistributionData(priorityData);
    }
  };

  const handleExportChart = () => {
    if (chartData) {
      exportChartData(chartData, `priority-distribution-chart-${new Date().toISOString().split('T')[0]}.csv`);
    }
  };

  // Widget actions
  const actions = enableExport ? [
    <Button
      key="export-csv"
      variant="ghost"
      size="sm"
      onClick={handleExportCSV}
      className="h-8 w-8 p-0"
      title="Export as CSV"
      data-testid={`export-csv-${widgetProps.id}`}
    >
      <Download className="h-3 w-3" />
    </Button>,
    enableNavigation && (
      <Button
        key="view-tasks"
        variant="ghost"
        size="sm"
        onClick={() => navigateToTasks()}
        className="h-8 w-8 p-0"
        title="View all tasks"
        data-testid={`view-tasks-${widgetProps.id}`}
      >
        <ExternalLink className="h-3 w-3" />
      </Button>
    )
  ].filter(Boolean) : [];

  // Memoized summary calculations
  const { totalTasks, highPriorityCount } = useMemo(() => {
    if (!priorityData || priorityData.length === 0) {
      return { totalTasks: 0, highPriorityCount: 0 };
    }

    const total = priorityData.reduce((sum, item) => sum + item.count, 0);
    const highPriority = priorityData.find(p => p.priority === 'high')?.count || 0;

    return { totalTasks: total, highPriorityCount: highPriority };
  }, [priorityData]);

  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error?.message || null}
      onRefresh={refetch}
      lastUpdated={lastUpdated}
      actions={actions}
    >
      <div className="h-full flex flex-col">
        {chartData && totalTasks > 0 ? (
          <>
            {/* Chart */}
            <div className="flex-1 min-h-0">
              <PieChart
                data={chartData}
                height={180}
                onSegmentClick={handleSegmentClick}
                options={{
                  plugins: {
                    legend: {
                      position: 'bottom' as const,
                      labels: {
                        usePointStyle: true,
                      },
                    },
                  },
                }}
                data-testid={`priority-distribution-chart-${widgetProps.id}`}
              />
            </div>
            
            {/* Priority breakdown */}
            <div className="mt-4 space-y-2">
              {priorityData.map((item) => {
                const Icon = priorityIcons[item.priority];
                return (
                  <div 
                    key={item.priority}
                    className="flex items-center justify-between p-2 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => handlePriorityItemClick(item.priority)}
                    data-testid={`priority-item-${item.priority}`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon 
                        className={`h-4 w-4 ${
                          item.priority === 'high' ? 'text-red-500' :
                          item.priority === 'medium' ? 'text-yellow-500' :
                          'text-green-500'
                        }`} 
                      />
                      <span className="text-sm font-medium capitalize">
                        {item.priority}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">
                        {item.count}
                      </span>
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${
                          item.priority === 'high' ? 'border-red-200 text-red-600 bg-red-50' :
                          item.priority === 'medium' ? 'border-yellow-200 text-yellow-600 bg-yellow-50' :
                          'border-green-200 text-green-600 bg-green-50'
                        }`}
                      >
                        {item.percentage}%
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* High priority alert */}
            {highPriorityCount > 0 && (
              <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center gap-2 text-red-700">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="text-sm font-medium">
                    {highPriorityCount} high priority task{highPriorityCount !== 1 ? 's' : ''} need attention
                  </span>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No task priorities to display</div>
          </div>
        )}
      </div>
    </Widget>
  );
}

// Export the component wrapped with error boundary
export function PriorityDistributionWidget(props: PriorityDistributionWidgetProps) {
  return (
    <WidgetErrorBoundary widgetId={props.id}>
      <PriorityDistributionWidgetInner {...props} />
    </WidgetErrorBoundary>
  );
}