import { useMemo } from 'react';
import { Widget } from '../Widget';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { WidgetErrorBoundary } from '../ErrorBoundary';
import { useActivityFeedData } from '@/hooks/useDashboardData';
import { useNavigationHelpers } from '@/hooks/useNavigationHelpers';
import { exportActivityFeedData } from '@/lib/exportUtils';
import { 
  MessageSquare, 
  CheckCircle, 
  UserPlus, 
  FileText, 
  Upload,
  Folder,
  Activity,
  Download,
  ExternalLink
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { WidgetProps, ActivityItem } from '../types';

interface ActivityFeedWidgetProps extends Omit<WidgetProps, 'children'> {
  onActivityClick?: (activityId: string) => void;
  maxItems?: number;
  showUserAvatars?: boolean;
  enableNavigation?: boolean;
  enableExport?: boolean;
}

const activityIcons = {
  task_created: FileText,
  task_completed: CheckCircle,
  task_assigned: UserPlus,
  comment_added: MessageSquare,
  file_uploaded: Upload,
  project_created: Folder,
};

const activityColors = {
  task_created: 'text-blue-500',
  task_completed: 'text-green-500',
  task_assigned: 'text-purple-500',
  comment_added: 'text-orange-500',
  file_uploaded: 'text-cyan-500',
  project_created: 'text-indigo-500',
};

function ActivityFeedWidgetInner({ 
  onActivityClick,
  maxItems = 10,
  showUserAvatars = true,
  enableNavigation = true,
  enableExport = true,
  ...widgetProps 
}: ActivityFeedWidgetProps) {
  const { data: activities, isLoading, error, refetch, lastUpdated } = useActivityFeedData(widgetProps.refreshInterval, maxItems);
  const { navigateToProjectDetails, navigateToTaskDetails } = useNavigationHelpers();

  // Handle activity clicks with navigation
  const handleActivityClick = (activity: ActivityItem) => {
    // Custom callback first
    if (onActivityClick) {
      onActivityClick(activity.id);
    }
    
    // Navigate to details if enabled
    if (enableNavigation && activity.metadata) {
      if (activity.metadata.taskId) {
        navigateToTaskDetails(activity.metadata.taskId);
      } else if (activity.metadata.projectId) {
        navigateToProjectDetails(activity.metadata.projectId);
      }
    }
  };

  // Export functionality
  const handleExportCSV = () => {
    if (activities && activities.length > 0) {
      exportActivityFeedData(activities);
    }
  };

  // Widget actions
  const actions = enableExport ? [
    <Button
      key="export-csv"
      variant="ghost"
      size="sm"
      onClick={handleExportCSV}
      className="h-8 w-8 p-0"
      title="Export as CSV"
      data-testid={`export-csv-${widgetProps.id}`}
    >
      <Download className="h-3 w-3" />
    </Button>
  ] : [];


  return (
    <Widget 
      {...widgetProps}
      isLoading={isLoading}
      error={error?.message || null}
      onRefresh={refetch}
      lastUpdated={lastUpdated}
      actions={actions}
    >
      <div className="h-full flex flex-col">
        {activities && activities.length > 0 ? (
          <div className="space-y-3 overflow-y-auto">
            {activities.map((activity) => {
              const Icon = activityIcons[activity.type];
              
              return (
                <div 
                  key={activity.id}
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                  onClick={() => handleActivityClick(activity)}
                  data-testid={`activity-item-${activity.id}`}
                >
                  {/* User avatar */}
                  {showUserAvatars && (
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      <AvatarImage src={activity.user.avatar || `https://avatar.vercel.sh/${activity.user.id}`} />
                      <AvatarFallback className="text-xs">
                        {activity.user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  )}

                  {/* Activity icon */}
                  <div className={`w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0 ${
                    !showUserAvatars ? '' : 'hidden sm:flex'
                  }`}>
                    <Icon className={`h-4 w-4 ${activityColors[activity.type]}`} />
                  </div>

                  {/* Activity content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{activity.title}</span>
                      <Badge variant="outline" className="text-xs">
                        {activity.type.replace('_', ' ')}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-1">
                      {activity.description}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{activity.user.name}</span>
                      <span>{formatDistanceToNow(activity.timestamp, { addSuffix: true })}</span>
                    </div>

                    {/* Project context */}
                    {activity.metadata?.projectName && (
                      <div className="mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {activity.metadata.projectName}
                        </Badge>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Activity className="h-12 w-12 text-muted-foreground mb-4" />
            <div className="text-sm text-muted-foreground">No recent activity</div>
          </div>
        )}
      </div>
    </Widget>
  );
}

// Export the component wrapped with error boundary
export function ActivityFeedWidget(props: ActivityFeedWidgetProps) {
  return (
    <WidgetErrorBoundary widgetId={props.id}>
      <ActivityFeedWidgetInner {...props} />
    </WidgetErrorBoundary>
  );
}