import { Component, ErrorInfo, ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw, Bug } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  resetOnPropsChange?: boolean;
  resetKeys?: Array<string | number>;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
  errorId: string;
}

export class ErrorBoundary extends Component<Props, State> {
  private resetTimeoutId: number | null = null;

  public state: State = {
    hasError: false,
    errorId: '',
  };

  public static getDerivedStateFromError(error: Error): Partial<State> {
    // Update state so the next render will show the fallback UI
    return {
      hasError: true,
      errorId: `error-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Widget Error Boundary caught an error:', error, errorInfo);
    
    this.setState({
      error,
      errorInfo,
    });

    // Call the optional onError callback
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Auto-retry after a delay for transient errors
    if (this.isTransientError(error)) {
      this.scheduleAutoRetry();
    }
  }

  public componentDidUpdate(prevProps: Props, prevState: State) {
    const { resetOnPropsChange, resetKeys } = this.props;
    const { hasError } = this.state;

    // Only reset if we had an error and the reset conditions are met
    // Add check to prevent infinite loops
    if (hasError && prevState.hasError) {
      // Reset error state when props change (if enabled)
      if (resetOnPropsChange && prevProps.children !== this.props.children) {
        // Use setTimeout to break the update cycle
        setTimeout(() => this.resetErrorBoundary(), 0);
        return;
      }

      // Reset error state when reset keys change
      if (resetKeys && prevProps.resetKeys) {
        const hasResetKeyChanged = resetKeys.some((key, index) => 
          prevProps.resetKeys?.[index] !== key
        );
        if (hasResetKeyChanged) {
          // Use setTimeout to break the update cycle
          setTimeout(() => this.resetErrorBoundary(), 0);
          return;
        }
      }
    }
  }

  public componentWillUnmount() {
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
    }
  }

  private isTransientError = (error: Error): boolean => {
    const transientPatterns = [
      /network/i,
      /fetch/i,
      /timeout/i,
      /connection/i,
      /loading chunk/i,
    ];
    
    return transientPatterns.some(pattern => 
      pattern.test(error.message) || pattern.test(error.name)
    );
  };

  private scheduleAutoRetry = () => {
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
    }

    // Auto-retry after 3 seconds for transient errors
    this.resetTimeoutId = window.setTimeout(() => {
      this.resetErrorBoundary();
    }, 3000);
  };

  private resetErrorBoundary = () => {
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
      this.resetTimeoutId = null;
    }

    this.setState({
      hasError: false,
      error: undefined,
      errorInfo: undefined,
      errorId: '',
    });
  };

  private handleRetry = () => {
    this.resetErrorBoundary();
  };

  private getErrorType = (error?: Error): string => {
    if (!error) return 'Unknown Error';
    
    if (error.message.includes('ChunkLoadError') || error.message.includes('Loading chunk')) {
      return 'Resource Loading Error';
    }
    if (error.message.includes('Network') || error.message.includes('fetch')) {
      return 'Network Error';
    }
    if (error.name === 'TypeError') {
      return 'Type Error';
    }
    if (error.name === 'ReferenceError') {
      return 'Reference Error';
    }
    
    return error.name || 'Application Error';
  };

  private getErrorMessage = (error?: Error): string => {
    if (!error) return 'An unexpected error occurred';
    
    if (error.message.includes('ChunkLoadError')) {
      return 'Failed to load application resources. This may be due to a network issue or an application update.';
    }
    if (error.message.includes('Network')) {
      return 'A network error occurred. Please check your connection and try again.';
    }
    if (error.message.includes('fetch')) {
      return 'Failed to fetch data from the server. Please try again.';
    }
    
    return error.message || 'An unexpected error occurred';
  };

  private getErrorSuggestions = (error?: Error): string[] => {
    if (!error) return ['Try refreshing the page'];
    
    const suggestions: string[] = [];
    
    if (error.message.includes('ChunkLoadError') || error.message.includes('Loading chunk')) {
      suggestions.push('Refresh the page to reload resources');
      suggestions.push('Clear your browser cache');
      suggestions.push('Check your internet connection');
    } else if (error.message.includes('Network') || error.message.includes('fetch')) {
      suggestions.push('Check your internet connection');
      suggestions.push('Try again in a few moments');
      suggestions.push('Contact support if the issue persists');
    } else {
      suggestions.push('Try refreshing the widget');
      suggestions.push('If the problem persists, try refreshing the page');
    }
    
    return suggestions;
  };

  public render() {
    if (this.state.hasError) {
      // Custom fallback UI
      if (this.props.fallback) {
        return this.props.fallback;
      }

      const errorType = this.getErrorType(this.state.error);
      const errorMessage = this.getErrorMessage(this.state.error);
      const suggestions = this.getErrorSuggestions(this.state.error);
      const isTransient = this.state.error ? this.isTransientError(this.state.error) : false;

      return (
        <Card className="h-full border-destructive/20 bg-destructive/5">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Widget Error
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="text-sm font-medium text-foreground">{errorType}</div>
              <div className="text-sm text-muted-foreground">{errorMessage}</div>
            </div>

            {suggestions.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-medium text-muted-foreground">Suggestions:</div>
                <ul className="space-y-1">
                  {suggestions.map((suggestion, index) => (
                    <li key={index} className="text-xs text-muted-foreground flex items-start gap-1">
                      <span className="text-primary">•</span>
                      {suggestion}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={this.handleRetry}
                className="flex items-center gap-2"
                data-testid="error-boundary-retry"
              >
                <RefreshCw className="h-3 w-3" />
                Try Again
              </Button>

              {process.env.NODE_ENV === 'development' && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    console.group(`🐛 Widget Error Details [${this.state.errorId}]`);
                    console.error('Error:', this.state.error);
                    console.error('Error Info:', this.state.errorInfo);
                    console.groupEnd();
                  }}
                  className="flex items-center gap-2 text-muted-foreground"
                >
                  <Bug className="h-3 w-3" />
                  Debug
                </Button>
              )}
            </div>

            {isTransient && (
              <div className="text-xs text-muted-foreground bg-amber-50 dark:bg-amber-900/20 p-2 rounded">
                <div className="flex items-center gap-1">
                  <RefreshCw className="h-3 w-3 animate-spin" />
                  Auto-retrying in a few seconds...
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      );
    }

    return this.props.children;
  }
}

// HOC for wrapping widgets with error boundary
export function withErrorBoundary<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  errorBoundaryProps?: Omit<Props, 'children'>
) {
  const WithErrorBoundaryComponent = (props: P) => (
    <ErrorBoundary {...errorBoundaryProps}>
      <WrappedComponent {...props} />
    </ErrorBoundary>
  );

  WithErrorBoundaryComponent.displayName = `withErrorBoundary(${WrappedComponent.displayName || WrappedComponent.name})`;
  
  return WithErrorBoundaryComponent;
}

// Widget-specific error boundary with optimized settings
export function WidgetErrorBoundary({ children, widgetId }: { children: ReactNode; widgetId: string }) {
  return (
    <ErrorBoundary
      resetOnPropsChange={true}
      onError={(error, errorInfo) => {
        // Log widget-specific errors
        console.error(`Widget Error [${widgetId}]:`, error);
        
        // In production, you might want to send this to an error tracking service
        if (process.env.NODE_ENV === 'production') {
          // Example: errorTrackingService.captureException(error, { widgetId, errorInfo });
        }
      }}
    >
      {children}
    </ErrorBoundary>
  );
}