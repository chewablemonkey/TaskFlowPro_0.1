import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
  ChartData,
} from 'chart.js';
import { forwardRef } from 'react';
import { defaultChartOptions, generateColors, generateBorderColors, type ChartRef } from './BaseChart';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export interface BarChartProps {
  data: {
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      backgroundColor?: string | string[];
      borderColor?: string | string[];
      borderWidth?: number;
    }[];
  };
  options?: ChartOptions<'bar'>;
  className?: string;
  onBarClick?: (label: string, value: number, datasetIndex: number, index: number) => void;
  height?: number;
  horizontal?: boolean;
  stacked?: boolean;
}

const defaultBarOptions: ChartOptions<'bar'> = {
  ...defaultChartOptions,
  scales: {
    x: {
      grid: {
        display: false,
      },
      ticks: {
        color: '#6b7280',
      },
    },
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(107, 114, 128, 0.1)',
      },
      ticks: {
        color: '#6b7280',
      },
    },
  },
  plugins: {
    ...defaultChartOptions.plugins,
    legend: {
      ...defaultChartOptions.plugins?.legend,
      position: 'top' as const,
    },
  },
};

export const BarChart = forwardRef<ChartRef, BarChartProps>(({
  data,
  options = {},
  className = '',
  onBarClick,
  height = 300,
  horizontal = false,
  stacked = false,
}, ref) => {
  const chartData: ChartData<'bar'> = {
    labels: data.labels,
    datasets: data.datasets.map((dataset, index) => ({
      ...dataset,
      backgroundColor: dataset.backgroundColor || generateColors(1, 0.8)[0],
      borderColor: dataset.borderColor || generateBorderColors(1)[0],
      borderWidth: dataset.borderWidth || 1,
    })),
  };

  const chartOptions: ChartOptions<'bar'> = {
    ...defaultBarOptions,
    indexAxis: horizontal ? 'y' as const : 'x' as const,
    ...options,
    onClick: onBarClick ? (event, elements) => {
      if (elements.length > 0) {
        const element = elements[0];
        const datasetIndex = element.datasetIndex;
        const index = element.index;
        const label = data.labels[index];
        const value = data.datasets[datasetIndex].data[index];
        onBarClick(label, value, datasetIndex, index);
      }
    } : undefined,
    scales: {
      ...defaultBarOptions.scales,
      ...(horizontal ? {
        x: {
          ...defaultBarOptions.scales?.y,
          beginAtZero: true,
          stacked,
        },
        y: {
          ...defaultBarOptions.scales?.x,
          stacked,
        },
      } : {
        x: {
          ...defaultBarOptions.scales?.x,
          stacked,
        },
        y: {
          ...defaultBarOptions.scales?.y,
          stacked,
        },
      }),
      ...options.scales,
    },
  };

  return (
    <div className={`relative ${className}`} style={{ height }}>
      <Bar
        ref={ref}
        data={chartData}
        options={chartOptions}
        data-testid="bar-chart"
      />
    </div>
  );
});

BarChart.displayName = 'BarChart';