import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  ChartOptions,
  ChartData,
} from 'chart.js';
import { forwardRef } from 'react';
import { defaultChartOptions, chartColors, generateColors, type ChartRef } from './BaseChart';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export interface LineChartProps {
  data: {
    labels: string[];
    datasets: {
      label: string;
      data: number[];
      borderColor?: string;
      backgroundColor?: string;
      fill?: boolean;
      tension?: number;
      borderWidth?: number;
      pointRadius?: number;
      pointHoverRadius?: number;
    }[];
  };
  options?: ChartOptions<'line'>;
  className?: string;
  onPointClick?: (label: string, value: number, datasetIndex: number, index: number) => void;
  height?: number;
  smooth?: boolean;
  filled?: boolean;
}

const defaultLineOptions: ChartOptions<'line'> = {
  ...defaultChartOptions,
  scales: {
    x: {
      grid: {
        display: false,
      },
      ticks: {
        color: '#6b7280',
      },
    },
    y: {
      beginAtZero: true,
      grid: {
        color: 'rgba(107, 114, 128, 0.1)',
      },
      ticks: {
        color: '#6b7280',
      },
    },
  },
  elements: {
    point: {
      radius: 4,
      hoverRadius: 8,
      borderWidth: 2,
    },
    line: {
      borderWidth: 3,
      tension: 0.4,
    },
  },
  plugins: {
    ...defaultChartOptions.plugins,
    legend: {
      ...defaultChartOptions.plugins?.legend,
      position: 'top' as const,
    },
  },
};

export const LineChart = forwardRef<ChartRef, LineChartProps>(({
  data,
  options = {},
  className = '',
  onPointClick,
  height = 300,
  smooth = true,
  filled = false,
}, ref) => {
  const chartData: ChartData<'line'> = {
    labels: data.labels,
    datasets: data.datasets.map((dataset, index) => {
      const color = chartColors.palette[index % chartColors.palette.length];
      return {
        ...dataset,
        borderColor: dataset.borderColor || color,
        backgroundColor: dataset.backgroundColor || (filled ? `${color}20` : 'transparent'),
        fill: filled || dataset.fill,
        tension: smooth ? (dataset.tension ?? 0.4) : 0,
        borderWidth: dataset.borderWidth || 3,
        pointRadius: dataset.pointRadius || 4,
        pointHoverRadius: dataset.pointHoverRadius || 8,
        pointBackgroundColor: color,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
      };
    }),
  };

  const chartOptions: ChartOptions<'line'> = {
    ...defaultLineOptions,
    ...options,
    onClick: onPointClick ? (event, elements) => {
      if (elements.length > 0) {
        const element = elements[0];
        const datasetIndex = element.datasetIndex;
        const index = element.index;
        const label = data.labels[index];
        const value = data.datasets[datasetIndex].data[index];
        onPointClick(label, value, datasetIndex, index);
      }
    } : undefined,
    scales: {
      ...defaultLineOptions.scales,
      ...options.scales,
    },
  };

  return (
    <div className={`relative ${className}`} style={{ height }}>
      <Line
        ref={ref}
        data={chartData}
        options={chartOptions}
        data-testid="line-chart"
      />
    </div>
  );
});

LineChart.displayName = 'LineChart';