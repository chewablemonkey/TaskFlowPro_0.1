import { Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  ChartOptions,
  ChartData,
} from 'chart.js';
import { forwardRef } from 'react';
import { defaultChartOptions, chartColors, generateColors, generateBorderColors, type ChartRef } from './BaseChart';

ChartJS.register(ArcElement, Tooltip, Legend);

export interface PieChartProps {
  data: {
    labels: string[];
    datasets: {
      data: number[];
      backgroundColor?: string[];
      borderColor?: string[];
      borderWidth?: number;
    }[];
  };
  options?: ChartOptions<'pie'>;
  className?: string;
  onSegmentClick?: (label: string, value: number, index: number) => void;
  height?: number;
  showValues?: boolean;
  centerText?: string;
}

const defaultPieOptions: ChartOptions<'pie'> = {
  ...defaultChartOptions,
  plugins: {
    ...defaultChartOptions.plugins,
    legend: {
      ...defaultChartOptions.plugins?.legend,
      position: 'right' as const,
    },
    tooltip: {
      ...defaultChartOptions.plugins?.tooltip,
      callbacks: {
        label: function(context) {
          const label = context.label || '';
          const value = context.parsed;
          const total = context.dataset.data.reduce((sum: number, val: number) => sum + val, 0);
          const percentage = ((value / total) * 100).toFixed(1);
          return `${label}: ${value} (${percentage}%)`;
        },
      },
    },
  },
};

export const PieChart = forwardRef<ChartRef, PieChartProps>(({
  data,
  options = {},
  className = '',
  onSegmentClick,
  height = 300,
  showValues = true,
}, ref) => {
  const chartData: ChartData<'pie'> = {
    labels: data.labels,
    datasets: data.datasets.map((dataset, index) => ({
      ...dataset,
      backgroundColor: dataset.backgroundColor || generateColors(data.labels.length, 0.8),
      borderColor: dataset.borderColor || generateBorderColors(data.labels.length),
      borderWidth: dataset.borderWidth || 2,
    })),
  };

  const chartOptions: ChartOptions<'pie'> = {
    ...defaultPieOptions,
    ...options,
    onClick: onSegmentClick ? (event, elements) => {
      if (elements.length > 0) {
        const index = elements[0].index;
        const label = data.labels[index];
        const value = data.datasets[0].data[index];
        onSegmentClick(label, value, index);
      }
    } : undefined,
    plugins: {
      ...defaultPieOptions.plugins,
      ...options.plugins,
      tooltip: {
        ...defaultPieOptions.plugins?.tooltip,
        ...options.plugins?.tooltip,
        enabled: showValues,
      },
    },
  };

  return (
    <div className={`relative ${className}`} style={{ height }}>
      <Pie
        ref={ref}
        data={chartData}
        options={chartOptions}
        data-testid="pie-chart"
      />
    </div>
  );
});

PieChart.displayName = 'PieChart';