import { Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  ChartOptions,
  ChartData,
} from 'chart.js';
import { forwardRef } from 'react';
import { defaultChartOptions, generateColors, generateBorderColors, type ChartRef } from './BaseChart';

ChartJS.register(ArcElement, Tooltip, Legend);

export interface DonutChartProps {
  data: {
    labels: string[];
    datasets: {
      data: number[];
      backgroundColor?: string[];
      borderColor?: string[];
      borderWidth?: number;
    }[];
  };
  options?: ChartOptions<'doughnut'>;
  className?: string;
  onSegmentClick?: (label: string, value: number, index: number) => void;
  height?: number;
  centerText?: string;
  centerSubtext?: string;
  showValues?: boolean;
}

const defaultDonutOptions: ChartOptions<'doughnut'> = {
  ...defaultChartOptions,
  cutout: '60%',
  plugins: {
    ...defaultChartOptions.plugins,
    legend: {
      ...defaultChartOptions.plugins?.legend,
      position: 'bottom' as const,
    },
    tooltip: {
      ...defaultChartOptions.plugins?.tooltip,
      callbacks: {
        label: function(context) {
          const label = context.label || '';
          const value = context.parsed;
          const total = context.dataset.data.reduce((sum: number, val: number) => sum + val, 0);
          const percentage = ((value / total) * 100).toFixed(1);
          return `${label}: ${value} (${percentage}%)`;
        },
      },
    },
  },
};

export const DonutChart = forwardRef<ChartRef, DonutChartProps>(({
  data,
  options = {},
  className = '',
  onSegmentClick,
  height = 300,
  centerText,
  centerSubtext,
  showValues = true,
}, ref) => {
  const chartData: ChartData<'doughnut'> = {
    labels: data.labels,
    datasets: data.datasets.map((dataset) => ({
      ...dataset,
      backgroundColor: dataset.backgroundColor || generateColors(data.labels.length, 0.8),
      borderColor: dataset.borderColor || generateBorderColors(data.labels.length),
      borderWidth: dataset.borderWidth || 2,
    })),
  };

  const chartOptions: ChartOptions<'doughnut'> = {
    ...defaultDonutOptions,
    ...options,
    onClick: onSegmentClick ? (event, elements) => {
      if (elements.length > 0) {
        const index = elements[0].index;
        const label = data.labels[index];
        const value = data.datasets[0].data[index];
        onSegmentClick(label, value, index);
      }
    } : undefined,
    plugins: {
      ...defaultDonutOptions.plugins,
      ...options.plugins,
      tooltip: {
        ...defaultDonutOptions.plugins?.tooltip,
        ...options.plugins?.tooltip,
        enabled: showValues,
      },
    },
  };

  return (
    <div className={`relative ${className}`} style={{ height }}>
      <Doughnut
        ref={ref}
        data={chartData}
        options={chartOptions}
        data-testid="donut-chart"
      />
      {(centerText || centerSubtext) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          {centerText && (
            <div className="text-2xl font-bold text-foreground" data-testid="donut-center-text">
              {centerText}
            </div>
          )}
          {centerSubtext && (
            <div className="text-sm text-muted-foreground" data-testid="donut-center-subtext">
              {centerSubtext}
            </div>
          )}
        </div>
      )}
    </div>
  );
});

DonutChart.displayName = 'DonutChart';