import { ChartOptions, ChartData, Chart as ChartJS } from 'chart.js';
import { forwardRef } from 'react';

export interface BaseChartProps {
  data: ChartData<any, any[], any>;
  options?: ChartOptions<any>;
  width?: number;
  height?: number;
  className?: string;
  onChartClick?: (event: any, elements: any[]) => void;
}

export interface ChartRef {
  chart?: ChartJS;
}

// Common chart configuration
export const defaultChartOptions: ChartOptions<any> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom' as const,
      labels: {
        padding: 20,
        usePointStyle: true,
        font: {
          size: 12,
        },
      },
    },
    tooltip: {
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      titleColor: '#fff',
      bodyColor: '#fff',
      borderColor: 'rgba(255, 255, 255, 0.1)',
      borderWidth: 1,
      cornerRadius: 8,
      displayColors: true,
      padding: 12,
    },
  },
  interaction: {
    intersect: false,
    mode: 'nearest' as const,
  },
};

// Color palette for consistent theming
export const chartColors = {
  primary: '#3b82f6',
  secondary: '#6366f1',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  info: '#06b6d4',
  muted: '#6b7280',
  
  // Extended palette for multi-series charts
  palette: [
    '#3b82f6', // blue
    '#10b981', // green
    '#f59e0b', // yellow
    '#ef4444', // red
    '#6366f1', // indigo
    '#06b6d4', // cyan
    '#8b5cf6', // violet
    '#f97316', // orange
    '#ec4899', // pink
    '#84cc16', // lime
  ],
  
  // Status-specific colors
  status: {
    planning: '#6b7280',
    active: '#3b82f6',
    completed: '#10b981',
    cancelled: '#ef4444',
    overdue: '#dc2626',
  },
  
  priority: {
    low: '#10b981',
    medium: '#f59e0b',
    high: '#ef4444',
  },
};

// Utility function to get chart colors with opacity
export const getChartColor = (color: string, opacity: number = 1): string => {
  if (color.startsWith('#')) {
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
  }
  return color;
};

// Generate background colors for datasets
export const generateColors = (count: number, opacity: number = 0.8): string[] => {
  return Array.from({ length: count }, (_, i) => 
    getChartColor(chartColors.palette[i % chartColors.palette.length], opacity)
  );
};

// Generate border colors for datasets
export const generateBorderColors = (count: number): string[] => {
  return Array.from({ length: count }, (_, i) => 
    chartColors.palette[i % chartColors.palette.length]
  );
};